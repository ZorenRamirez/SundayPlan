begin;
create table public.student_plans (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  revision integer not null default 1 check (revision > 0)
);
alter table public.student_plans enable row level security;
revoke all on table public.student_plans from public, anon, authenticated;
grant select, insert on public.student_plans to authenticated;
grant update (payload, revision) on public.student_plans to authenticated;
create policy student_read_own on public.student_plans for select to authenticated
using ((select auth.uid()) = user_id);
create policy student_insert_own on public.student_plans for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy student_update_own on public.student_plans for update to authenticated
using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
commit;
