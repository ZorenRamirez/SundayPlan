begin;

-- The caller supplies no user ID. Deleting the authenticated identity also
-- removes its student_plans row through the existing foreign key.
create or replace function public.delete_my_sunday_plan_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  student_id uuid := auth.uid();
begin
  if student_id is null then
    raise exception 'Sign in before deleting an account' using errcode = '42501';
  end if;
  delete from auth.users where id = student_id;
end;
$$;

revoke all on function public.delete_my_sunday_plan_account() from public, anon, authenticated;
grant execute on function public.delete_my_sunday_plan_account() to authenticated;
commit;
