# Supabase email templates

Source of truth for the Confirm signup email. Supabase does not read these files automatically.

1. Dashboard → Authentication → Emails → Confirm signup (custom SMTP sender required to edit templates).
2. Paste `confirm-signup.subject.txt` into Subject and `confirm-signup.html` into the message body.
3. Keep `{{ .ConfirmationURL }}` exactly as written (used for the button and the fallback link).
4. Send yourself a test signup and check it on a phone and in dark mode.
