const {test} = require("node:test");
const assert = require("node:assert/strict");
const {cleanInput} = require("./apple-ranker");
const candidate = {title:"Campus Robotics",kind:"Club",summary:"Build robots together.",step:"Ask about the next meeting.",minutes:10,reasons:["Matches your interest in clubs."]};
test("the ranker accepts only bounded listing data and sends no extra profile fields to the model", () => {
  const request = {intent:"Meet people",preferences:"Engineering, clubs",remaining:60,candidates:[{...candidate,email:"private@example.invalid"}],name:"Private"};
  const result=cleanInput(request);
  assert.equal(result.name,undefined);
  assert.equal(result.candidates[0].email,undefined);
  assert.throws(()=>cleanInput({...request,remaining:-1}));
  assert.throws(()=>cleanInput({...request,candidates:Array(37).fill(candidate)}));
  assert.throws(()=>cleanInput({...request,candidates:[{...candidate,minutes:0}]}));
});
