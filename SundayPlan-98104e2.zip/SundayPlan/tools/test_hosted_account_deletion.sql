-- Run in the Sunday Plan SQL Editor after installing the account-deletion migration.
-- Both identities are generated here. All fixture changes roll back.
begin;

do $test$
declare
  student uuid := gen_random_uuid();
  other_student uuid := gen_random_uuid();
  returning_student uuid := gen_random_uuid();
  address text := 'sunday-plan-qa-' || student || '@example.invalid';
  rpc regprocedure := 'public.delete_my_sunday_plan_account()'::regprocedure;
begin
  if not has_function_privilege('authenticated', rpc, 'execute')
     or has_function_privilege('anon', rpc, 'execute') then
    raise exception 'Unexpected function permissions';
  end if;

  insert into auth.users (id, email, aud, role) values
    (student, address, 'authenticated', 'authenticated'),
    (other_student, 'sunday-plan-qa-' || other_student || '@example.invalid', 'authenticated', 'authenticated');
  insert into public.student_plans (user_id, payload) values
    (student, '{"step":"disposable"}'),
    (other_student, '{"step":"control"}');

  perform set_config('request.jwt.claim.sub', student::text, true);
  execute 'set local role authenticated';
  if auth.uid() is distinct from student then
    raise exception 'Unexpected test identity';
  end if;
  perform public.delete_my_sunday_plan_account();
  execute 'reset role';

  if exists (select 1 from auth.users where id = student)
     or exists (select 1 from public.student_plans where user_id = student) then
    raise exception 'Deleted account or plan still exists';
  end if;
  if not exists (select 1 from auth.users where id = other_student)
     or not exists (select 1 from public.student_plans where user_id = other_student and payload->>'step' = 'control') then
    raise exception 'Control student or saved plan changed';
  end if;

  insert into auth.users (id, email, aud, role)
    values (returning_student, address, 'authenticated', 'authenticated');
  if exists (select 1 from public.student_plans where user_id = returning_student) then
    raise exception 'The new identity inherited a plan';
  end if;
end;
$test$;

rollback;
select 'PASS: account and plan removed; control intact; same email starts fresh; test rolled back.' as hosted_verification;
