"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

function accountFixture() {
  const root = {innerHTML:""}, events = {}, drafts = new Map(), saved = new Map(), requests = [];
  const location = {hash:"#signin", origin:"http://localhost:4173", pathname:"/"};
  const config = {mode:"cloud", url:"https://project.example", key:"public-test"};
  const storage = {getItem:k=>drafts.get(k), setItem:(k,v)=>drafts.set(k,v), removeItem:k=>drafts.delete(k)};
  const auth = {
    onAuthStateChange:callback=>{ events.auth=callback; },
    getSession:async()=>({data:{session:auth.session}}),
    getUser:async()=>({data:{user:auth.session?.user}}),
    signOut:async()=>{auth.session=null; return {};},
  };
  const table = {select:()=>table,eq:(_field,id)=>({maybeSingle:async()=>({data:saved.get(id)})})};
  const window = {SUNDAY_CONFIG:config, addEventListener:(name,fn)=>{events[name]=fn;},
    claude:{use:async()=>({})}, supabase:{createClient:()=>({auth,from:()=>table})}};
  const document = {getElementById:()=>root, querySelector:()=>null, createElement:()=>({}),
    head:{appendChild:node=>node.onload()}, addEventListener:(name,fn)=>{events[name]=fn;}};
  const fixture = {root,events,auth,saved,drafts,requests,location,document,deny:false};
  const context = vm.createContext({window,document,location,sessionStorage:storage,localStorage:storage,
    history:{replaceState:(_state,_title,hash)=>{location.hash=hash;}},
    setTimeout:queueMicrotask,clearTimeout:()=>{},structuredClone,AbortSignal,
    fetch:async (url,options)=>{
      if (url==="data/curated.json") return {ok:true,json:async()=>({listings:[],meta:{}})};
      assert.equal(url, config.url+"/rest/v1/rpc/delete_my_sunday_plan_account");
      requests.push({token:options.headers.Authorization,body:options.body});
      if (fixture.deny) return {ok:false};
      saved.delete(auth.session.user.id);
      return {ok:true};
    }});
  const run=code=>vm.runInContext(code,context);
  const load=file=>run(fs.readFileSync(path.join(__dirname,"../app/js",file),"utf8"));
  load("03-state.js"); load("plan-sync.js");
  run('let ui={},downloads; const freshUI=()=>({}),sectionFromUrl=()=>"week",esc=String,build=()=>[],loadCatalog=()=>{},render=()=>{},clean=x=>x,toast=()=>{};');
  load("account.js");
  const click=action=>events.click({target:{closest:()=>({dataset:{account:action}})}});
  const login=async id=>{
    auth.session=id ? {user:{id,email:"student@example.invalid",user_metadata:{given_name:"Student"}},access_token:"test-"+id} : null;
    events.auth(id ? "SIGNED_IN" : "SIGNED_OUT",auth.session);
    await new Promise(resolve=>setImmediate(resolve));
  };
  return Object.assign(fixture, {run, click, login, draft:id=>"sp-draft:"+config.url+":"+id});
}

test("login and create-account pages restore the right student and keep fresh onboarding empty", async () => {
  const app=accountFixture();
  await app.run("sundayAccount.start()"); await app.login(null);
  assert.match(app.root.innerHTML,/Log in to Sunday Plan/);
  app.location.hash="#signup"; app.events.hashchange();
  assert.match(app.root.innerHTML,/Create your account/);
  app.saved.set("returning",{revision:1,payload:{profile:{setup:true,name:"Returning"},plan:{club:{status:"planned"}}}});
  await app.login("returning");
  assert.equal(app.run('state.plan.club.status'),"planned");
  assert.equal(app.location.hash,"#week");
  await app.click("logout");
  assert.match(app.root.innerHTML,/Log in to Sunday Plan/);
  await app.login("new");
  assert.equal(app.run("state.profile.setup"),false);
  assert.equal(app.run("Object.keys(state.plan).length"),0);
});

test("only confirmed deletion clears the student's draft and returns to signup, and a failed deletion is retryable", async () => {
  const app=accountFixture();
  await app.run("sundayAccount.start()");
  app.saved.set("first",{revision:1,payload:{profile:{setup:true},plan:{club:{status:"planned"}}}});
  await app.login("first");
  await app.click("delete");
  assert.equal(app.requests.length,0);
  for (const key of [app.draft("first"),app.draft("first")+":conflict-backup",app.draft("other")]) app.drafts.set(key,"test-draft");
  app.run("ui.confirmReset=true"); app.deny=true;
  await app.click("delete");
  assert.match(app.run("ui.resetError"),/try again/i);
  assert.equal(app.run("state.plan.club.status"),"planned");
  assert.ok(app.drafts.has(app.draft("first")));
  app.deny=false; await app.click("delete");
  assert.deepEqual(app.requests,[{token:"Bearer test-first",body:"{}"},{token:"Bearer test-first",body:"{}"}]);
  assert.equal(app.auth.session,null);
  assert.equal(app.drafts.has(app.draft("first")),false);
  assert.equal(app.drafts.has(app.draft("first")+":conflict-backup"),false);
  assert.ok(app.drafts.has(app.draft("other")));
  assert.equal(app.location.hash,"#signup");
  assert.match(app.root.innerHTML,/account and saved plan were deleted/);
  await app.login("fresh-id-same-email");
  assert.equal(app.run("state.profile.setup"),false);
  assert.equal(app.run("Object.keys(state.plan).length"),0);
});

test("email sign-up asks for name, email and password, and tells the student to confirm by email", async () => {
  const app=accountFixture();
  const calls=[];
  app.auth.signUp=async arg=>{calls.push(["signUp",arg]); return {data:{user:{identities:[{}]},session:null},error:null};};
  app.auth.signInWithPassword=async arg=>{calls.push(["signIn",arg]); return {error:{message:"Invalid login credentials"}};};
  await app.run("sundayAccount.start()"); await app.login(null);
  app.location.hash="#signup"; app.events.hashchange();
  assert.match(app.root.innerHTML,/name="name"[\s\S]*name="email"[\s\S]*name="password"/);
  const message={textContent:"",classList:{toggle(){}}};
  app.document.querySelector=()=>message;
  const submit=(kind,values)=>app.events.submit({preventDefault(){},target:{closest:()=>({dataset:{authForm:kind},elements:Object.fromEntries(Object.entries(values).map(([k,v])=>[k,{value:v}]))})}});
  submit("signup",{name:"Ada Lovelace",email:"ada@wsu.edu",password:"short"});
  assert.match(message.textContent,/at least 8/);
  assert.equal(calls.length,0);
  submit("signup",{name:"Ada Lovelace",email:"ada@wsu.edu",password:"longenough1"});
  await new Promise(r=>setImmediate(r));
  assert.equal(calls[0][1].options.data.given_name,"Ada");
  assert.match(message.textContent,/Check ada@wsu\.edu for a confirmation link/);
  submit("signin",{email:"ada@wsu.edu",password:"wrong"});
  await new Promise(r=>setImmediate(r));
  assert.match(message.textContent,/don’t match/);
});
