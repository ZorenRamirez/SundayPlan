import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import refresh_catalog as refresh


class CatalogRefreshTest(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.data = Path(folder.name)
        self.dest = self.data / "current.json"
        self.previous = {
            "meta": {"builtAt": "2020-01-01"},
            "clubs": [{"u": "old-club"}], "events": [{"u": "old-event"}],
            "jobs": [{"id": "stripe-old"}, {"id": "robinhood-old"}],
        }
        self.dest.write_text(json.dumps(self.previous))
        for attribute, value in (("DATA", self.data), ("DEST", self.dest)):
            scoped = patch.object(refresh, attribute, value)
            scoped.start()
            self.addCleanup(scoped.stop)

    def run_refresh(self, responder):
        with patch.object(refresh, "fetch", side_effect=responder):
            with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
                refresh.main()

    def test_all_sources_unavailable_preserves_the_exact_existing_file(self):
        before = self.dest.read_bytes()
        def fail(_url):
            raise OSError("test offline")
        with self.assertRaisesRegex(SystemExit, "Previous snapshot retained"):
            self.run_refresh(fail)
        self.assertEqual(self.dest.read_bytes(), before)

    def test_partial_refresh_keeps_failed_board_and_campus_dates(self):
        def respond(url):
            if "/stripe/" in url:
                return {"jobs": []}
            if url.endswith("/events"):
                return []
            if url.endswith("/organizations"):
                return [{"name": "missing source identifier"}]
            raise OSError("fixture source unavailable")
        self.run_refresh(respond)
        result = json.loads(self.dest.read_text())
        self.assertEqual(result["clubs"], self.previous["clubs"])
        self.assertEqual(result["events"], self.previous["events"])
        self.assertEqual([j["id"] for j in result["jobs"]], ["robinhood-old"])
        self.assertEqual(result["meta"]["sourceDates"]["stripe"], refresh.TODAY)
        self.assertEqual(result["jobs"][0]["checked"], "2020-01-01")
        self.assertEqual(result["meta"]["sourceDates"]["events"], "2020-01-01")
        self.assertIn("events", result["meta"]["failedSources"])
        self.assertNotIn("stripe", result["meta"]["failedSources"])


if __name__ == "__main__":
    unittest.main()
