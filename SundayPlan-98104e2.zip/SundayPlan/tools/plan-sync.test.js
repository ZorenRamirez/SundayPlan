const test = require("node:test");
const assert = require("node:assert/strict");
const {createPlanSync, mergePlans} = require("../app/js/plan-sync");
function setup() {
  let row = null;
  const memory = new Map();
  const storage = {getItem: k => memory.get(k), setItem: (k,v) => memory.set(k,v), removeItem: k => memory.delete(k)};
  const read = async () => structuredClone(row);
  const write = async (base, payload) => {
    if (base !== (row?.revision || 0)) return null;
    row = {revision:base+1, payload:structuredClone(payload)};
    return row.revision;
  };
  function session(key = "student", extra = {}) {
    const statuses = [];
    const sync = createPlanSync({storage, key, read, write, onStatus:s=>statuses.push(s), active:()=>true, ...extra});
    return {...sync,statuses};
  }
  return {session,read,write,memory};
}
test("sign-out flush waits for a pending request and every subsequent edit", async () => {
  const db=setup(); let ready, release;
  const started = new Promise(r=>{ready=r;});
  const wait = new Promise(r=>{release=r;});
  const s=db.session("a",{write:async(base,payload)=>{ready();await wait;return db.write(base,payload);}});
  await s.load(); s.queue({name:"one"});const saving=s.flush(); await started;
  s.queue({name:"two"}); const logout=s.flush(); release(); await Promise.all([saving,logout]);
  assert.deepEqual(await db.read(),{revision:2,payload:{name:"two"}});assert.equal(s.statuses.at(-1),"synced");s.stop();
});
test("offline drafts restore only under the matching account key",async()=>{
  const db=setup();const s=db.session("a",{write:async()=>{throw Error("offline");}});
  await s.load();s.queue({plan:["pitch"]});await s.flush();s.stop();
  const other=db.session("b");assert.equal(await other.load(),null);other.stop();
  const restored=db.session("a");assert.deepEqual(await restored.load(),{plan:["pitch"]});
  await restored.flush();assert.equal((await db.read()).revision,1);restored.stop();
});
test("concurrent writers preserve the pending draft and the newer server version",async()=>{
  const db=setup();const a=db.session("tabA"),b=db.session("tabB");
  await Promise.all([a.load(),b.load()]);a.queue({pick:"A"});await a.flush();b.queue({pick:"B"});await b.flush();
  assert.equal(b.statuses.at(-1),"conflict");assert.equal((await db.read()).payload.pick,"A");
  assert.deepEqual(await b.useRemote(),{pick:"A"});assert.equal(JSON.parse(db.memory.get("tabB:conflict-backup")).payload.pick,"B");
  a.stop();b.stop();
});
test("a retry recognizes a committed write even if JSONB reordered the object",async()=>{
  const db=setup();let lost=true;
  const s=db.session("a",{write:async(base,payload)=>{
    if(lost){lost=false;await db.write(base,{b:payload.b,a:payload.a});throw Error("response lost");}
    return db.write(base,payload);
  }});
  await s.load();s.queue({a:1,b:[2,3]});await s.flush();assert.equal(s.statuses.at(-1),"offline");
  await s.flush();assert.equal(s.statuses.at(-1),"synced");assert.equal((await db.read()).revision,1);s.stop();
});
test("two stale sessions merge independent edits instead of conflicting", async () => {
  const db = setup(), merged = [];
  const opts = {merge: mergePlans, onMerged: p => merged.push(p)};
  const a = db.session("a", opts), b = db.session("b", opts);
  await a.load(); await b.load();
  a.queue({plan: {one: "planned"}, time: 60}); await a.flush();
  b.queue({plan: {two: "planned"}, time: 60}); await b.flush();
  assert.deepEqual((await db.read()).payload, {plan: {one: "planned", two: "planned"}, time: 60});
  assert.equal(b.statuses.at(-1), "synced");
  assert.deepEqual(merged.at(-1), {plan: {one: "planned", two: "planned"}, time: 60});
  const step = status => ({status});
  a.queue({plan: {one: step("planned")}, time: 60}); await a.flush();
  b.queue({plan: {one: step("planned")}, time: 60}); await b.flush();
  a.queue({plan: {one: step("done")}, time: 60}); await a.flush();
  b.queue({plan: {one: step("skipped")}, time: 60}); await b.flush();
  assert.equal((await db.read()).payload.plan.one.status, "done", "finished stays finished");
  a.stop(); b.stop();
});
test("without a merge function a stale session still reports a conflict", async () => {
  const db = setup(); const a = db.session("a"), b = db.session("b");
  await a.load(); await b.load();
  a.queue({one: 1}); await a.flush(); b.queue({two: 2}); await b.flush();
  assert.equal(b.statuses.at(-1), "conflict");
});
