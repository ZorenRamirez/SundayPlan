BOARDS = {"robinhood": "Robinhood", "allworthfinancial": "Allworth Financial", "stripe": "Stripe", "coinbase": "Coinbase", "databricks": "Databricks", "airbnb": "Airbnb",
 "pinterest": "Pinterest", "lyft": "Lyft", "figma": "Figma", "roblox": "Roblox", "tanium": "Tanium", "affirm": "Affirm", "brex": "Brex", "carta": "Carta", "gusto": "Gusto",
 "point72": "Point72", "imc": "IMC Trading", "drweng": "DRW", "akunacapital": "Akuna Capital", "spacex": "SpaceX", "cloudflare": "Cloudflare", "datadog": "Datadog",
 "mongodb": "MongoDB", "duolingo": "Duolingo"}
