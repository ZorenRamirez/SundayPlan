// Catalog safeguards in app/js/04-feed-builder.js, checked with the shipped data and the
// Nov 23 finance first-year. Run with: node --test tools/catalog-quality.test.js
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const root = path.resolve(__dirname, "..");
process.env.TZ = "America/Los_Angeles";
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

// A fresh copy of the app's own code and data for each test. `meta` overrides the catalog's
// freshness record; `jobDates` stamps a check date on every job from the named boards.
function fixture({ meta = {}, jobDates = {}, interests = ["career", "scholarship", "club"] } = {}) {
  const feeds = Object.fromEntries(
    ["clubs", "events", "jobs", "feed"].map((k) => [k, JSON.parse(read("app/data/" + k + ".json"))]),
  );
  for (const j of feeds.jobs) {
    const board = String(j.id).split("-", 1)[0];
    if (board in jobDates) j.checked = jobDates[board];
  }
  const context = vm.createContext({
    window: { __NOW: "2026-11-23T10:30:00" },
    document: { addEventListener() {} },
    URLSearchParams, calendarFile: require("../app/js/ical"),
    raw: JSON.parse(read("local-data/seed.json")).docs,
    feeds,
    metaOverride: meta,
    interests,
  });
  const run = (code) => vm.runInContext(code, context);
  for (const file of fs.readdirSync(path.join(root, "app/js")).filter((n) => /^0[1-9]-|^10-/.test(n)).sort())
    vm.runInContext(read("app/js/" + file), context, { filename: file });
  run(`CUR = Object.entries(raw).filter(([k]) => k.startsWith("listings/")).map(([k,v]) => ({...v, id:k.slice(9)}));
    const baseMeta = {...feeds.feed, ...metaOverride};
    for (const k of Object.keys(baseMeta)) if (baseMeta[k] === null) delete baseMeta[k];
    FEEDS = {clubs:feeds.clubs, events:feeds.events, jobs:feeds.jobs, meta:baseMeta}; LIST = build();
    Object.assign(state.profile, {setup:true, name:"Test", grad:2030, year:1, major:"Finance",
      interests, time:120, where:"pullman"});
    const byId = id => LIST.find(o => o.id === id);
    const ids = list => list.map(x => x.o.id);
    const ALL = Object.keys(TYPES);`);
  return run;
}
test("the Profile support-group toggle updates suggestions and retires the old ranking", async () => {
  const run = fixture({ interests: ["event", "club"] });
  run(`let onClick;
    document.querySelector = () => null;
    document.addEventListener = (type, fn) => { if (type === "click") onClick = fn; };
    window.addEventListener = () => {};
    let saved = 0;
    function save() { saved++; }
    function render() {}`);
  run(read("app/js/12-actions.js"));
  const toggle = () => run('onClick({target:{closest: () => ({dataset:{act:"supportgroups"}})}})');
  const markup = () => run("profileFields()");
  assert.match(markup(), /aria-pressed="false" data-act="supportgroups"/);
  const original = run("rankingSignature()");
  await toggle();
  assert.match(markup(), /aria-pressed="true" data-act="supportgroups"/);
  assert.notEqual(run("rankingSignature()"), original);
  assert.equal(run("candidates().some(x => x.o.support)"), true);
  await toggle();
  assert.equal(run("candidates().some(x => x.o.support)"), false);
  assert.equal(run("saved"), 2);
});
const RECOVERY = ["ev-mental-well-meeting-45", "ev-art-pizza-night-71", "ev-mindful-fiber-arts-44"];

test("Nov 23 finance first-year: no recovery or support group is suggested, with any interests", () => {
  for (const interests of [["career", "scholarship", "club"], null]) {
    const run = fixture();
    if (!interests) run("state.profile.interests = ALL");
    assert.equal(run("picks().length > 0"), true);
    assert.equal(run("candidates().some(x => x.o.support)"), false);
    assert.equal(run("picks().some(x => x.o.support || x.o.outdated)"), false);
    for (const id of RECOVERY) assert.equal(run('ids(candidates()).includes("' + id + '")'), false, id);
  }
});

test("support groups stay in the list, in search and in Coming up", () => {
  const run = fixture({ interests: ["career", "scholarship", "club", "event"] });
  for (const id of RECOVERY) {
    assert.equal(run('byId("' + id + '").support'), true, id);
    assert.equal(run('upcoming(true).some(x => x.o.id === "' + id + '")'), true, id);
  }
  run('ui.q = "mental well"; RES = {pred:null, plain:false, you:null}');
  assert.equal(run('found().some(x => (x.o || x).id === "ev-mental-well-meeting-45")'), true);
  assert.equal(run('eligible(byId("ev-mental-well-meeting-45"))'), true);
  assert.equal(run('stepIndex(byId("ev-mental-well-meeting-45"))'), 0);
});

test("the opt-in is read live and does not carry over to another student", () => {
  const run = fixture();
  run("state.profile.interests = ALL");
  const suggested = () => run("candidates().some(x => x.o.support)");
  assert.equal(suggested(), false);
  run("state.profile.supportGroups = true"); // no rebuild of LIST
  assert.equal(suggested(), true);
  assert.equal(run('byId("ev-mental-well-meeting-45").nopick'), false);
  run('state = adopt({profile:{setup:true, major:"Finance", year:1, grad:2030, interests:ALL, time:120}})');
  assert.equal(suggested(), false);
  run("state = adopt({profile:{...state.profile, supportGroups:true}})");
  assert.equal(run("state.profile.supportGroups"), true, "the setting survives adopt()");
  assert.equal(suggested(), true);
});

test("with the opt-in off, For you lists and dates hide support groups but browse, search and saved dates keep them", () => {
  const run = fixture({ interests: ["career", "scholarship", "club", "event"] });
  run("state.profile.interests = ALL");
  const forYou = () => {
    run('ui.all = false; ui.q = ""; RES = {pred:null, plain:true, you:youPred}');
    return run("found().some(x => x.o.support)");
  };
  const ids = (all) => run("upcoming(" + all + ").filter(x => x.o.support).map(x => x.o.id)");
  assert.equal(forYou(), false);
  assert.equal(ids(false).length, 0);
  assert.notEqual(ids(true).length, 0, "Everything on campus still lists them");
  run('ui.all = true; RES = {pred:null, plain:true, you:null}');
  assert.equal(run("found().some(x => x.o.support)"), true, "Browse all still lists them");
  run('ui.all = false; ui.q = "mental well"');
  assert.equal(run('found().some(x => x.o.id === "ev-mental-well-meeting-45")'), true, "search still finds them");
  run('state.plan["ev-mental-well-meeting-45:0"] = {status:"planned", day:"2026-11-24"}');
  assert.equal(run('upcoming(false).some(x => x.o.id === "ev-mental-well-meeting-45")'), true, "saved dates stay");
  for (const status of ["done", "skipped"]) {
    run('state.plan["ev-mental-well-meeting-45:0"] = {status:"' + status + '"}');
    assert.equal(run('upcoming(false).some(x => x.o.id === "ev-mental-well-meeting-45")'), false, status + " does not bypass the opt-out");
  }
  run('state.plan = {}; state.profile.supportGroups = true');
  assert.equal(forYou(), true);
  assert.notEqual(ids(false).length, 0);
});

test("the support-group match is narrow, and never sets off deadline nudges", () => {
  const run = fixture();
  const is = (...t) => run("isSupportGroup(..." + JSON.stringify(t) + ")");
  for (const t of ["Grief support group", "Students in recovery meet weekly", "Peer support circle", "Sober tailgate", "Harm reduction and naloxone hours"])
    assert.equal(is(t), true, t);
  for (const t of ["Disaster recovery planning workshop", "Supporting first-year students", "Finance Club", "Stress relief yoga", "Mindfulness Club", "Supply drive for survivors"])
    assert.equal(is(t), false, t);
  assert.equal(run('LIST.find(o => o.title === "The Crimson Group").support'), true);
  for (const title of ["Pet Your Stress Away", "ATVP Essentials Supply Drive Collection", "Crafternoons", "Mindfulness Club", "Pre PT/OT Club at WSU"])
    assert.equal(run("LIST.filter(o => o.title === " + JSON.stringify(title) + ").some(o => o.support)"), false, title);
  assert.equal(run("LIST.filter(o => !o.src).some(o => o.support)"), false, "no hand-checked listing is flagged");
  assert.equal(run("LIST.filter(o => o.support).every(o => o.dates.every(d => !d.key))"), true);
  assert.equal(run("LIST.filter(o => o.support).length"), 13); // The Crimson Group and 12 Cougs for Recovery events
});

test("fraternity and sorority listings are never suggested, opted in or not", () => {
  const run = fixture();
  run("state.profile.interests = ALL; state.profile.supportGroups = true");
  assert.equal(run('LIST.filter(o => o.org === "Fraternity or sorority").length > 0'), true);
  assert.equal(run('LIST.filter(o => o.org === "Fraternity or sorority").every(o => o.nopick)'), true);
});

test("a one-day-old catalog is not labeled", () => {
  const run = fixture();
  assert.equal(run("LIST.some(o => o.outdated)"), false);
  assert.match(run('byId("ev-interview-prep-and-resume-workshop").steps[0].text'), /^Go: Tue, Dec 1/);
  assert.match(run('byId("fire-club").steps[0].text'), /^Go to a meeting/);
  assert.equal(run('byId("job-roblox-8072713").checked'), "2026-11-22");
  assert.deepEqual(JSON.parse(run("JSON.stringify(catalogStatus())")), {
    clubs: { checked: "2026-11-22", days: 1, stale: false },
    events: { checked: "2026-11-22", days: 1, stale: false },
    jobs: { total: 73, outdated: 0 },
    failedSources: [],
  });
});

test("events from a source that has not refreshed are labeled and not suggested", () => {
  const run = fixture({ meta: { sourceDates: { clubs: "2026-11-22", events: "2026-11-18" }, failedSources: ["events"] } });
  run("state.profile.interests = ALL; const e = byId('ev-interview-prep-and-resume-workshop')");
  assert.equal(run("e.outdated && e.nopick && e.verify === 'secondary'"), true);
  assert.equal(run("e.checked"), "2026-11-18");
  assert.match(run("e.steps[0].text"), /^Confirm on the event page that this is still on, then go: Tue, Dec 1, 3 pm/);
  assert.equal(run("e.steps[0].event"), 0);
  assert.match(run("e.note"), /last checked Nov 18/);
  assert.equal(run("candidates().some(x => x.o.id.startsWith('ev-'))"), false);
  assert.equal(run("upcoming(true).some(x => x.o.id === e.id)"), true);
  assert.equal(run("LIST.filter(o => !o.id.startsWith('ev-')).some(o => o.outdated)"), false, "only events are affected");
  assert.match(run('byId("fire-club").steps[0].text'), /^Go to a meeting/);
  assert.equal(run("catalogStatus().events.stale && catalogStatus().events.days === 5"), true);
  assert.deepEqual(JSON.parse(run("JSON.stringify(catalogStatus().failedSources)")), ["events"]);
});

test("the limit is exact: three days old is current, four is out of date", () => {
  assert.equal(fixture({ meta: { sourceDates: { clubs: "2026-11-22", events: "2026-11-20" } } })("LIST.some(o => o.outdated)"), false);
  assert.equal(fixture({ meta: { sourceDates: { clubs: "2026-11-22", events: "2026-11-19" } } })("LIST.some(o => o.outdated)"), true);
});

test("old club data turns meeting times back into confirmation steps", () => {
  const run = fixture({ meta: { sourceDates: { clubs: "2026-11-01", events: "2026-11-22" } } });
  for (const id of ["fire-club", "mis-club"]) {
    assert.equal(run('byId("' + id + '").steps.some(s => /^Go to a meeting/.test(s.text))'), false, id);
    assert.equal(run('byId("' + id + '").steps[0].ask'), true, id);
    assert.match(run('byId("' + id + '").note'), /was last checked Nov 1\. Confirm it before you go\./);
  }
  assert.equal(run("LIST.filter(o => o.id.startsWith('org-')).every(o => o.outdated && o.steps[0].ask && /last checked Nov 1/.test(o.note))"), true);
  assert.equal(run("LIST.some(o => /^Go to a meeting/.test(o.steps[0]?.text || ''))"), false);
  assert.equal(run("LIST.filter(o => o.id.startsWith('ev-')).some(o => o.outdated)"), false);
  assert.equal(run("picks().length > 0"), true, "asking is still a safe suggestion");
});

test("each employer board is judged by its own check date", () => {
  const run = fixture({ jobDates: { roblox: "2026-11-10" } });
  run("state.profile.interests = ALL; state.profile.year = 3; const old = LIST.filter(o => o.id.startsWith('job-roblox-'))");
  assert.equal(run("old.length > 0 && old.every(o => o.outdated && o.nopick && o.checked === '2026-11-10')"), true);
  assert.match(run("old[0].summary"), / · last checked Nov 10, may have closed$/);
  assert.match(run("old[0].note"), /may have closed/);
  assert.equal(run("LIST.filter(o => o.src === 'board' && !o.id.startsWith('job-roblox-')).some(o => o.outdated || o.nopick)"), false);
  assert.equal(run("candidates().some(x => x.o.id.startsWith('job-roblox-'))"), false);
  assert.equal(run("catalogStatus().jobs.outdated"), run("old.length"));
  // without a per-job date, the board's source date is used, then the build date
  const viaBoard = fixture({ meta: { sourceDates: { clubs: "2026-11-22", events: "2026-11-22", duolingo: "2026-11-09" } } });
  assert.equal(viaBoard("LIST.filter(o => o.id.startsWith('job-duolingo-')).every(o => o.outdated && o.checked === '2026-11-09')"), true);
  assert.equal(viaBoard("LIST.filter(o => o.src === 'board' && !o.id.startsWith('job-duolingo-')).some(o => o.outdated)"), false);
});

test("a catalog with no check date is treated as out of date, and a future date as current", () => {
  const none = fixture({ meta: { builtAt: null } });
  none("state.profile.interests = ALL");
  assert.equal(none("LIST.filter(o => o.src).every(o => o.outdated)"), true);
  assert.match(none('byId("ev-interview-prep-and-resume-workshop").note'), /never date-checked/);
  assert.equal(none("candidates().some(x => x.o.src === 'board' || x.o.id.startsWith('ev-'))"), false);
  assert.equal(none("catalogStatus().events.days"), null);
  const ahead = fixture({ meta: { sourceDates: { clubs: "2026-11-25", events: "2026-11-25" } } });
  assert.equal(ahead("LIST.some(o => o.outdated)"), false);
  assert.equal(ahead("catalogStatus().events.days"), 0);
});

test("hand-checked listings are labeled when old, stay usable, and the cache is not changed", () => {
  const run = fixture();
  run(`CUR = CUR.map(o => o.id === "scholarship-app" ? {...o, checked:"2026-10-20"} : o);
    const before = JSON.stringify(CUR); LIST = build(); const after = JSON.stringify(CUR);
    const app = byId("scholarship-app");`);
  assert.equal(run("before === after"), true);
  assert.equal(run("CUR.some(o => Object.getOwnPropertyDescriptor(o, 'nopick') || 'outdated' in o || 'support' in o)"), false);
  assert.equal(run("app.outdated && !app.nopick"), true);
  assert.match(run("app.note"), /^The 2027–28 application moved to Scholarship Manager\. This listing was last checked Oct 20\./);
  assert.equal(run("ids(candidates()).includes('scholarship-app')"), true);
  assert.equal(run("LIST.filter(o => !o.src && o.id !== 'scholarship-app').some(o => o.outdated)"), false);
  assert.equal(run("LIST.length"), 646); // bundled directory and curated listings, including five WSU department listings
});
