"use strict";
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
function settings(env, allowLocal) {
  const url = env.SUPABASE_URL?.trim();
  const key = env.SUPABASE_PUBLISHABLE_KEY?.trim();
  if (!url && !key && allowLocal) return { mode: "local" };
  if (!url || !key || !key.startsWith("sb_publishable_") || !/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/.test(url))
    throw new Error("Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY to this project's HTTPS URL and public sb_publishable_ key.");
  if (/^https:\/\/(example|your-project|project-ref|placeholder|test)\.supabase\.co\/?$/.test(url) || /^sb_publishable_(test|example|placeholder|xxx)/.test(key))
    throw new Error("SUPABASE_URL or SUPABASE_PUBLISHABLE_KEY is a placeholder. Use the real project values; fake credentials must never be built into dist.");
  const googleClientId = env.GOOGLE_WEB_CLIENT_ID?.trim() || "";
  if (googleClientId && !/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/.test(googleClientId))
    throw new Error("GOOGLE_WEB_CLIENT_ID must be a public Google web client ID.");
  return { mode: "cloud", url: new URL(url).origin, key, googleClientId };
}
function curated() {
  const { docs } = JSON.parse(fs.readFileSync(path.join(root, "local-data/seed.json"), "utf8"));
  return { listings: Object.entries(docs).filter(([k]) => k.startsWith("listings/")).map(([k,v]) => ({...v,id:k.slice(9)})), meta: docs["meta/feed"] || null };
}
function configScript(config) { return "window.SUNDAY_CONFIG = " + JSON.stringify(config).replace(/</g, "\\u003c") + ";\n"; }
function loadEnv() {
  const file = path.join(root, ".env.local");
  if (fs.existsSync(file)) process.loadEnvFile(file);
}
module.exports = { settings, curated, configScript, loadEnv, root };
