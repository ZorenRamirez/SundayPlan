"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { settings } = require("./runtime");

test("normal account builds reject placeholder Supabase credentials before dist is touched", () => {
  assert.throws(() => settings({ SUPABASE_URL: "https://example.supabase.co", SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test" }, false), /placeholder/);
  assert.throws(() => settings({ SUPABASE_URL: "https://abcdefgh.supabase.co", SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test" }, false), /placeholder/);
  assert.throws(() => settings({ SUPABASE_URL: "https://example.supabase.co/", SUPABASE_PUBLISHABLE_KEY: "sb_publishable_real123" }, false), /placeholder/);
  assert.equal(settings({ SUPABASE_URL: "https://abcdefgh.supabase.co", SUPABASE_PUBLISHABLE_KEY: "sb_publishable_real123" }, false).mode, "cloud");
});
