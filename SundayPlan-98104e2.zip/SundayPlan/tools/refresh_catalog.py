"""Refresh public sources independently. Replace a single complete snapshot atomically."""
import concurrent.futures
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.request
from zoneinfo import ZoneInfo
from employer_boards import BOARDS

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "app" / "data"
DEST = DATA / "current.json"
WSU = "https://api.presence.io/wsu/v1/"
JOBS = "https://boards-api.greenhouse.io/v1/boards/"
TODAY = datetime.datetime.now(ZoneInfo("America/Los_Angeles")).date().isoformat()

def read(path):
    return json.loads(path.read_text())

def fetch(url):
    request = urllib.request.Request(url, headers={"User-Agent": "SundayPlan/0.1 (student opportunity planner)", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=15) as response:
        return json.load(response)

def validated(name, value):
    if name in BOARDS:
        if not isinstance(value, dict) or not isinstance(value.get("jobs"), list):
            raise ValueError("missing jobs array")
        rows = value["jobs"]
        fields = ("id", "title", "absolute_url")
    else:
        rows = value
        fields = ("uri", "name") if name == "clubs" else ("uri", "eventName", "startDateTimeUtc")
        if not isinstance(rows, list) or (name == "clubs" and not rows):
            raise ValueError("unexpected campus listing response")
    if any(not isinstance(row, dict) or not all(row.get(f) for f in fields) for row in rows):
        raise ValueError("listing record missing required fields")
    return value

def main():
    old = read(DEST) if DEST.exists() else {**{n:read(DATA / (n+".json")) for n in ("clubs","events","jobs")}, "meta":read(DATA / "feed.json")}
    dates = dict(old["meta"].get("sourceDates", {}))
    baseline = old["meta"]["builtAt"]
    urls = {"clubs": WSU+"organizations", "events": WSU+"events", **{b:JOBS+b+"/jobs" for b in BOARDS}}
    values, failed = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        pending = {pool.submit(fetch,url):name for name,url in urls.items()}
        for future in concurrent.futures.as_completed(pending):
            name = pending[future]
            try:
                values[name] = validated(name,future.result())
            except Exception as error:
                failed.append(name)
                print(name, type(error).__name__, "retaining previous records",file=sys.stderr)
    if not values:
        raise SystemExit("No source responded successfully. Previous snapshot retained.")
    with tempfile.TemporaryDirectory() as folder:
        tmp = Path(folder)
        for name,value in values.items():
            if name in BOARDS:
                (tmp/("gh_"+name+".json")).write_text(json.dumps(value))
        for source in ("clubs","events"):
            (tmp/(source+".raw")).write_text(json.dumps(values.get(source,[])))
        subprocess.run([sys.executable,str(ROOT/"tools/build_feed.py"),str(tmp/"clubs.raw"),str(tmp/"events.raw"),str(tmp),str(tmp)], check=True)
        clubs = read(tmp/"clubs.json") if "clubs" in values else old["clubs"]
        events_ok = "clubs" in values and "events" in values
        events = read(tmp/"events.json") if events_ok else old["events"]
        jobs = read(tmp/"jobs.json") + [j for j in old["jobs"] if j["id"].split("-",1)[0] not in values]
    if "clubs" in values: dates["clubs"] = TODAY
    if events_ok: dates["events"] = TODAY
    if "events" in values and not events_ok: failed.append("events")
    for name in BOARDS:
        dates[name] = TODAY if name in values else dates.get(name, baseline)
    for name in ("clubs","events"): dates.setdefault(name,baseline)
    refreshed = {k:len(v) for k,v in (("clubs",clubs),("events",events),("jobs",jobs))}
    meta = {**old["meta"], **refreshed,"builtAt":min(dates["clubs"],dates["events"]), "attemptedAt":TODAY, "sourceDates":dates, "failedSources":sorted(set(failed))}
    for job in jobs: job["checked"] = dates.get(job["id"].split("-",1)[0],baseline)
    snapshot = {"meta":meta,"clubs":clubs,"events":events,"jobs":jobs}
    with tempfile.NamedTemporaryFile(dir=DATA, mode="w", delete=False) as output:
        json.dump(snapshot,output,ensure_ascii=False,separators=(",",":"))
        name = output.name
    os.replace(name, DEST)
    print("Updated",len(values),"sources;",len(failed),"retained.",refreshed)

if __name__ == "__main__": main()
