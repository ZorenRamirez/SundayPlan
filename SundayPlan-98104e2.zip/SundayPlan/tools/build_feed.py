#!/usr/bin/env python3
"""Builds Sunday Plan's feed files from WSU's public club and event directory (WSU Involve / Presence).
Usage: python3 build_feed.py ORGS.json EVENTS.json OUTDIR [BOARDS_DIR]
ORGS/EVENTS are the raw responses of https://api.presence.io/wsu/v1/organizations and /events.
BOARDS_DIR holds gh_<token>.json files, each the raw response of https://boards-api.greenhouse.io/v1/boards/<token>/jobs"""
import json, re, html, sys, os, glob
from employer_boards import BOARDS
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
PAC = ZoneInfo("America/Los_Angeles")
orgs = json.load(open(sys.argv[1], encoding="utf-8")); events = json.load(open(sys.argv[2], encoding="utf-8")); out = sys.argv[3]
def text(s):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()
def brief(s, n=190):
    s = text(s)
    if len(s) <= n: return s
    cut = s[:n]
    m = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
    return cut[:m + 1] if m > 80 else cut[:cut.rfind(" ")].rstrip(",;:") + "…"
ALIAS = {"international-business-ibus-club": "intl-business-club", "fire-finance-insurance-and-real-estate-club": "fire-club", "beta-alpha-psi": "beta-alpha-psi",
 "alpha-kappa-psi": "alpha-kappa-psi", "innovation-and-change-club": "innovation-change-club", "marketing-club-at-wsu": "marketing-club", "mis-club-at-wsu": "mis-club",
 "people-in-the-workplace-pw-club": "pw-club", "pullman-vita-at-wsu": "vita-club", "sales-club-at-wsu": "sales-club",
 "school-of-hospitality-business-management-ambassadors-shbm": "shbm-ambassadors", "sigma-iota-pullman": "sigma-iota", "women-in-business-at-wsu": "women-in-business"}
SKIP_ORG = ("* Department", "* Residence Life Organization")
cats = {}
clubs = []
for o in orgs:
    c = o.get("categories") or []; cats[o.get("uri")] = c
    if not o.get("name") or not o.get("uri") or any(k in c for k in SKIP_ORG): continue
    kind = "greek" if "* Fraternity or Sorority Organization" in c else "sport" if any("Sports Club" in k for k in c) else "club"
    clubs.append({"u": o["uri"], "n": text(o["name"])[:120], "d": brief(o.get("description")), "t": text(o.get("regularMeetingTime"))[:80], "l": text(o.get("regularMeetingLocation"))[:80],
                  "c": [k for k in c if not k.startswith("*") and k != "Involve Finance"][:4], "m": int(o.get("memberCount") or 0), "e": bool(o.get("hasUpcomingEvents")),
                  "k": kind, "g": "Graduate" in c, "a": ALIAS.get(o["uri"], "")})
now = datetime.now(timezone.utc) - timedelta(hours=6)
evs = []
for e in events:
    try: st = datetime.fromisoformat(e["startDateTimeUtc"].replace("Z", "+00:00"))
    except Exception: continue
    if st < now or not e.get("eventName") or not e.get("uri"): continue
    c = cats.get(e.get("organizationUri"), [])
    if "* Residence Life Organization" in c: continue          # hall-only socials
    tags = e.get("tags") or []
    if any("Fraternity Sorority" in t for t in tags): continue  # chapter-internal programming
    try: en = datetime.fromisoformat(e["endDateTimeUtc"].replace("Z", "+00:00"))
    except (ValueError, KeyError, TypeError, AttributeError): en = None
    ls, le = st.astimezone(PAC), en.astimezone(PAC) if en and en > st else None
    evs.append({"u": e["uri"], "n": text(e["eventName"])[:120], "d": brief(e.get("description"), 170), "date": ls.strftime("%Y-%m-%d"), "s": ls.strftime("%H:%M"),
                "e": le.strftime("%H:%M") if le else "", "endDate": le.date().isoformat() if le and le.date() != ls.date() else "", "l": text(e.get("location"))[:90], "o": text(e.get("organizationName"))[:90],
                "ou": e.get("organizationUri") or "", "tags": tags[:4], "greek": "* Fraternity or Sorority Organization" in c, "g": "Graduate" in c or bool(re.search(r"\bgraduate\b|\bgpsa\b", text(e.get("organizationName")) + " " + text(e["eventName"]), re.I))})
evs.sort(key=lambda x: (x["date"], x["s"]))
evs = evs[:400]

INTERN = re.compile(r"\bintern(ship)?s?\b|\bco-?op\b|summer analyst|early insight|explore program|discover(y)? program", re.I)
US = re.compile(r"united states|\busa?\b|remote|, (AL|AK|AZ|AR|CA|CO|CT|DC|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NC|ND|NE|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY)\b|new york|san francisco|seattle|chicago|austin|boston|los angeles|bellevue|redmond|mountain view|palo alto", re.I)
jobs = []
if len(sys.argv) > 4:
    for path in sorted(glob.glob(os.path.join(sys.argv[4], "gh_*.json"))):
        token = os.path.basename(path)[3:-5]
        try: data = json.load(open(path, encoding="utf-8")).get("jobs", [])
        except Exception: continue
        mine = []
        for j in data:
            title = text(j.get("title")); loc = text((j.get("location") or {}).get("name")); url = j.get("absolute_url") or ""
            if not INTERN.search(title) or re.search(r"\bph\.?d\b|\bmba\b|graduate|master|postdoc|doctoral", title, re.I) or not url.startswith("https://") or not US.search(loc): continue
            mine.append({"id": token + "-" + str(j.get("id")), "n": title[:130], "o": BOARDS.get(token, token.title()), "l": loc[:80], "url": url, "up": (j.get("updated_at") or "")[:10]})
        mine.sort(key=lambda x: x["up"], reverse=True)
        jobs += mine[:10]
jobs.sort(key=lambda x: x["up"], reverse=True)
today = datetime.now(PAC).strftime("%Y-%m-%d")
json.dump(jobs, open(out + "/jobs.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
json.dump(clubs, open(out + "/clubs.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
json.dump(evs, open(out + "/events.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
json.dump({"builtAt": today, "clubs": len(clubs), "events": len(evs), "jobs": len(jobs), "source": "WSU Involve (wsu.presence.io) and employer career pages"}, open(out + "/feed.json", "w", encoding="utf-8"))
print(len(clubs), "clubs", len(evs), "events", len(jobs), "jobs", today)
