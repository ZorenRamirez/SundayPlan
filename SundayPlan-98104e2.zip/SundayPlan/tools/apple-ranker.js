"use strict";
const {spawn} = require("node:child_process");
const fs = require("node:fs/promises");
const path = require("node:path");
const {promisify} = require("node:util");
const execFile = promisify(require("node:child_process").execFile);
const root = path.resolve(__dirname, "..");
const cache = path.join(root, ".plan-runtime");
const binary = path.join(cache, "weekly-ranker");
const source = path.join(root, "native/WeeklyRanker.swift");
let compiling;
function prepare() {
  if (compiling) return compiling;
  compiling = (async () => {
    const built = await fs.stat(binary).catch(() => null);
    if (built && built.mtimeMs >= (await fs.stat(source)).mtimeMs) return;
    await fs.mkdir(cache, {recursive:true});
    const target = binary + "." + process.pid;
    try {
      await execFile("/usr/bin/xcrun", ["swiftc", "-parse-as-library", "-module-cache-path", path.join(cache,"modules"), source, "-o", target], {timeout:90000});
      await fs.rename(target, binary);
    } finally { await fs.rm(target,{force:true}); }
  })().finally(() => { compiling = undefined; });
  return compiling;
}
function cleanInput(body) {
  if (!body || typeof body.intent !== "string" || body.intent.length > 160 || typeof body.preferences !== "string" || body.preferences.length > 720 ||
      !Number.isInteger(body.remaining) || body.remaining < 0 || body.remaining > 600 ||
      !Array.isArray(body.candidates) || !body.candidates.length || body.candidates.length > 36) throw Error("input");
  const text = (s,max) => typeof s === "string" && s.length > 0 && s.length <= max;
  const candidates = body.candidates.map(c => {
    if (!c || !text(c.title,160) || !text(c.kind,45) || typeof c.summary !== "string" || c.summary.length > 180 || !text(c.step,320) ||
        !Number.isInteger(c.minutes) || c.minutes < 1 || c.minutes > 600 ||
        !Array.isArray(c.reasons) || !c.reasons.length || c.reasons.length > 5 || !c.reasons.every(r=>text(r,160))) throw Error("input");
    return {title:c.title,summary:c.summary,kind:c.kind,step:c.step,minutes:c.minutes,reasons:c.reasons};
  });
  return {intent:body.intent,preferences:body.preferences, remaining:body.remaining, candidates};
}
async function rank(input) {
  await prepare();
  return new Promise((resolve,reject) => {
    const proc = spawn(binary, [], {stdio:["pipe","pipe","ignore"]});
    let text = "", done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const valid = text.split("\n").flatMap(line => {
        try {
          const result = JSON.parse(line);
          if (!["language","semantic"].includes(result.source) || !Array.isArray(result.picks)) return [];
          const seen = new Set();
          const picks = result.picks.filter(p => Number.isInteger(p?.index) && input.candidates[p.index] &&
            Number.isInteger(p.reason) && input.candidates[p.index].reasons[p.reason] && !seen.has(p.index) && seen.add(p.index));
          return picks.length ? [{source:result.source,picks}] : [];
        } catch { return []; }
      });
      if (valid.length) resolve(valid.at(-1)); else reject(Error("unavailable"));
    };
    const timer = setTimeout(() => { proc.kill(); finish(); }, 18000);
    proc.on("error", finish); proc.on("close",finish);
    proc.stdout.setEncoding("utf8");
    proc.stdout.on("data", chunk => { if (text.length < 10000) text += chunk; });
    proc.stdin.on("error", () => {});
    proc.stdin.end(JSON.stringify(input));
  });
}
module.exports = {cleanInput, prepare, rank};
