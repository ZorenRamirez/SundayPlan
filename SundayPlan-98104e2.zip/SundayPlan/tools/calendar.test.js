const {test} = require("node:test");
const assert = require("node:assert/strict");
const calendar = require("../app/js/ical");

const timed = {
  uid:"career-networking", title:"Career Networking Night", date:"2027-02-08",
  start:"16:30", end:"19:00", location:"CUB Senior Ballroom, Pullman",
};
test("Apple Calendar gets the posted local date and time, place and reminders", () => {
  const result = calendar.write([timed]);
  assert.match(result, /DTSTART;TZID=America\/Los_Angeles:20270208T163000/);
  assert.match(result, /DTEND;TZID=America\/Los_Angeles:20270208T190000/);
  assert.ok(result.includes("LOCATION:CUB Senior Ballroom\\, Pullman"));
  assert.match(result, /TRIGGER:-PT2H/);
  assert.ok(result.endsWith("END:VCALENDAR\r\n"));
});
test("prep is all-day on the chosen date, with an exclusive end at the following year boundary", () => {
  const result = calendar.write([{uid:"prep",title:"Write a résumé",date:"2026-12-31"}], 3);
  assert.match(result, /DTSTART;VALUE=DATE:20261231\r\nDTEND;VALUE=DATE:20270101/);
  assert.match(result, /TRIGGER:-PT63H/);
});
test("recurring meetings retain Pacific wall time and biweekly cadence across DST", () => {
  const result = calendar.write([{...timed, rrule:"FREQ=WEEKLY;INTERVAL=2;BYDAY=MO"}]);
  assert.match(result, /BEGIN:VTIMEZONE/);
  assert.match(result, /BYMONTH=3;BYDAY=2SU/);
  assert.match(result, /BYMONTH=11;BYDAY=1SU/);
  assert.match(result, /DTSTART;TZID=America\/Los_Angeles:20270208T163000/);
  assert.match(result, /RRULE:FREQ=WEEKLY;INTERVAL=2;BYDAY=MO/);
});
test("long international titles are folded on UTF-8 boundaries and plain-text line breaks stay in the description", () => {
  const title = "Fútbol ⚽ ".repeat(20);
  const result = calendar.write([{...timed, title, details:"One\r\nTwo; three, four"}]);
  assert.ok(result.split("\r\n").every(line=>Buffer.byteLength(line)<=75));
  assert.ok(result.replace(/\r\n /g,"").includes("SUMMARY:" + title));
  assert.ok(result.includes("DESCRIPTION:One\\nTwo\\; three\\, four"));
});
test("overnight and multi-day events retain their end date, and missing end times stay unspecified", () => {
  assert.match(calendar.write([{...timed,end:"00:15"}]), /DTEND;TZID=America\/Los_Angeles:20270209T001500/);
  assert.match(calendar.write([{...timed,endDate:"2027-02-10"}]), /DTEND;TZID=America\/Los_Angeles:20270210T190000/);
  assert.doesNotMatch(calendar.write([{...timed,end:""}]), /DTEND/);
});
test("invalid dates and recurrence text are rejected before a native calendar opens", () => {
  for (const item of [{date:"2027-02-30"},{start:"24:00"},{rrule:"FREQ=WEEKLY\r\nMETHOD:CANCEL"}])
    assert.throws(()=>calendar.write([{...timed,...item}]));
});
function calendarActionFixture(macCalendar, nativeAvailable) {
  const vm = require("node:vm");
  const fs = require("node:fs");
  const path = require("node:path");
  const calls = {native:0, downloads:[], messages:[]};
  const context = vm.createContext({
    window: {SUNDAY_CONFIG:{macCalendar}}, calendarFile:calendar, state:{remind:{lead:3}},
    Blob, URLSearchParams, downloads:{save: async file => calls.downloads.push(file)},
    toast: message => calls.messages.push(message), items:[timed],
    fetch: async (url, options) => {
      calls.native++;
      assert.equal(url, "/api/calendar/open");
      assert.equal(options.method, "POST");
      assert.deepEqual(JSON.parse(options.body), {items:[timed],lead:3});
      return {ok:nativeAvailable};
    },
  });
  vm.runInContext(fs.readFileSync(path.join(__dirname,"../app/js/07-calendar.js"),"utf8"), context);
  return {calls, add:()=>vm.runInContext('appleFile(items,"sunday-plan-event")', context)};
}
test("one button hands the selected event to the local Mac without an extra browser download", async () => {
  const fixture = calendarActionFixture(true, true);
  await fixture.add();
  assert.equal(fixture.calls.native, 1);
  assert.equal(fixture.calls.downloads.length, 0);
  assert.match(fixture.calls.messages[0], /Choose a calendar/);
});
test("hosted builds and unavailable native Calendar handoffs deliver an ordinary .ics file", async () => {
  for (const native of [false,true]) {
    const fixture = calendarActionFixture(native, false);
    await fixture.add();
    assert.equal(fixture.calls.native, native ? 1 : 0);
    const [file] = fixture.calls.downloads;
    assert.equal(file.filename, "sunday-plan-event.ics");
    assert.match(file.data.type, /^text\/calendar/);
    assert.match(await file.data.text(), /DTSTART;TZID=America\/Los_Angeles:20270208T163000/);
  }
});
