/*
  server.js — the tiny local server for Sunday Plan.

  Start it with:   npm start        (then open http://localhost:4173)
  Stop it with:    Ctrl + C in the Terminal window

  It does two jobs:
    1. Hands the files in the app/ folder to your browser (the pages, styles and scripts).
    2. Acts as the app's database: it reads and writes local-data/database.json
       whenever the app asks to load or save something.

  It uses only what comes with Node.js, so there is nothing to install.
  It only listens on your own computer (127.0.0.1); nobody else can reach it.
*/
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("node:os");
const { promisify } = require("node:util");
const execFile = promisify(require("node:child_process").execFile);
const calendarFile = require("./app/js/ical");
const appleRanker = require("./tools/apple-ranker");
const { spawn } = require("node:child_process");

const { settings, curated, configScript, loadEnv } = require("./tools/runtime");
loadEnv();
const runtime = { ...settings(process.env, true), macCalendar: process.platform === "darwin",
  onDeviceRanking: process.platform === "darwin" && process.arch === "arm64" };
const PORT = Number(process.env.PORT) || 4173;
const APP_DIR = path.join(__dirname, "app");
const DATA_DIR = process.env.SUNDAY_PLAN_DATA || path.join(__dirname, "local-data");
const SEED_FILE = path.join(__dirname, "local-data", "seed.json"); // starting data, never changed by the server
const DB_FILE = path.join(DATA_DIR, "database.json"); // the live local database

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
};

/* ---------- the database: one JSON file ---------- */

// Read the whole database. The first time, copy the starting data from seed.json.
function readDb() {
  if (!fs.existsSync(DB_FILE)) {
    const seed = JSON.parse(fs.readFileSync(SEED_FILE, "utf8"));
    writeDb({ docs: seed.docs || {} });
  }
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function writeDb(db) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2) + "\n");
}

// A document path looks like "listings/handshake" or "data/users/local-user/state":
// plain names separated by slashes. Documents have an even number of parts,
// collections (groups of documents) an odd number.
const SAFE_PATH = /^[A-Za-z0-9_.-]+(\/[A-Za-z0-9_.-]+)*$/;
const partsOf = (p) =>
  typeof p === "string" && SAFE_PATH.test(p) && !p.includes("..") ? p.split("/") : null;

function sendJson(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > 2 * 1024 * 1024) {
        reject(new Error("too large"));
        req.destroy();
      } else chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

async function handleApi(req, res, url) {
  const kind = url.pathname.slice("/api/db/".length); // "doc" or "collection"
  const docPath = url.searchParams.get("path");
  const parts = partsOf(docPath);
  if (!parts) return sendJson(res, 400, { error: "bad path" });

  if (kind === "collection" && req.method === "GET") {
    if (parts.length % 2 !== 1)
      return sendJson(res, 400, { error: "a collection path has an odd number of parts" });
    const db = readDb();
    const prefix = docPath + "/";
    const docs = Object.keys(db.docs)
      .filter((k) => k.startsWith(prefix) && !k.slice(prefix.length).includes("/"))
      .sort()
      .map((k) => ({ id: k.slice(prefix.length), data: db.docs[k] }));
    return sendJson(res, 200, { docs });
  }

  if (kind === "doc") {
    if (parts.length % 2 !== 0)
      return sendJson(res, 400, { error: "a document path has an even number of parts" });
    const db = readDb();
    if (req.method === "GET") {
      const exists = Object.prototype.hasOwnProperty.call(db.docs, docPath);
      return sendJson(res, 200, exists ? { exists: true, data: db.docs[docPath] } : { exists: false });
    }
    if (req.method === "PUT") {
      let data;
      try {
        data = JSON.parse(await readBody(req));
      } catch (e) {
        return sendJson(res, 400, { error: "the body must be JSON" });
      }
      if (!data || typeof data !== "object" || Array.isArray(data))
        return sendJson(res, 400, { error: "a document must be an object" });
      db.docs[docPath] = data;
      writeDb(db);
      console.log("saved  " + docPath);
      return sendJson(res, 200, { ok: true });
    }
    if (req.method === "DELETE") {
      delete db.docs[docPath];
      writeDb(db);
      console.log("deleted " + docPath);
      return sendJson(res, 200, { ok: true });
    }
  }
  return sendJson(res, 404, { error: "not found" });
}

/* ---------- the app's files ---------- */

function serveFile(req, res, url) {
  let rel;
  try {
    rel = decodeURIComponent(url.pathname);
  } catch (e) {
    res.writeHead(400);
    return res.end("Bad request");
  }
  if (rel.endsWith("/")) rel += "index.html";
  const file = path.join(APP_DIR, rel);
  // Never hand out anything outside the app/ folder.
  if (file !== APP_DIR && !file.startsWith(APP_DIR + path.sep)) {
    res.writeHead(403);
    return res.end("Not allowed");
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Not found");
    }
    // no-store: the browser always asks for the newest copy, so your edits show on reload.
    res.writeHead(200, {
      "Content-Type": TYPES[path.extname(file).toLowerCase()] || "application/octet-stream",
      "Cache-Control": "no-store",
    });
    res.end(data);
  });
}

async function openMacCalendar(req, res) {
  const host = req.headers.host;
  if (!runtime.macCalendar || !["localhost:" + PORT, "127.0.0.1:" + PORT].includes(host) ||
      req.headers.origin !== "http://" + host || req.method !== "POST" ||
      req.headers["content-type"]?.split(";")[0] !== "application/json")
    return sendJson(res, 403, {error:"Use Sunday Plan on this Mac to open Calendar."});

  let contents;
  try {
    const {items, lead} = JSON.parse(await readBody(req));
    contents = calendarFile.write(items, lead);
  } catch { return sendJson(res, 400, {error:"Invalid event details."}); }
  let dir;
  try {
    dir = await fs.promises.mkdtemp(path.join(os.tmpdir(), "sunday-plan-calendar-"));
    const file = path.join(dir, "Sunday Plan.ics");
    await fs.promises.writeFile(file, contents, {mode:0o600});
    await execFile("/usr/bin/open", ["-a", "/System/Applications/Calendar.app", file], {timeout:10000});
    sendJson(res, 200, {opened:true});
  } catch { sendJson(res, 503, {error:"Calendar could not open."}); }
  finally {
    if (dir) setTimeout(() => fs.promises.rm(dir, {recursive:true, force:true}).catch(() => {}), 600000).unref();
  }
}

let activeRankings = 0;
async function rankWeeklyPlan(req, res) {
  const host = req.headers.host;
  if (!runtime.onDeviceRanking) return sendJson(res,503,{error:"On-device ranking unavailable"});
  if (!["localhost:" + PORT, "127.0.0.1:" + PORT].includes(host) || req.headers.origin !== "http://" + host ||
      req.method !== "POST" || req.headers["content-type"]?.split(";")[0] !== "application/json")
    return sendJson(res,403,{error:"Open the planner on this Mac."});
  if (activeRankings >= 2) return sendJson(res,429,{error:"The planner is busy."});
  activeRankings++;
  try {
    if (runtime.mode === "cloud") {
      const token = req.headers.authorization;
      if (!token?.startsWith("Bearer ") || token.length > 8192) return sendJson(res,401,{error:"Sign in first."});
      const user = await fetch(runtime.url + "/auth/v1/user", {headers:{authorization:token,apikey:runtime.key},signal:AbortSignal.timeout(5000)});
      if (!user.ok) return sendJson(res,401,{error:"Sign in again."});
    }
    let input;
    try { input = appleRanker.cleanInput(JSON.parse(await readBody(req))); }
    catch { return sendJson(res,400,{error:"Invalid planner choices."}); }
    sendJson(res,200,await appleRanker.rank(input));
  } catch { sendJson(res,503,{error:"On-device ranking unavailable"}); }
  finally { activeRankings--; }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/runtime-config.js") {
    res.writeHead(200, { "Content-Type":"application/javascript", "Cache-Control":"no-store" });
    return res.end(configScript(runtime));
  }
  if (url.pathname === "/data/curated.json") return sendJson(res, 200, curated());
  if (url.pathname === "/api/calendar/open") return void openMacCalendar(req, res);
  if (url.pathname === "/api/plan/rank") return void rankWeeklyPlan(req, res);
  if (url.pathname.startsWith("/api/db/")) {
    if (runtime.mode !== "local") return sendJson(res, 404, {error:"Unavailable in account mode"});
    handleApi(req, res, url).catch((e) => sendJson(res, 500, { error: String((e && e.message) || e) }));
  } else if (req.method === "GET" || req.method === "HEAD") {
    serveFile(req, res, url);
  } else {
    res.writeHead(405);
    res.end();
  }
});

server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.error(
      "\nPort " +
        PORT +
        " is already in use. Sunday Plan is probably already running in another Terminal window.",
    );
    console.error("Open http://localhost:" + PORT + " or close the other window and try again.\n");
  } else console.error(e);
  process.exit(1);
});

// Refresh on launch when yesterday's catalog is still installed, then check hourly.
let refreshInProgress = false;
function refreshIfDue() {
  if (refreshInProgress) return;
  const today = new Intl.DateTimeFormat("en-CA", {timeZone: "America/Los_Angeles"}).format(new Date());
  try {
    const {meta} = JSON.parse(fs.readFileSync(path.join(APP_DIR, "data/current.json"), "utf8"));
    if (meta.attemptedAt === today && !meta.failedSources?.length) return;
  } catch { /* A missing or unreadable bundle needs a refresh. */ }
  refreshInProgress = true;
  const process = spawn("python3", [path.join(__dirname, "tools/refresh_catalog.py")], {stdio: "inherit"});
  process.on("error", error => console.warn("Catalog refresh could not start:", error.message));
  process.on("close", () => { refreshInProgress = false; });
}

server.listen(PORT, "127.0.0.1", () => {
  if (runtime.mode === "local") readDb(); // make sure database.json exists before the first request
  refreshIfDue();
  setInterval(refreshIfDue, 60 * 60 * 1000).unref();
  console.log("\nSunday Plan is running.");
  console.log("  Open:      http://localhost:" + PORT);
  console.log(runtime.mode === "local" ? "  Saving to: " + DB_FILE : "  Student accounts: Supabase");
  console.log("  Stop:      press Ctrl + C\n");
});
