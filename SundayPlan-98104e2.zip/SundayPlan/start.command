#!/bin/bash
# Double-click this file in Finder to start Sunday Plan.
# It opens a Terminal window, starts the local server, and opens the app in your browser.
# To stop the app, close that Terminal window (or press Ctrl + C in it).
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js was not found. Install the LTS version from https://nodejs.org and try again."
  read -r -p "Press Return to close."
  exit 1
fi
(sleep 1 && open "http://localhost:${PORT:-4173}") &
node server.js
