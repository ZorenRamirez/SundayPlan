/*
  08-dropdowns.js — the app's own dropdown menus.

  The choices for graduation year, age, major, times and getting around, how a dropdown
  opens, filters and is used from the keyboard, plus the small celebration burst.
*/
"use strict";
/* ---------- dropdowns ---------- */
const ayEnd = () => {
  const d = now();
  return d.getMonth() >= 6 ? d.getFullYear() + 1 : d.getFullYear();
};
const gradToYear = (g) => Math.max(1, Math.min(4, 4 - (g - ayEnd())));
const gradOpts = () => {
  const e = ayEnd();
  return [3, 2, 1, 0]
    .map((n) => ({ v: e + n, l: String(e + n), sub: YEARS[4 - n] }))
    .concat([{ v: e + 4, l: e + 4 + " or later", sub: "First-year" }]);
};
const AGES = [
  "18",
  "19",
  "20",
  "21",
  "22",
  "23",
  "24",
  "25 or older",
  "17 or younger",
  "Prefer not to say",
].map((a) => ({ v: a, l: a }));
const TIMES = (() => {
  const o = [];
  for (let m = 7 * 60; m <= 22 * 60; m += 30) {
    const v = pad(Math.floor(m / 60)) + ":" + pad(m % 60);
    o.push({ v, l: fmtTime(v) });
  }
  return o;
})();
const MOVE = [
  { v: "walk", l: "Walking only" },
  { v: "bus", l: "Bus" },
  { v: "car", l: "I have a car" },
];
const majorOpts = () => MAJORS.map((m) => ({ v: m[1], l: m[1], group: m[3] }));
function dd(id, label, value, opts, o = {}) {
  const open = ui.dd === id,
    cur = opts.find((x) => String(x.v) === String(value));
  let last = "";
  const items = opts
    .map((x) => {
      let h = "";
      if (x.group && x.group !== last) {
        last = x.group;
        h += `<div class="ddgroup">${esc(x.group)}</div>`;
      }
      const on = String(x.v) === String(value);
      return (
        h +
        `<button type="button" class="ddopt" role="option" aria-selected="${on}" data-act="ddpick" data-f="${id}" data-v="${esc(x.v)}" data-g="${esc(x.group || "")}"><span>${esc(x.l)}${x.sub ? `<small>${esc(x.sub)}</small>` : ""}</span><i class="tick"></i></button>`
      );
    })
    .join("");
  return `<div class="fieldset ${o.full ? "full" : ""}"><span id="ddl-${id}">${esc(label)}</span><div class="dd ${open ? "open" : ""}" data-dd="${id}"><button type="button" class="ddbtn" id="dd-${id}" data-act="ddtoggle" data-v="${id}" aria-haspopup="listbox" aria-expanded="${open}" aria-labelledby="ddl-${id} dd-${id}"><span class="${cur ? "" : "ph"}">${esc(cur ? cur.l + (cur.sub ? " · " + cur.sub : "") : o.ph || "Choose")}</span><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button>${open ? `<div class="ddpop" role="listbox" aria-labelledby="ddl-${id}">${o.search ? `<input type="search" id="ddq" placeholder="${esc(o.search)}" aria-label="${esc(o.search)}" autocomplete="off">` : ""}<div class="ddscroll">${items}<div class="ddnone" hidden>No match. Try another word.</div></div></div>` : ""}</div></div>`;
}
function ddFilter(q) {
  q = q.trim().toLowerCase();
  const pop = $(".ddpop");
  if (!pop) return;
  let any = false;
  const seen = new Set();
  pop.querySelectorAll(".ddopt").forEach((b) => {
    const hit = !q || b.textContent.toLowerCase().includes(q);
    b.hidden = !hit;
    if (hit) {
      any = true;
      seen.add(b.dataset.g);
    }
  });
  pop.querySelectorAll(".ddgroup").forEach((g) => (g.hidden = !seen.has(g.textContent)));
  pop.querySelector(".ddnone").hidden = any;
}
function ddFocus() {
  const pop = $(".ddpop");
  if (!pop) return;
  const q = pop.querySelector("#ddq"),
    sel = pop.querySelector('[aria-selected="true"]');
  if (sel) sel.scrollIntoView({ block: "center" });
  (q || sel || pop.querySelector(".ddopt")).focus({ preventScroll: true });
}
document.addEventListener("keydown", (ev) => {
  if (!ui.dd) return;
  const pop = $(".ddpop");
  if (!pop) return;
  if (ev.key === "Escape") {
    const id = ui.dd;
    ui.dd = null;
    render();
    const b = document.getElementById("dd-" + id);
    if (b) b.focus();
    return;
  }
  if (ev.key !== "ArrowDown" && ev.key !== "ArrowUp") return;
  ev.preventDefault();
  const o = [...pop.querySelectorAll(".ddopt:not([hidden])")];
  if (!o.length) return;
  let i = o.indexOf(document.activeElement);
  i = ev.key === "ArrowDown" ? Math.min(o.length - 1, i + 1) : Math.max(0, i < 0 ? 0 : i - 1);
  o[i].focus();
});
function burst(el) {
  if (!el || matchMedia("(prefers-reduced-motion:reduce)").matches) return;
  const r = el.getBoundingClientRect(),
    cols = ["var(--wheat)", "var(--ok)", "var(--t-career)", "var(--t-club)"];
  for (let n = 0; n < 14; n++) {
    const d = document.createElement("i");
    d.className = "bit";
    const a = Math.random() * Math.PI * 2,
      m = 40 + Math.random() * 50;
    d.style.cssText = `left:${r.left + r.width / 2}px;top:${r.top + r.height / 2}px;background:${cols[n % 4]};--x:${Math.cos(a) * m}px;--y:${Math.sin(a) * m - 20}px`;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 700);
  }
}
