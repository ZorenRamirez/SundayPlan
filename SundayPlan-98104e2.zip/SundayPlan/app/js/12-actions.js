/*
  12-actions.js — what happens when the student does something.

  One big click handler (every button has a data-act name that is matched here), plus
  typing, picking from menus, and switching tabs through the address bar (#week, #you...).
*/
"use strict";
/* ---------- actions ---------- */
function meetingForm(id) {
  const listing = LIST.find(o => o.id === id);
  const alternating = /bi[ -]?weekly|every other|every (?:two|2) weeks|fortnight/i.test(listing?.meet || "");
  return { day: 2, time: "18:00", place: "", interval: alternating ? 2 : 1, ...state.weekly[id] };
}
function writePlanEntry(k, patch) {
  const entry = Object.assign({}, state.plan[k] || {}, patch);
  const [id, index] = k.split(":");
  const listing = LIST.find(item => item.id === id);
  const step = listing?.steps?.[Number(index)];
  if (step && (!entry.listing || entry.listing.step === step.text)) {
    const event = step.event != null && listing.dates?.[step.event];
    entry.listing = {
      title: listing.title, type: listing.type, org: listing.org, url: listing.url,
      step: step.text, minutes: step.min, ...(event ? {event: {...event}} : {}),
      ...(step.ask && listing.ask ? {question:listing.ask} : {}),
    };
  }
  state.plan[k] = entry;
}
function setPlan(k, patch) {
  writePlanEntry(k, patch);
  if (state.later) delete state.later[k];
  save();
}
function reportText() {
  const p = prof(),
    L = [
      "Sunday Plan report · " + fmtDate(today()),
      (p.name || "Student") + " · " + YEARS[p.year] + " · " + majorRow()[1],
      "Streak: " + streak() + " weeks",
      "",
    ];
  for (const x of entries()) {
    if (!x.o) continue;
    const e = x.e;
    L.push(
      "[" +
        e.status +
        "] " +
        x.o.title +
        " · step " +
        (x.i + 1) +
        (e.day ? " · " + e.day : "") +
        (e.at ? " · done " + e.at : "") +
        (e.knew === true ? " · already knew" : e.knew === false ? " · new to me" : "") +
        (e.reason ? " · reason: " + e.reason : "") +
        (e.note ? " · note: " + e.note : ""),
    );
  }
  for (const x of weeklyList(true))
    L.push(
      (x.w.interval === 2 ? "[every two weeks] " : "[weekly] ") +
        x.o.title +
        " · " +
        DOWL[+x.w.day] +
        " " +
        x.w.time +
        " · weeks attended: " +
        Object.keys(state.attend).filter((k) => k.startsWith(x.id + ":") && state.attend[k]).length,
    );
  const flaggedTitles = Object.entries(state.stale)
    .filter(([, flag]) => flag)
    .map(([id, flag]) => LIST.find(o => o.id === id)?.title ||
      (typeof flag === "string" ? flag : "Previously listed opportunity"));
  if (flaggedTitles.length) L.push("", "Marked out of date: " + flaggedTitles.join(", "));
  return L.join("\n");
}
document.addEventListener("click", async (ev) => {
  {
    const sg = $("#sugg");
    if (sg && !ev.target.closest(".sbox")) sg.hidden = true;
  }
  if (ui.dd && !ev.target.closest(".dd")) {
    ui.dd = null;
    if (!ev.target.closest("[data-act]")) {
      render();
      return;
    }
  }
  const b = ev.target.closest("[data-act]");
  if (!b) return;
  const a = b.dataset.act,
    v = b.dataset.v,
    k = b.dataset.k,
    p = prof();
  switch (a) {
    case "open":
      ui.open[b.dataset.id] = !ui.open[b.dataset.id];
      render();
      return;
    case "ddtoggle":
      ui.dd = ui.dd === v ? null : v;
      render();
      return;
    case "ddpick": {
      const f = b.dataset.f;
      ui.dd = null;
      if (f === "grad") {
        p.grad = +v;
        p.year = gradToYear(+v);
      } else if (f === "age") p.age = v;
      else if (f === "major") {
        p.major = v;
        p.major_set = true;
      } else if (f === "transport") p.transport = v;
      else if (f === "winterval") {
        ui.wform.interval = +v;
        render();
        return;
      } else if (f === "wday" || f === "wtime") {
        ui.wform = Object.assign({ day: 2, time: "18:00", place: "" }, ui.wform);
        ui.wform[f === "wday" ? "day" : "time"] = f === "wday" ? +v : v;
        render();
        return;
      } else if (f === "rday") {
        state.remind.day = +v;
        state.remind.set = true;
      } else if (f === "rtime") state.remind.time = v;
      else if (f === "rlead") state.remind.lead = +v;
      save();
      render();
      const t = document.getElementById("dd-" + f);
      if (t) {
        t.focus({ preventScroll: true });
        t.classList.add("pop");
      }
      return;
    }
    case "showlisting": {
      ui.planStage = null;
      const listing = LIST.find(item => item.id === b.dataset.id);
      if (!listing) return;
      if (ui.tab !== "explore") history.pushState(null, "", "#explore");
      openSection("explore", listing);
      return;
    }
    case "saveretry":
      retrySave();
      return;
    case "tab":
      if (ui.tab !== v) {
        try { history.pushState(null, "", "#" + v); }
        catch { location.hash = v; }
        openSection(v);
      }
      return;
    case "time":
      p.time = +v;
      break;
    case "where":
      p.where = v;
      break;
    case "busy": {
      const i = +v;
      p.busy = p.busy.includes(i) ? p.busy.filter((x) => x !== i) : p.busy.concat(i);
      break;
    }
    case "setp":
      p[b.dataset.f] = b.dataset.f === "year" ? +v : v;
      break;
    case "interest":
      p.interests = p.interests.includes(v) ? p.interests.filter((x) => x !== v) : p.interests.concat(v);
      break;
    case "commit":
      p.commit = v;
      p.time = COMMIT[v][0];
      break;
    case "supportgroups":
      p.supportGroups = p.supportGroups !== true;
      break;
    case "paid":
      p.paid = v === "1";
      break;
    case "rday":
      state.remind.day = +v;
      break;
    case "rlead":
      state.remind.lead = +v;
      break;
    case "obback":
      ui.dd = null;
      ui.ob = Math.max(0, ui.ob - 1);
      render();
      return;
    case "obnext":
      if (!obOk(ui.ob)) {
        toast(OBMSG[ui.ob]);
        return;
      }
      if (ui.ob < 5) {
        ui.ob++;
        ui.dd = null;
        render();
        window.scrollTo(0, 0);
        return;
      }
      state.weekStartsOn = +state.remind.day;
      p.setup = true;
      ui.tab = "week";
      save();
      void generateWeeklyPlan();
      return;
    case "generateplan":
      void generateWeeklyPlan();
      return;
    case "reviewplan":
      ui.planStage = "ready";
      render();
      window.scrollTo(0, 0);
      return;
    case "finishplan":
      ui.open["list:all"] = true;
      ui.planStage = null;
      ui.tab = "week";
      if (location.hash !== "#week") location.hash = "week";
      render();
      window.scrollTo(0, 0);
      return;
    case "plan": {
      // Add to my list saves at once. Choosing a day is a separate, optional step.
      const [id, index] = (k || "").split(":");
      if (!LIST.find((item) => item.id === id)?.steps?.[Number(index)]) return;
      if (state.plan[k]?.status === "done") return;
      if (state.plan[k]?.status !== "planned") setPlan(k, { status: "planned", week: weekStart() });
      ui.planning = ui.skipping = null;
      ui.coach = false;
      ui.focusRow = k;
      toast("Added to your list.");
      render();
      return;
    }
    case "pickday":
      ui.planning = k;
      ui.skipping = null;
      ui.coach = false;
      render();
      return;
    case "clearday":
      if (state.plan[k]) {
        delete state.plan[k].day;
        ui.planning = null;
        toast("Day removed. It stays on your list.");
      }
      break;
    case "coachplan":
      ui.planning = k;
      ui.skipping = null;
      ui.wk = null;
      ui.coach = true;
      render();
      return;
    case "coachwk": {
      const id = b.dataset.id;
      ui.wk = id;
      ui.wform = meetingForm(id);
      ui.planning = ui.skipping = null;
      ui.coach = true;
      render();
      return;
    }
    case "skip":
      ui.skipping = k;
      ui.planning = null;
      render();
      return;
    case "wk": {
      const id = b.dataset.id;
      ui.coach = false;
      ui.wk = id;
      ui.wform = meetingForm(id);
      ui.planning = ui.skipping = null;
      render();
      return;
    }
    case "wksave": {
      const id = b.dataset.id,
        f = ui.wform || { day: 2, time: "18:00", place: "" };
      if (f.interval === 2 && !isDate(f.anchor)) {
        toast("Choose a confirmed meeting date so the alternating weeks line up.");
        return;
      }
      state.weekly[id] = {
        day: f.interval === 2 ? P(f.anchor).getDay() : +f.day,
        time: f.time, place: String(f.place || "").slice(0, 80),
        interval: f.interval || 1, anchor: f.interval === 2 ? f.anchor : "",
      };
      ui.wk = null;
      ui.coach = false;
      ui.wform = null;
      ui.focusRow = "wk-" + id;
      save();
      toast("Saved. Add it to your calendar once.");
      render();
      return;
    }
    case "wkstop":
      delete state.weekly[b.dataset.id];
      break;
    case "went": {
      const meeting = weeklyList().find(x => x.id === b.dataset.id);
      if (!meeting || meeting.date > today()) return;
      const key = b.dataset.id + ":" + weekStart();
      state.attend[key] = !state.attend[key];
      if (state.attend[key]) {
        burst(b);
        ui.flash = "ring";
        toast("Counted toward your week.");
      }
      break;
    }
    case "cancel":
      ui.coach = false;
      ui.wk = null;
      ui.planning = ui.skipping = null;
      ui.confirmReset = false;
      render();
      return;
    case "planday":
      if (!isDate(b.dataset.day) || b.dataset.day < today() || b.dataset.day > weekEnd()) return;
      setPlan(k, { status: "planned", day: b.dataset.day, week: weekStart() });
      ui.planning = null;
      ui.coach = false;
      ui.focusRow = k;
      toast("Added to your list for " + fmtDate(b.dataset.day) + ".");
      render();
      return;
    case "going":
      setPlan(k, { status: "planned", day: b.dataset.day, week: weekStart() });
      ui.focusRow = k;
      toast("Added to your list.");
      render();
      return;
    case "done":
      burst(b);
      setPlan(k, { status: "done", at: today(), week: weekStart() });
      ui.planning = ui.skipping = null;
      ui.flash = "ring";
      toast(weekCount() >= 3 ? "That’s your week done." : "Nice. Logged.");
      render();
      return;
    case "undo": {
      const entry = state.plan[k];
      if (entry?.status !== "done") return;
      if (isDate(entry.day)) {
        entry.status = "planned";
        entry.week = weekStart(entry.day);
        delete entry.at;
      } else delete state.plan[k];
      break;
    }
    case "unplan":
      delete state.plan[k];
      break;
    case "later": {
      const [id, index] = k.split(":");
      const listing = LIST.find((item) => item.id === id);
      const step = listing?.steps?.[Number(index)];
      if (!listing || !step) return;
      state.later[k] = { id, title: listing.title, type: listing.type, org: listing.org, step: step.text, at: today() };
      toast("Saved for later. It stays on your list until you add it to a week.");
      break;
    }
    case "unlater":
      delete state.later[k];
      break;
    case "skipwhy":
      setPlan(k, { status: "skipped", reason: b.dataset.r, week: weekStart() });
      ui.skipping = null;
      toast("Skipped for this week.");
      render();
      return;
    case "stale":
      state.stale[b.dataset.id] = state.stale[b.dataset.id] ? false : (LIST.find(o => o.id === b.dataset.id)?.title || true);
      toast(state.stale[b.dataset.id] ? "Marked out of date in your plan." : "Removed the out-of-date mark.");
      break;
    case "copyask": {
      const id = b.dataset.id;
      const o = LIST.find(x => x.id === id && x.ask) || entries().find(x => x.o.id === id && x.o.ask)?.o;
      if (!o) return toast("The organizer question is unavailable.");
      try {
        await navigator.clipboard.writeText(askText(o));
        toast("Question copied.");
      } catch (e) {
        toast("Copy is blocked here. Select the text to copy it.");
      }
      return;
    }
    case "apple": {
      const c = calCache.get(b.dataset.id);
      if (c) appleFile([c], "sunday-plan-event");
      return;
    }
    case "appleall":
      appleFile(
        upcoming(false)
          .filter((x) => x.d.key)
          .slice(0, 60)
          .map((x) => calFor(x.o, x.d)),
        "sunday-plan-key-dates",
      );
      return;
    case "appleweekly":
      appleFile([weeklyCal()], "sunday-plan-weekly");
      return;
    case "habit":
      state.habits[v] = !state.habits[v];
      break;
    case "road":
      state.road[v] = !state.road[v];
      break;
    case "ftype":
      ui.ftype = v;
      render();
      return;
    case "fscope":
      ui.fscope = v;
      render();
      return;
    case "all":
      ui.all = !ui.all;
      render();
      return;
    case "allset":
      ui.all = v === "1";
      ui.limit = 24;
      render();
      return;
    case "more":
      ui.limit += 24;
      render();
      return;
    case "sugg": {
      const o = LIST.find((x) => x.id === b.dataset.id);
      if (o) {
        ui.q = o.title;
        ui.open["card:list:" + o.id] = true;
        ui.limit = 24;
      }
      render();
      return;
    }
    case "welcomed":
      state.welcomed = true;
      break;
    case "focus":
      state.focus[v] = !state.focus[v];
      break;
    case "datesall":
      ui.allDates = v === "1";
      ui.limit = 24;
      render();
      return;
    case "report":
      try {
        await navigator.clipboard.writeText(reportText());
        toast("Report copied.");
      } catch (e) {
        toast("Copy is blocked in this view.");
      }
      return;
    case "reset":
      ui.resetError = "";
      ui.confirmReset = true;
      render();
      return;
    case "reset2":
      if (!deviceProfile || !ui.confirmReset || ui.resetting) return;
      ui.resetting = true;
      clearTimeout(cloud.timer);
      try {
        if (testerMode) localStorage.removeItem(KEY);
        else {
          if (!cloud.ok || !cloud.doc) throw Error("Local database unavailable");
          await cloud.chain;
          await cloud.doc.delete();
        }
      } catch {
        ui.resetting = false;
        ui.resetError = testerMode ? "This browser could not clear your profile." : "The local database couldn’t confirm the reset. Your profile is still open.";
        save(); render();
        return;
      }
      try { localStorage.removeItem(KEY); } catch {}
      state = fresh(); ui = freshUI(); storedBase = null;
      history.replaceState(null,"","#week");
      render(); window.scrollTo(0, 0);
      return;
    default:
      return;
  }
  save();
  render();
});
document.addEventListener("input", (ev) => {
  const t = ev.target;
  if (t.id === "ddq") {
    ddFilter(t.value);
    return;
  }
  if (t.id === "q") {
    ui.q = t.value;
    ui.limit = 24;
    calCache.clear();
    $("#results").innerHTML = results();
    const sg = $("#sugg");
    if (sg) {
      const h = sugg();
      sg.innerHTML = h;
      sg.hidden = !h;
    }
    return;
  }
  if (t.dataset.w === "anchor") {
    ui.wform.anchor = t.value;
    return;
  }
  if (t.dataset.w === "place") {
    ui.wform = Object.assign({ day: 2, time: "18:00", place: "" }, ui.wform);
    ui.wform.place = t.value;
    return;
  }
  if (t.dataset.p === "gpa" && (t.value === "" || t.validity.valid)) {
    prof().gpa = t.value;
    save();
    return;
  }
  if (t.dataset.p === "goal") { prof().goal = t.value.slice(0,160); save(); return; }
  if (t.dataset.p === "name") {
    prof().name = t.value.slice(0, 40);
    save();
    const nb = $("[data-act=obnext]");
    if (nb) nb.classList.toggle("off", !obOk(ui.ob));
    return;
  }
});
document.addEventListener("change", (ev) => {
  const t = ev.target;
  if (t.dataset.note) {
    setPlan(t.dataset.note, { note: t.value.slice(0, 300) });
    return;
  }
  if (t.dataset.p === "major") {
    prof().major = t.value;
    save();
    render();
    return;
  }
  if (t.dataset.p === "gpa") {
    const n = parseFloat(t.value);
    prof().gpa = isFinite(n) && n >= 0 && n <= 4 ? String(n) : "";
    t.value = prof().gpa;
    save();
    return;
  }
  if (t.dataset.r === "time" && /^\d\d:\d\d$/.test(t.value)) {
    state.remind.time = t.value;
    save();
    render();
    return;
  }
});
function openSection(section, listing) {
  ui.tab = section;
  ui.q = listing?.title || "";
  ui.limit = 24;
  ui.all = !!listing;
  if (listing) {
    ui.ftype = ui.fscope = "";
    ui.open["card:list:" + listing.id] = true;
  }
  ui.anim = true;
  ui.planning = ui.skipping = ui.dd = null;
  ui.confirmReset = false;
  render();
  window.scrollTo(0, 0);
}
function sectionFromUrl() {
  const section = location.hash.slice(1);
  return TABS.some(([id]) => id === section) ? section : "week";
}
function route() {
  const section = sectionFromUrl();
  if (section !== ui.tab) openSection(section);
}
window.addEventListener("hashchange", route);
