// Use one complete refresh. Fall back to the bundled snapshot when the latest is unavailable.
let catalogReady;
function loadCatalog() {
  return catalogReady ||= readCatalog();
}
async function readCatalog() {
  const usable = v => v && typeof v.meta?.builtAt === "string" && [v.clubs,v.events,v.jobs].every(Array.isArray);
  let snapshot;
  try {
    const response = await fetch("data/current.json", {cache:"no-store"});
    if (response.ok) snapshot = await response.json();
    if (!usable(snapshot)) throw new Error("No complete refresh");
    try { localStorage.setItem("sp-public-catalog",JSON.stringify(snapshot)); } catch {}
  } catch {
    try { snapshot = JSON.parse(localStorage.getItem("sp-public-catalog")); } catch {}
  }
  if (!usable(snapshot)) return loadFeeds();
  FEEDS = snapshot;
  LIST = build();
  render();
}
