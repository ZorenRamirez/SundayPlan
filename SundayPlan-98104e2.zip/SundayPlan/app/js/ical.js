/* Shared by the browser download and the local Mac Calendar handoff. */
"use strict";
const calendarFile = (() => {
  const zone = "America/Los_Angeles";
  const weekdays = "(SU|MO|TU|WE|TH|FR|SA)";
  const weekly = new RegExp("^FREQ=WEEKLY;(INTERVAL=2;)?BYDAY=" + weekdays + "$");
  function validDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const day = new Date(value + "T12:00:00Z");
    return Number.isFinite(+day) && day.toISOString().slice(0, 10) === value;
  }
  function nextDay(date) {
    const day = new Date(date + "T12:00:00Z");
    day.setUTCDate(day.getUTCDate() + 1);
    return day.toISOString().slice(0, 10);
  }
  function endDate(item) {
    return item.endDate || (item.start && item.end && item.end < item.start ? nextDay(item.date) : item.date);
  }
  function escapeText(value) {
    return String(value || "").replace(/\\/g, "\\\\").replace(/\r\n|\r|\n/g, "\\n")
      .replace(/,/g, "\\,").replace(/;/g, "\\;").replace(/[\x00-\x08\x0b-\x1f\x7f]/g, "");
  }
  function validate(item) {
    if (!item || !validDate(item.date) || !item.title || !item.uid) throw Error("Missing calendar fields");
    for (const key of ["uid", "title", "details", "location"]) {
      if (item[key] != null && (typeof item[key] !== "string" || item[key].length > 10000)) throw Error("Invalid event text");
    }
    for (const time of [item.start, item.end]) {
      if (time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw Error("Invalid calendar time");
    }
    if (item.endDate && (!validDate(item.endDate) || item.endDate < item.date)) throw Error("Invalid end date");
    if (item.rrule && !weekly.test(item.rrule)) throw Error("Unsupported recurrence");
  }
  function fold(line) {
    const parts = [];
    let part = "", bytes = 0;
    for (const ch of line) {
      const cp = ch.codePointAt(0);
      const size = cp < 128 ? 1 : cp < 2048 ? 2 : cp < 65536 ? 3 : 4;
      if (bytes + size > 75) { parts.push(part); part = " "; bytes = 1; }
      part += ch; bytes += size;
    }
    return parts.concat(part).join("\r\n");
  }
  const compact = date => date.replace(/-/g, "");
  const localTime = (date, time) => compact(date) + "T" + time.replace(":", "") + "00";
  function write(items, lead = 7) {
    if (!Array.isArray(items) || !items.length || items.length > 60) throw Error("Choose between one and sixty events");
    if (![1, 3, 7, 14].includes(lead)) lead = 7;
    items.forEach(validate);
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Sunday Plan//Calendar//EN", "CALSCALE:GREGORIAN"];
    if (items.some(c => c.start)) lines.push("BEGIN:VTIMEZONE", "TZID:" + zone,
      "BEGIN:DAYLIGHT", "DTSTART:20070311T020000", "RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU",
      "TZOFFSETFROM:-0800", "TZOFFSETTO:-0700", "TZNAME:PDT", "END:DAYLIGHT",
      "BEGIN:STANDARD", "DTSTART:20071104T020000", "RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU",
      "TZOFFSETFROM:-0700", "TZOFFSETTO:-0800", "TZNAME:PST", "END:STANDARD", "END:VTIMEZONE");
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
    for (const c of items) {
      lines.push("BEGIN:VEVENT", "UID:" + escapeText(c.uid) + "@sunday-plan", "DTSTAMP:" + stamp, "SUMMARY:" + escapeText(c.title));
      if (c.start) {
        lines.push("DTSTART;TZID=" + zone + ":" + localTime(c.date, c.start));
        if (c.end && (c.start !== c.end || c.date !== endDate(c)))
          lines.push("DTEND;TZID=" + zone + ":" + localTime(endDate(c), c.end));
      } else lines.push("DTSTART;VALUE=DATE:" + compact(c.date), "DTEND;VALUE=DATE:" + compact(nextDay(c.endDate || c.date)));
      if (c.location) lines.push("LOCATION:" + escapeText(c.location));
      if (c.details) lines.push("DESCRIPTION:" + escapeText(c.details));
      if (c.rrule) lines.push("RRULE:" + c.rrule);
      const alarms = c.rrule ? [c.uid === "weekly-summary" ? "PT0M" : "-PT1H"] :
        c.start ? ["-P1D", "-PT2H"] : ["-PT" + (lead * 24 - 9) + "H", "PT9H"];
      for (const trigger of alarms)
        lines.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + escapeText(c.title), "TRIGGER:" + trigger, "END:VALARM");
      lines.push("END:VEVENT");
    }
    return lines.concat("END:VCALENDAR", "").map(fold).join("\r\n");
  }
  return {write, endDate};
})();
if (typeof module !== "undefined" && module.exports) module.exports = calendarFile;
