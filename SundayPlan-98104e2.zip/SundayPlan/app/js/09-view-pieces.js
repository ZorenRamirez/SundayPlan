/*
  09-view-pieces.js — reusable pieces of the screen.

  Cards, badges and pills, the day picker, the "ask the organizer" box, the saved list and
  its rows, the top of the weekly screen, the focus checklist and the pop-up toast message.
  Each function returns a chunk of HTML as text; the long lines inside backticks (`...`)
  are that HTML.
*/
"use strict";
/* ---------- views ---------- */
let toastT = null;
function toast(m) {
  let t = $(".toast");
  if (!t) {
    t = document.createElement("div");
    t.className = "toast";
    t.setAttribute("role", "status");
    document.body.appendChild(t);
  }
  t.textContent = m;
  clearTimeout(toastT);
  toastT = setTimeout(() => t.remove(), 3800);
}
const pill = (o) =>
  `<span class="pill"><i style="background:var(--t-${esc(o.type)})"></i>${esc((TYPES[o.type] || ["", "Other"])[1])}</span>`;
const badges = (o, m) =>
  (m && subjectFit(o)?.direct ? '<span class="badge match">Your major</span>' : "") +
  (o.scope === "beyond" ? '<span class="badge">Beyond WSU</span>' : "") +
  (o.cost === "paid" ? '<span class="badge warn">Costs money</span>' : "") +
  (o.verify === "secondary" ? '<span class="badge warn">Confirm with organizer</span>' : "");
function askText(o) {
  const p = prof();
  return String(o.ask || "")
    .replace("{year}", YEARS[p.year].toLowerCase())
    .replace("{major}", majorRow()[1]);
}
function qualifyLine(o) {
  const p = prof();
  let g = "";
  if (o.gpa)
    g =
      p.gpa === ""
        ? ` Check your GPA against this requirement (${o.gpa.toFixed(1)}).`
        : +p.gpa >= o.gpa
          ? ` Your GPA meets the listed ${o.gpa.toFixed(1)} minimum.`
          : "";
  return esc(o.qualify || "") + g;
}
function dayChips(k, busy) {
  const [id, index] = k.split(":");
  const listing = LIST.find(o => o.id === id);
  const event = listing?.dates?.[listing.steps[index]?.event];
  const current = state.plan[k]?.status === "planned" ? state.plan[k].day : "";
  let h = "";
  for (let n = 0; n < 7; n++) {
    const d = addDays(today(), n),
      w = P(d).getDay(),
      off = busy.includes(w);
    if (d > weekEnd()) break;
    if (event && event.date !== d) continue;
    h += `<button class="chip day ${off ? "busy" : ""}" aria-pressed="${d === current}" aria-label="${DOWL[w]}, ${MONL[P(d).getMonth()]} ${P(d).getDate()}${off ? ", a day you marked busy" : ""}" data-act="planday" data-k="${esc(k)}" data-day="${d}"><b>${DOW[w]}</b><span>${MON[P(d).getMonth()]} ${P(d).getDate()}</span>${off ? "<small>Busy</small>" : ""}</button>`;
  }
  return h;
}
// Keyboard focus has to follow the day picker, and the screen is rebuilt on every change.
// `lastPress` reads which button was just used (it still has focus while the new screen is
// being built) and `focusOn` moves focus once the new screen is in place.
const lastPress = () => (typeof document === "object" && document.activeElement && document.activeElement.dataset) || {};
const focusOn = (find) => {
  if (typeof requestAnimationFrame !== "function") return;
  requestAnimationFrame(() => {
    const el = find();
    if (el) el.focus({ preventScroll: true });
  });
};
const withYear = (d) => fmtDate(d) + (d.slice(0, 4) !== today().slice(0, 4) ? " " + d.slice(0, 4) : "");
// The day picker shared by picks, Explore cards and list rows. Choosing a day schedules a step
// the student does themselves. That is not the same as attending the listing's dated event, so
// the picker names the step, shows the real date, time and place when the listing has one, and
// says where the listing came from. `extra` is the Details button, which stays in reach.
function dayPicker(o, i, { step = true, selectedStep = o.steps?.[i], extra = "" } = {}) {
  const k = pkey(o, i),
    s = selectedStep,
    chips = dayChips(k, prof().busy),
    q = "dq-" + esc(k),
    d = nextKey(o),
    url = safeUrl(o.url),
    press = lastPress();
  if (press.k === k && (press.act === "pickday" || press.act === "coachplan"))
    focusOn(() => {
      const g = document.getElementById("days-" + k);
      return g && (g.querySelector('[aria-pressed="true"]') || g.querySelector("button"));
    });
  const real = d
    ? `<p class="pnote"><b>${d.start || d.location ? "The event itself" : "The date this leads to"}</b>${esc(d.label)}, ${withYear(d.date)}${d.start ? ", " + fmtTime(d.start) + (d.end ? " to " + fmtTime(d.end) : "") : ""}${d.location ? " · " + esc(d.location) : ""}</p>`
    : "";
  const from = o.src === "involve" ? "WSU Involve" : o.src === "board" ? "the employer’s careers page" : o.org || "the organizer";
  return `<div class="pday">${step ? `<p class="pstep"><b>Step</b>${esc(s.text)}</p>` : ""}<div class="q" id="${q}">Optional: pick a day for yourself<span class="vh"> for ${esc(o.title)}</span></div><p class="mini">This is your own plan, not a deadline. You can leave it open.</p>${
    chips
      ? `<div class="chips days" id="days-${esc(k)}" role="group" aria-labelledby="${q}">${chips}</div>`
      : `<p class="mini">No day is left for this in the current week.</p>`
  }${real}<p class="psrc">Source: ${esc(from)}${isDate(o.checked) ? ", checked " + fmtShort(o.checked) : ""}.${url ? ` <a class="link" href="${esc(url)}" target="_blank" rel="noopener">Organizer page ↗</a>` : ""}</p><div class="actions pfoot"><button class="btn text" data-act="cancel" data-k="${esc(k)}">Close</button>${state.plan[k]?.day ? `<button class="btn text" data-act="clearday" data-k="${esc(k)}">Remove my day</button>` : ""}${extra}</div></div>`;
}
const chev = (o) =>
  `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="transform:rotate(${o ? 180 : 0}deg);transition:transform .2s"><path d="m6 9 6 6 6-6"/></svg>`;
const shortStep = (s) =>
  s.text;
function askBox(o) {
  const c = o.contact || {};
  return `<div class="ask"><q>${esc(askText(o))}</q><div class="to">To ${esc(c.name || "the organizer")}${c.email ? ` · <a class="link" href="mailto:${esc(c.email)}">${esc(c.email)}</a>` : ""}</div><div class="actions" style="margin-top:8px"><button class="btn sm ghost" data-act="copyask" data-id="${esc(o.id)}">Copy question</button></div></div>`;
}
function card(x, variant, why) {
  const o = x.o,
    i = x.i,
    s = i >= 0 ? o.steps[i] : null,
    k = s ? pkey(o, i) : "",
    e = k ? state.plan[k] : null,
    id = esc(o.id),
    title = esc(o.title),
    lead = variant === "top",
    pick = lead || variant === "alt";
  // true while this card's day picker is open
  const planning = !!s && !ui.coach && ui.planning === k && !(variant === "list" && why_not(o));
  const ds = (o.dates || []).filter((d) => isDate(d.date) && d.date >= today());
  const ev = s && s.event != null && o.dates[s.event],
    url = safeUrl(o.url),
    no = variant === "list" ? why_not(o) : "",
    // Each place a listing appears (top pick, other picks, Discover) keeps its own Details state.
    scope = variant + "-" + o.id,
    openKey = "card:" + variant + ":" + o.id,
    open = !!ui.open[openKey],
    nk = nextKey(o);
  const weeklyOk = !o.archived && ["club", "service", "leadership"].includes(o.type) && !state.weekly[o.id];
  let h = `<article class="card ${lead ? "lead" : ""} ${pick ? "pick" : ""} ${ui.anim ? "rise" : ""}" aria-labelledby="t-${esc(scope)}">`;
  h += `<div class="meta">${lead ? `<span class="ribbon">Top pick</span>` : ""}${pill(o)}${badges(o, variant === "list")}</div><h3 id="t-${esc(scope)}">${title}</h3>`;
  {
    const bits = [];
    // A hand-checked step carries a time estimate. Feed listings do not, so none is shown for them.
    if (pick && s && !o.src && !ev) bits.push("About " + dur(s.min));
    if (o.src && o.type !== "club" && o.src !== "board" && o.org) bits.push(esc(o.org));
    if (o.meet) bits.push(esc(o.meet) + (o.place ? " · " + esc(o.place) : ""));
    if (ev)
      bits.push(
        "Event " + fmtDate(ev.date) +
          (ev.start ? ", " + fmtTime(ev.start) : "") +
          (ev.location ? " · " + esc(ev.location) : ""),
      );
    else if (nk && nk.key && daysTo(nk.date) <= 75) bits.push(nk.key ? "Deadline " + fmtShort(nk.date) : "Event " + fmtShort(nk.date));
    if (pick && s) {
      // Picks lead with the reason and the one thing to do. The description waits in Details.
      const reason = why || fits(o, i).slice(0, 2).join(" · ");
      if (reason) h += `<p class="why1">${esc(reason)}</p>`;
      h += `<p class="next"><b>Next</b><span class="${open || planning ? "" : "clamp"}">${esc(s.text)}</span></p>`;
    } else {
      const sum = o.summary || (s ? shortStep(s) : "");
      if (sum) h += `<p class="sum ${open ? "" : "clamp"}">${esc(sum)}</p>`;
    }
    if (bits.length) h += `<p class="mini">${bits.join(" · ")}</p>`;
    if (no) h += `<p class="mini">${esc(no)}</p>`;
    else if (!s) {
      const any = Object.keys(state.plan).some(
        (q) => q.startsWith(o.id + ":") && state.plan[q].status === "done",
      );
      const m = any ? "All steps done" : nk ? "Next step opens closer to " + fmtShort(nk.date) : "";
      if (m) h += `<p class="mini">${m}</p>`;
    }
  }
  const more = `<button class="btn ghost more" id="more-${esc(scope)}" data-act="open" data-id="${esc(openKey)}" aria-expanded="${open}" aria-controls="body-${esc(scope)}">${open ? "Less" : "Details"}<span class="vh"> for ${title}</span>${chev(open)}</button>`;
  if (s && !no) {
    if (!ui.coach && ui.wk === o.id && !state.weekly[o.id]) h += wkForm(o);
    else if (planning) h += `<div class="inline">${dayPicker(o, i, { step: !pick, extra: more })}</div>`;
    else if (ui.skipping === k)
      h += `<div class="inline"><div class="q">What got in the way?</div><div class="chips">${SKIPS.map((r) => `<button class="chip sm" data-act="skipwhy" data-k="${esc(k)}" data-r="${esc(r)}">${esc(r)}</button>`).join("")}</div><div><button class="btn text" data-act="cancel">Cancel</button></div></div>`;
    else {
      // Cancel hands keyboard focus back to the button that opened the picker.
      if ((lastPress().act === "cancel" || lastPress().act === "plan") && lastPress().k === k) focusOn(() => document.getElementById("go-" + k));
      h += `<div class="actions main">${e && e.status === "planned" ? `<span class="pill"><i style="background:var(--ok)"></i>On your list${isDate(e.day) ? (ev ? " · Event " : e.day < today() ? " · You planned " : " · Your plan: ") + withYear(e.day) : ""}</span>${ev ? "" : `<button class="btn ghost" id="go-${esc(k)}" data-act="pickday" data-k="${esc(k)}">${isDate(e.day) ? "Change my day" : "Pick a day (optional)"}<span class="vh">: ${title}</span></button>`}${appleButton(calForStep({o,s,e,k}), ev ? "Add event to Apple Calendar" : "Add step to Apple Calendar")}` : ev ? `<button class="btn primary" id="go-${esc(k)}" data-act="going" data-k="${esc(k)}" data-day="${ev.date}">I’m going<span class="vh"> to ${title}</span></button>` : `<button class="btn primary" id="go-${esc(k)}" data-act="plan" data-k="${esc(k)}">Add to my list<span class="vh">: ${title}</span></button>`}${!ev && !(e && e.status === "planned") && !state.later?.[k] ? `<button class="btn ghost" data-act="later" data-k="${esc(k)}">Save for later<span class="vh">: ${title}</span></button>` : ""}${more}</div>`;
    }
  } else h += `<div class="actions main">${more}</div>`;
  if (pick && s?.ask && o.ask) h += askBox(o);
  if (open) {
    h += `<div class="more-body" id="body-${esc(scope)}">`;
    if (pick && s && o.summary) h += `<p class="sum">${esc(o.summary)}</p>`;
    if (s && !no && !pick && !planning) h += `<div class="kv"><b>Next step.</b> ${esc(s.text)}</div>`;
    if (!pick && s && !no && s.ask && o.ask) h += askBox(o);
    if (s && !no && variant !== "list")
      h += `<ul class="why">${fits(o, i)
        .map((f) => `<li>${esc(f)}</li>`)
        .join("")}</ul>`;
    h += `<div class="kv"><b>Who it’s for.</b> ${qualifyLine(o)}${o.note ? " " + esc(o.note) : ""}</div>`;
    if (o.org) h += `<div class="kv"><b>Run by.</b> ${esc(o.org)}</div>`;
    if (ds.length)
      h += `<div class="dates">${ds
        .slice(0, 6)
        .map(
          (d) =>
            `<div class="daterow"><span class="mono">${fmtShort(d.date)}${d.start ? " " + fmtTime(d.start).replace(" ", "") : ""}</span><span class="lbl">${esc(d.label)}${d.location ? " · " + esc(d.location) : ""}</span>${calBtns(calFor(o, d))}</div>`,
        )
        .join("")}</div>`;
    if (s && !no && !(ui.planning === k || ui.skipping === k || ui.wk === o.id))
      h += `<div class="actions">${e && e.status === "planned" ? `<button class="btn sm ghost" data-act="done" data-k="${esc(k)}">Mark done</button>` : ""}${variant !== "list" && !(e && e.status === "planned") ? `<button class="btn text" data-act="skip" data-k="${esc(k)}">Not this week</button>` : ""}</div>`;
    h += `<div class="foot">${url ? `<a class="link" href="${esc(url)}" target="_blank" rel="noopener">Organizer page ↗</a>` : ""}${(
      o.links || []
    )
      .filter((l) => safeUrl(l.url))
      .map((l) => `<a class="link" href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.label)} ↗</a>`)
      .join(
        "",
      )}<button class="btn text" data-act="stale" data-id="${id}">${state.stale[o.id] ? "Marked out of date · Undo" : "Mark out of date"}</button></div></div>`;
  }
  return h + `</article>`;
}
function wkForm(o) {
  const f = ui.wform || { day: 2, time: "18:00", place: "" };
  return `<div class="inline"><div class="q">When does it meet?</div><div class="form">${f.interval === 2 ? "" : dd(
    "wday",
    "Day",
    f.day,
    DOWL.map((d, i) => ({ v: i, l: d })),
  )}${dd("wtime", "Time", f.time, TIMES)}${dd("winterval", "Repeats", f.interval || 1, [{v:1,l:"Every week"},{v:2,l:"Every two weeks"}])}${f.interval === 2 ? `<label class="f">Confirmed meeting date<input type="date" data-w="anchor" value="${esc(f.anchor || "")}"></label>` : ""}<label class="f full">Where, optional<input type="text" id="w-place" data-w="place" value="${esc(f.place || "")}" placeholder="Todd Hall 216"></label></div><div class="actions"><button class="btn wheat sm" data-act="wksave" data-id="${esc(o.id)}">Save</button><button class="btn text" data-act="cancel">Cancel</button></div></div>`;
}
const moreBtn = (key, open) =>
  `<button class="btn text more" data-act="open" data-id="${esc(key)}" aria-expanded="${open}">${open ? "Less" : "More"}${chev(open)}</button>`;
function track() {
  const t = today(),
    wc = weekCount(),
    dayIdx = Math.round((P(t) - P(weekStart())) / 864e5);
  const over =
      planned().filter((x) => x.e.day < t).length + weeklyList().filter((x) => x.due && x.date < t).length,
    open = planned().length + weeklyList().filter((x) => !x.went).length;
  if (over > 0) return { state: "behind", label: over + " overdue" };
  if (wc >= 3) return { state: "done", label: "Week complete" };
  if (wc === 0 && open === 0 && dayIdx >= 3) return { state: "behind", label: "Nothing planned yet" };
  return { state: "on", label: "On track" };
}
// The chevron repeats what tapping the row does, so it is kept out of the keyboard and
// screen-reader order. The row button itself carries the expanded state.
const tchev = (key, open) =>
  `<button class="tchev" tabindex="-1" aria-hidden="true" data-act="open" data-id="${esc(key)}">${chev(open)}</button>`;
const DAY_ICON = `<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="5" width="16" height="15" rx="3"/><path d="M8 3v4M16 3v4M4 10h16"/></svg>`;
// Says what a date on a row actually is. A listing's event date and a real deadline come from the
// listing; a day the student picked is labeled as theirs. Steps with no date show none.
function whenParts(o, s, e) {
  const ev = s.event != null && o.dates?.[s.event], parts = [];
  if (ev) parts.push("Event " + fmtDate(ev.date) + (ev.start ? ", " + fmtTime(ev.start) : ""));
  else {
    const dl = (o.dates || []).filter((d) => d.key && isDate(d.date) && d.date >= today()).sort((a, b) => (a.date < b.date ? -1 : 1))[0];
    if (dl) parts.push("Deadline " + fmtShort(dl.date));
    if (isDate(e?.day)) parts.push((e.day < today() ? "You planned " : "Your plan: ") + fmtDate(e.day));
  }
  return parts;
}
// The row that was just added or saved. The list uses it to confirm the save in place.
let justSaved = null;
const isJustSaved = (row) => !!justSaved && justSaved.row === row && Date.now() - justSaved.at < 30000;
function todoPlan(x, cls = "") {
  if (!x.o || !x.s) return "";
  const o = x.o,
    k = esc(x.k),
    title = esc(o.title),
    url = safeUrl(o.url),
    key = "row:" + x.k,
    ev = x.s.event != null && o.dates[x.s.event],
    planning = !ui.coach && ui.planning === x.k,
    more = !!ui.open[key],
    open =
      more ||
      planning ||
      ui.skipping === x.k ||
      (!ui.coach && ui.wk === o.id && !state.weekly[o.id]),
    over = x.e.day < today();
  const weeklyOk = !o.archived && ["club", "service", "leadership"].includes(o.type) && !state.weekly[o.id];
  // What Details adds under the step: the note for a listing that left the catalog, the
  // question to send, the organizer page and the calendar buttons.
  const info = `${o.archived ? '<p class="muted">This listing has left the catalog. Your saved step is still here.</p>' : ""}${x.s.ask && o.ask ? askBox(o) : ""}<div class="actions">${url ? `<a class="btn sm primary" href="${esc(url)}" target="_blank" rel="noopener">Open page ↗</a>` : ""}${calBtns(calForStep(x))}</div>`;
  const press = lastPress();
  if (press.k === x.k && !planning) {
    // After Cancel, focus returns to the row's change-day button. After a day is chosen, it
    // goes to the row itself, which now shows the new day.
    if (press.act === "cancel") focusOn(() => document.getElementById("mv-" + x.k) || document.getElementById("tx-" + x.k));
    else if (press.act === "planday" && ui.focusRow === x.k) focusOn(() => document.getElementById("tx-" + x.k));
  }
  let d = "";
  if (open) {
    d = `<div class="tdetail" id="td-${k}">`;
    if (planning)
      // The picker stays open while Details is shown or hidden underneath it.
      d +=
        dayPicker(o, x.i, {
          selectedStep: x.s,
          extra: `<button class="btn text more" id="more-row-${k}" data-act="open" data-id="${esc(key)}" aria-expanded="${more}">${more ? "Less" : "Details"}<span class="vh"> for ${title}</span>${chev(more)}</button>`,
        }) + (more ? info : "");
    else if (ui.skipping === x.k)
      d += `<div class="chips">${SKIPS.map((r) => `<button class="chip sm" data-act="skipwhy" data-k="${k}" data-r="${esc(r)}">${esc(r)}</button>`).join("")}</div><div><button class="btn text" data-act="cancel">Cancel</button></div>` + (more ? info : "");
    else if (!ui.coach && ui.wk === o.id && weeklyOk) d += wkForm(o) + (more ? info : "");
    else
      d += `<p class="tfull">${esc(x.s.text)}</p>${info}<div class="actions">${ev ? "" : `<button class="btn text" data-act="pickday" data-k="${k}">${isDate(x.e.day) ? (over ? "Move it" : "Change my day") : "Pick a day (optional)"}</button>`}${weeklyOk ? `<button class="btn text" data-act="wk" data-id="${esc(o.id)}">Add a repeating meeting time</button>` : ""}<button class="btn text" data-act="${over ? "skip" : "unplan"}" data-k="${k}">${over ? "Drop it" : "Remove"}</button></div>`;
    d += `</div>`;
  } else if (isJustSaved(x.k))
    d = `<div class="tdetail saved" role="status"><p class="savedmsg">${isDate(x.e.day) ? "On your list for " + fmtDate(x.e.day) : "Added to your list."}</p><div class="actions">${calBtns(calForStep(x))}</div></div>`;
  const parts = whenParts(o, x.s, x.e).map(esc);
  if (x.s.weeklyMeeting && !ev) parts.push(esc(x.s.weeklyMeeting));
  const when = over
    ? (ev ? "Event was " : "You planned ") + fmtDate(x.e.day) + ". Did it happen?"
    : parts.length ? parts.join(" · ") : "On your list";
  return `<div class="todo ${cls} ${over ? "is-over" : ""} ${ui.focusRow === x.k ? "flash" : ""}" data-row="${k}"><button class="check tbox" aria-pressed="false" aria-label="Mark done: ${title}" data-act="done" data-k="${k}"><i class="box"></i></button><button class="ttext" id="tx-${k}" data-act="open" data-id="${esc(key)}" aria-expanded="${more}"${open ? ` aria-controls="td-${k}"` : ""}><span class="tt">${title}</span><span class="mini">${when}</span></button>${ev ? "" : `<button class="tact" id="mv-${k}" data-act="pickday" data-k="${k}" aria-label="${over ? "Move" : isDate(x.e.day) ? "Change day for" : "Pick an optional day for"} ${title}">${DAY_ICON}</button>`}${tchev(key, more)}${d}</div>`;
}
function todoWeekly(x, cls = "") {
  const o = x.o,
    w = x.w,
    id = esc(o.id),
    title = esc(o.title),
    url = safeUrl(o.url),
    key = "wk:" + o.id,
    open = !!ui.open[key] || ui.wk === o.id;
  let d = "";
  if (open)
    d = `<div class="tdetail" id="td-wk-${id}">${ui.wk === o.id ? wkForm(o) : `<div class="actions">${url ? `<a class="btn sm primary" href="${esc(url)}" target="_blank" rel="noopener">Open page ↗</a>` : ""}${calBtns(weeklyFor(o, w))}</div><div class="actions"><button class="btn text" data-act="wk" data-id="${id}">Change time</button><button class="btn text" data-act="wkstop" data-id="${id}">Stop</button></div>`}</div>`;
  else if (isJustSaved("wk-" + o.id))
    d = `<div class="tdetail saved" role="status"><p class="savedmsg">Meeting schedule saved.</p><div class="actions">${calBtns(weeklyFor(o, w))}</div></div>`;
  return `<div class="todo ${cls} ${x.went ? "is-done" : ""} ${x.due && x.date < today() ? "is-over" : ""} ${ui.focusRow === "wk-" + o.id ? "flash" : ""}" data-row="wk-${id}"><button class="check tbox" aria-pressed="${x.went}" ${x.date > today() ? "disabled" : ""} aria-label="Mark attended: ${title}" data-act="went" data-id="${id}"><i class="box"></i></button><button class="ttext" id="tx-wk-${id}" data-act="open" data-id="${esc(key)}" aria-expanded="${open}"${open ? ` aria-controls="td-wk-${id}"` : ""}><span class="tt">${title}</span><span class="mini">${w.interval === 2 ? "Every two weeks · " + fmtDate(x.date) : "Every " + DOW[+w.day]}, ${fmtTime(w.time)}${w.place ? " · " + esc(w.place) : ""}</span></button>${tchev(key, open)}${d}</div>`;
}
function todoDone(x, cls = "") {
  if (!x.o || !x.s) return "";
  const o = x.o,
    k = esc(x.k),
    title = esc(o.title),
    key = "done:" + x.k,
    weeklyOk = ["club", "service", "leadership"].includes(o.type) && !state.weekly[o.id],
    open = !!ui.open[key] || (!ui.coach && ui.wk === o.id && weeklyOk);
  let d = "";
  if (open)
    d = `<div class="tdetail" id="td-done-${k}">${!ui.coach && ui.wk === o.id && weeklyOk ? wkForm(o) : `<label class="f">Note to yourself (optional)<input type="text" id="note-${k.replace(":", "-")}" data-note="${k}" value="${esc(x.e.note || "")}" placeholder="Meets Tuesdays at 6 in Todd 216"></label>${weeklyOk ? `<div class="actions"><button class="btn sm wheat" data-act="wk" data-id="${esc(o.id)}">Add a repeating meeting time</button></div>` : ""}`}</div>`;
  return `<div class="todo ${cls} is-done"><button class="check tbox" aria-pressed="true" aria-label="Undo done: ${title}" data-act="undo" data-k="${k}"><i class="box"></i></button><button class="ttext" id="tx-done-${k}" data-act="open" data-id="${esc(key)}" aria-expanded="${open}"${open ? ` aria-controls="td-done-${k}"` : ""}><span class="tt">${title}</span><span class="mini">Done ${isDate(x.e.at) ? fmtShort(x.e.at) : ""}${x.e.note ? " · " + esc(x.e.note) : ""}</span></button>${tchev(key, open)}${d}</div>`;
}
// The saved list. It shows the first rows and keeps the rest one tap away, so a long list
// never pushes this week's pick off a phone screen. Returns "" when nothing is saved.
function todoList() {
  if (ui.focusRow) justSaved = { row: ui.focusRow, at: Date.now() };
  const todo = planned()
    .filter((x) => x.o && x.s)
    .map((x) => ({ d: x.e.day, row: (c) => todoPlan(x, c) }))
    .concat(
      weeklyList(true)
        .filter((x) => !x.went)
        .map((x) => ({ d: x.date, row: (c) => todoWeekly(x, c) })),
    )
    .sort((m, n) => (m.d < n.d ? -1 : m.d > n.d ? 1 : 0));
  const done = weeklyList()
    .filter((x) => x.went)
    .map((x) => ({ row: (c) => todoWeekly(x, c) }))
    .concat(
      doneThisWeek()
        .filter((x) => x.o && x.s)
        .map((x) => ({ row: (c) => todoDone(x, c) })),
    );
  const rows = todo.concat(done).map((r, i) => r.row(i >= 4 ? "m-more d-more" : i >= 2 ? "m-more" : "")),
    n = rows.length;
  if (!n) return "";
  // A row that is open, being changed or just saved is never left hidden.
  const active = (h) => /class="tdetail|\bflash\b/.test(h),
    all = !!ui.open["list:all"] || rows.some((h, i) => i >= 4 && active(h)),
    allPhone = all || rows.some((h, i) => i >= 2 && active(h));
  return `<div class="panel todos ${all ? "all" : ""} ${allPhone ? "all-m" : ""}"><div class="lhead"><h3 id="list-h">Your list</h3><small class="lweek">${weekSpan(weekStart(), weekEnd())}</small><small>${todo.length ? todo.length + " to do" : "All done"}</small>${n > 2 ? `<button class="btn text showall ${n > 4 ? "" : "m-only"}" id="showall" data-act="open" data-id="list:all" aria-expanded="${all}">${all ? "Show fewer" : "Show all " + n}</button>` : ""}</div>${rows.join("")}</div>`;
}
// The top of the weekly screen: which week it is, progress and the streak, in one compact band.
function weekHead() {
  const p = prof(),
    dw = weekCount(),
    goal = 3,
    circ = 2 * Math.PI * 40,
    st = streak(),
    tr = track();
  return `<header class="wkhead"><div class="wkhead-t"><div class="eyebrow">${DOWL[state.weekStartsOn]} edition${p.name ? " · Hi " + esc(p.name) : ""}</div><h1>${fullToday()}</h1></div>
  <div class="wkhead-p"><div class="ring ${ui.flash === "ring" ? "pop" : ""}"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="bgc" cx="50" cy="50" r="40"/><circle class="fg" cx="50" cy="50" r="40" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - Math.min(1, dw / goal))}"/></svg><b aria-hidden="true">${dw}</b></div><div class="wkp"><strong class="track ${tr.state}"><i></i>${tr.label}</strong><small>${dw} of ${goal} done this week</small></div>
  <div class="streak ${st > 0 ? "lit" : ""}"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M12 2c1 3.5 5.5 5.6 5.5 11A5.5 5.5 0 0 1 12 18.5 5.5 5.5 0 0 1 6.5 13c0-2 .8-3.3 2-4.6.3 1.5 1 2.4 2 2.9C10 8 10.6 4.6 12 2Z" fill="currentColor"/><path d="M8 21.5h8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><b>${st}</b><span>week streak</span><div class="wdots" role="img" aria-label="Weeks with something done, last six: ${weeksHit(6).filter(Boolean).length}">${weeksHit(
    6,
  )
    .map((x) => `<i class="${x ? "on" : ""}"></i>`)
    .join("")}</div></div></div></header>`;
}
// The season's focus checklist. It stays folded until the student opens it.
function focusPanel() {
  const yi = Math.max(0, Math.min(3, +prof().year - 1)),
    si = SEASON(now().getMonth()),
    fo = FOCUS[yi][si],
    fk = ayEnd() + ":" + yi + ":" + si + ":",
    items = fo.slice(1),
    done = items.filter((t, i) => state.focus[fk + i]).length,
    open = !!ui.open["focus"];
  return `<section class="panel focus ${open ? "open" : ""}"><h3><button class="fhead" id="fhead" data-act="open" data-id="focus" aria-expanded="${open}"><span>Focus: ${esc(fo[0])}<small>${YEARS[yi + 1]} · ${SEASONS[si].toLowerCase()}</small></span><em>${done} of ${items.length}</em>${chev(open)}</button></h3>${
    open
      ? items
          .map(
            (t, i) =>
              `<button class="check frow" aria-pressed="${!!state.focus[fk + i]}" data-act="focus" data-v="${fk + i}"><i class="box"></i><span>${esc(t)}</span></button>`,
          )
          .join("") +
        (EARLY[grp()] && yi < 3
          ? `<p class="mini">In your field, employers often hire interns close to a year ahead.</p>`
          : "")
      : ""
  }</section>`;
}
function feedLine() {
  const m = feed.meta,
    at = m && isDate((m.updatedAt || "").slice(0, 10)) ? fmtShort(m.updatedAt.slice(0, 10)) : null,
    f = FEEDS.meta;
  return `<div class="status ${f ? "live" : ""}"><span><i></i>${f && isDate(f.builtAt) ? "Catalog checked " + fmtShort(f.builtAt) + " · Check organizer pages for changes" : "Loading clubs and events"}${at ? " · WSU deadlines checked " + at : ""} · ${LIST.length} listings${f?.failedSources?.length ? " · Some sources could not refresh. Earlier listings are shown." : ""}</span></div>`;
}
