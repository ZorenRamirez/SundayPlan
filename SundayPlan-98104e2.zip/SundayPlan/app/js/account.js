"use strict";
const sundayAccount = (() => {
  let client, owner, sync, loaded = false, status = "loading", generation = 0;
  let accountEmail = "", deleting = false, deletionNotice = false;
  const projectUrl = () => window.SUNDAY_CONFIG.url;
  const draftKey = id => "sp-draft:" + projectUrl() + ":" + id;
  const deletionSignal = () => "sp-deleted:" + projectUrl();
  function forgetDraft(id) {
    try {
      sessionStorage.removeItem(draftKey(id));
      sessionStorage.removeItem(draftKey(id) + ":conflict-backup");
    } catch {}
  }
  const labels = { synced:"Saved to your account", pending:"Saving…", offline:"Saved in this tab · sync pending", conflict:"Another session changed this plan", volatile:"Keep this tab open · waiting to save" };
  const statusText = () => labels[status] || "Connecting to your account";
  function setStatus(value) {
    status = value;
    if (typeof setSaveState === "function" && labels[value]) setSaveState(value === "synced" ? "saved" : value === "pending" ? "saving" : value);
    const statusNode = document.querySelector("[data-account-status]");
    if (statusNode) statusNode.textContent = statusText();
    const controls = document.querySelector("[data-sync-actions]");
    if (controls) controls.innerHTML = syncActions();
  }
  function syncActions() {
    if (status === "conflict") return '<button class="btn ghost sm" data-account="reload">Use the version saved online</button><button class="btn text" data-account="export">Download my draft</button>';
    if (status === "offline" || status === "volatile") return '<button class="btn ghost sm" data-account="retry">Retry save</button>';
    return "";
  }
  function controls() {
    return '<section class="profile-account"><div><h3>Your account</h3><span>' + esc(accountEmail || "Signed in with Google") +
      '</span></div><button class="btn ghost sm" data-account="logout">Sign out</button><span data-sync-actions>' + syncActions() + '</span></section>';
  }
  function gate(title, details, actions = "") {
    loaded = false;
    document.getElementById("root").innerHTML = '<main class="account-gate"><section class="account-card"><div class="brand"><i></i>Sunday Plan</div><h1>' + esc(title) + '</h1><p class="sub">' + esc(details) + '</p><div class="actions">' + actions + '</div></section></main>';
  }
  const retry = '<button class="btn primary" data-account="refresh">Try again</button>';
  const logout = '<button class="btn ghost" data-account="logout">Sign out</button>';
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }
  function emailForm(signup) {
    return `<form class="auth-form" data-auth-form="${signup ? "signup" : "signin"}" novalidate>
      ${signup ? '<label class="f">Name<input type="text" name="name" autocomplete="name" placeholder="First and last name" required></label>' : ""}
      <label class="f">Email<input type="email" name="email" autocomplete="email" placeholder="you@wsu.edu" required></label>
      <label class="f">Password<input type="password" name="password" autocomplete="${signup ? "new-password" : "current-password"}" minlength="8" placeholder="${signup ? "At least 8 characters" : "Your password"}" required></label>
      <p class="auth-msg" data-auth-msg role="status" aria-live="polite"></p>
      <button class="btn primary" type="submit">${signup ? "Create account" : "Log in"}</button></form>`;
  }
  function authMessage(text, bad = true) {
    const node = document.querySelector("[data-auth-msg]");
    if (node) { node.textContent = text; node.classList.toggle("bad", bad); }
  }
  async function submitAuth(form) {
    const field = name => String(form.elements?.[name]?.value || "").trim();
    const kind = form.dataset.authForm, email = field("email"), password = form.elements?.password?.value || "", name = field("name");
    if (kind === "signup" && !name) return authMessage("Enter your name.");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return authMessage("Enter a valid email address.");
    if (kind === "signup" && password.length < 8) return authMessage("Choose a password with at least 8 characters.");
    if (!password) return authMessage("Enter your password.");
    authMessage("One moment…", false);
    try {
      if (kind === "signup") {
        const {data, error} = await client.auth.signUp({email, password, options:{
          emailRedirectTo: location.origin + location.pathname, data:{given_name:name.split(/\s+/)[0], full_name:name}}});
        if (error) throw error;
        // An address that is already registered comes back without identities and without an error.
        if (data?.user && Array.isArray(data.user.identities) && !data.user.identities.length) return authMessage("That email already has an account. Log in instead.");
        if (!data?.session) authMessage("Check " + email + " for a confirmation link, then log in.", false);
      } else {
        const {error} = await client.auth.signInWithPassword({email, password});
        if (error) throw error;
      }
    } catch (error) {
      const text = String(error?.message || "");
      authMessage(/not confirmed/i.test(text) ? "Confirm your email first. Check your inbox for the link." :
        /invalid login/i.test(text) ? "That email and password don’t match." :
        /rate|too many/i.test(text) ? "Too many tries. Wait a minute and try again." :
        kind === "signup" ? "Couldn’t create the account. Check the details and try again." : "Couldn’t log in. Check your connection and try again.");
    }
  }
  async function showLogin(active) {
    const signup = location.hash === "#signup";
    const fallback = `<button class="btn ghost" data-account="login">${signup ? "Sign up with Google" : "Continue with Google"}</button>`;
    loaded = false;
    // Logging in and creating an account are separate pages. Each shows one Google button.
    const intro = signup
      ? `<h1>Start your first week</h1><p>Tell Sunday Plan what you want more of. It picks real steps from WSU listings and puts each one on a day.</p>
      <div class="login-example"><span>An example week</span><ul><li><b>Mon</b>Ask a finance club when it meets</li><li><b>Wed</b>Open the WSU scholarship application</li><li><b>Thu</b>Set up your Handshake profile</li></ul></div>`
      : `<h1>Your week at WSU</h1><p>Turn clubs, scholarships and career opportunities into a weekly list you can actually finish.</p>`;
    const next = signup ? `<ol class="login-steps">
      <li><span><b>Sign up with Google</b>Sunday Plan uses your name and email to keep your plan private to you.</span></li>
      <li><span><b>Answer a few quick questions</b>Your year, major, interests and how much you want to take on.</span></li>
      <li><span><b>Get your first week</b>Up to three real steps, each with a reason and a day.</span></li></ol>
      <p class="login-note">Used this Google account here before? You’ll go straight to your saved plan.</p>` : "";
    document.getElementById("root").innerHTML = `<main class="account-gate"><section class="login-panel ${signup ? "is-signup" : ""}" aria-labelledby="login-heading">
      <div class="login-intro"><div class="brand"><i></i>Sunday Plan</div>
      ${intro}</div>
      <div class="login-form">
      ${deletionNotice ? '<p class="account-notice" role="status">Your Sunday Plan account and saved plan were deleted.</p>' : ""}
      <h2 id="login-heading">${signup ? "Create your account" : "Log in to Sunday Plan"}</h2><p>${signup ? "Sign up with Google, answer a few questions and get your first weekly plan." : "Open your weekly plan and pick up where you left off."}</p>
      ${emailForm(signup)}
      <div class="login-or"><span>or</span></div>
      ${fallback}
      ${next}
      <p class="login-new">${signup ? 'Already have an account? <a href="#signin">Log in</a>' : 'New to Sunday Plan? <a href="#signup">Create an account</a>'}</p></div></section></main>`;
  }
  async function openSession(session) {
    const id = session?.user?.id;
    if (generation && owner === id) return;
    generation++;
    const token = generation, active = () => token === generation && owner === id;
    sync?.stop();
    sync = null; owner = id; accountEmail = session?.user?.email || ""; loaded = false; state = fresh();
    ui = freshUI();
    ui.tab = sectionFromUrl();
    if (!id) {
      await showLogin(active);
      return;
    }
    deletionNotice = false;
    if (["#signin","#signup"].includes(location.hash)) history.replaceState(null,"","#week");
    gate("Opening your planner", "Loading your saved profile and weekly plan.");
    const table = () => client.from("student_plans");
    async function read() {
      const {data,error} = await table().select("payload,revision").eq("user_id", id).maybeSingle();
      if (error) throw error;
      return data;
    }
    async function write(base, payload) {
      const query = base === 0 ? table().insert({user_id:id, payload, revision:1}) :
        table().update({payload, revision:base+1}).eq("user_id",id).eq("revision",base);
      const {data,error} = await query.select("revision").maybeSingle();
      if (error?.code === "23505") return null;
      if (error) throw error;
      return data?.revision ?? null;
    }
    try {
      const verified = await client.auth.getUser(session.access_token);
      if (!active()) return;
      if (verified.error) {
        if (["user_not_found","session_not_found","session_expired"].includes(verified.error.code)) {
          if (verified.error.code === "user_not_found") forgetDraft(id);
          await client.auth.signOut({scope:"local"});
          if (active()) await openSession(null);
          return;
        }
        throw verified.error;
      }
      if (verified.data.user?.id !== id) throw Error("Account changed");
      sync = createPlanSync({storage:sessionStorage, key:draftKey(id), read, write, active, onStatus:setStatus,
        merge:mergePlans, onMerged:payload => { state = adopt(payload); render(); }});
      const [saved, catalog] = await Promise.all([sync.load(), fetch("data/curated.json").then(r => {
        if (!r.ok) throw new Error("Catalog unavailable"); return r.json();
      })]);
      if (!active()) return;
      state = adopt(saved);
      if (!saved) state.profile.name = String(session.user.user_metadata?.given_name || session.user.user_metadata?.full_name || "").trim().split(/\s+/)[0].slice(0,40);
      CUR = catalog.listings.map(row => clean(row,row.id)).filter(Boolean);
      feed.meta = catalog.meta; feed.state = "live"; LIST = build();
      downloads = await window.claude.use("downloads");
      if (!active()) return;
      loaded = true; render(); loadCatalog();
    } catch {
      if (active()) gate("Your plan could not be loaded", "Check your connection and that the Sunday Plan database has been set up.", retry + logout);
    }
  }
  async function deleteMyAccount() {
    if (!loaded || !owner || !ui.confirmReset || deleting) return;
    const id = owner, sameOwner = () => owner === id;
    deleting = true;
    gate("Deleting your account", "Removing your Sunday Plan profile and saved list.");
    try {
      const {data, error} = await client.auth.getSession();
      if (error || !sameOwner() || data.session?.user?.id !== id) throw Error("Sign in again");
      // Pin the request to the identity that saw the confirmation, even if another tab switches accounts.
      const response = await fetch(projectUrl() + "/rest/v1/rpc/delete_my_sunday_plan_account", {
        method:"POST", headers:{apikey:window.SUNDAY_CONFIG.key, Authorization:"Bearer " + data.session.access_token,
          "Content-Type":"application/json"}, body:"{}", signal:AbortSignal.timeout(20000)
      });
      if (!response.ok) throw Error("Deletion unconfirmed");
    } catch {
      if (sameOwner()) {
        loaded = true; ui.confirmReset = true; ui.resetError = "Deletion couldn’t be confirmed. Check your connection and try again.";
        render();
      }
      deleting = false;
      return;
    }
    if (sameOwner()) sync?.stop();
    forgetDraft(id);
    try { localStorage.setItem(deletionSignal(),id); localStorage.removeItem(deletionSignal()); } catch {}
    if (sameOwner()) {
      deletionNotice = true;
      history.replaceState(null,"","#signup");
      window.google?.accounts?.id?.disableAutoSelect?.();
      // A deleted user may already have lost their remote session.
      try {
        const {data} = await client.auth.getSession();
        if (data.session && data.session.user.id !== id) {
          await openSession(data.session);
          return;
        }
        await client.auth.signOut({scope:"local"});
      } finally {
        if (sameOwner()) await openSession(null);
        deleting = false;
      }
    }
    deleting = false;
  }
  window.addEventListener("hashchange", () => {
    if (!client || owner || !["#signin","#signup"].includes(location.hash)) return;
    const token = generation;
    void showLogin(() => !owner && token === generation);
  });
  window.addEventListener("storage", event => {
    if (window.SUNDAY_CONFIG?.mode !== "cloud" || event.key !== deletionSignal() || !event.newValue) return;
    forgetDraft(event.newValue);
    if (owner === event.newValue) {
      sync?.stop(); deletionNotice = true; history.replaceState(null,"","#signup"); void openSession(null);
    }
  });
  async function start() {
    if (window.SUNDAY_CONFIG?.mode !== "cloud") {
      gate("This build needs a database connection", "Set the project URL and publishable key before sharing this build.");
      return;
    }
    gate("Opening Sunday Plan", "Connecting to student sign-in.");
    try {
      await loadScript("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2");
      const {url,key} = window.SUNDAY_CONFIG;
      client = window.supabase.createClient(url,key,{auth:{flowType:"pkce", persistSession:true, autoRefreshToken:true, detectSessionInUrl:true}});
      client.auth.onAuthStateChange((event,session) => {
        // No SDK calls inside this callback while the SDK holds its auth lock.
        if (event === "INITIAL_SESSION" || event === "SIGNED_IN" || event === "SIGNED_OUT")
          setTimeout(() => { void openSession(session); },0);
      });
    } catch { gate("Sign-in could not start", "Check your connection and try again.", retry); }
  }
  document.addEventListener("submit", e => {
    const form = e.target?.closest?.("[data-auth-form]");
    if (!form || !client) return;
    e.preventDefault();
    void submitAuth(form);
  });
  document.addEventListener("click", async e => {
    const action = e.target.closest("[data-account]")?.dataset.account;
    if (!action) return;
    try {
      if (action === "login") {
        authMessage("Opening Google…", false);
        const result = await client.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin + location.pathname,queryParams:{prompt:"select_account"}}});
        if (result.error) throw result.error;
      } else if (action === "delete") {
        await deleteMyAccount();
      } else if (action === "logout") {
        await sync?.flush();
        if (sync && status !== "synced" && !window.confirm("This tab has unsynced edits. Keep it open to finish saving. Sign out anyway?")) return;
        deletionNotice = false;
        history.replaceState(null,"","#signin");
        const {error} = await client.auth.signOut({scope:"local"});
        if (error) throw error;
        window.google?.accounts?.id?.disableAutoSelect?.();
        await openSession(null);
      } else if (action === "refresh") location.reload();
      else if (action === "retry") await sync?.flush();
      else if (action === "reload") {
        const current = sync, saved = await current.useRemote();
        if (current !== sync) return;
        state = adopt(saved); render();
      } else if (action === "export") {
        await downloads.save({filename:"sunday-plan-draft.json",data:new Blob([JSON.stringify(state,null,2)],{type:"application/json"})});
      }
    } catch {
      if (loaded) toast("The account request failed. Please try again.");
      else if (document.querySelector("[data-auth-msg]")) authMessage("That didn’t work. Check your connection and try again.");
      else gate("Sign-in needs another try", "Check the Google provider and your connection.", retry); }
  });
  window.addEventListener("online", () => sync?.flush());
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") sync?.flush(); });
  async function rankingToken() {
    const {data} = await client.auth.getSession();
    return loaded && data.session?.user?.id === owner ? data.session.access_token : null;
  }
  return {start,rankingToken,ready:() => loaded,save:payload => sync?.queue(payload),retry:() => sync?.flush(),controls,statusText,email:() => accountEmail};
})();
