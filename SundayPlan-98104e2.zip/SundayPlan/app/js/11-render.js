/*
  11-render.js — puts the current screen on the page.

  The icons and tab list (TABS), the sidebar and phone tab bar, and render(), which
  redraws everything inside <div id="root"> whenever something changes.
*/
"use strict";
const ICON = {
  week: '<path d="M4 6h16M4 12h10M4 18h7"/>',
  month: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  clubs:
    '<circle cx="9" cy="9" r="3.2"/><path d="M3.5 19c.6-3.2 3-4.8 5.5-4.8s4.9 1.6 5.5 4.8M16 6.5a3 3 0 0 1 0 5.6M18 14.6c1.5.7 2.4 2.1 2.7 4.4"/>',
  jobs: '<rect x="4" y="8" width="16" height="11" rx="2.5"/><path d="M9 8V6.5A1.5 1.5 0 0 1 10.5 5h3A1.5 1.5 0 0 1 15 6.5V8M4 13h16"/>',
  explore: '<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5"/>',
  path: '<path d="M5 19V9l7-5 7 5v10M10 19v-5h4v5"/>',
  you: '<circle cx="12" cy="8" r="4"/><path d="M4 20c1.5-4 14.5-4 16 0"/>',
};
// id, sidebar label, phone label, shown in the phone tab bar
const TABS = [
  ["week", "This week", "Week", 1],
  ["month", "Coming up", "Dates", 0],
  ["clubs", "Campus clubs", "Clubs", 1],
  ["jobs", "Internships", "Jobs", 1],
  ["explore", "Explore all", "Explore", 1],
  ["path", "Four years", "4 years", 0],
  ["you", "Profile", "Profile", 1],
];
const navBtn = (t, due, cls) =>
  `<button class="${cls}" data-act="tab" data-v="${t[0]}" ${ui.tab === t[0] ? 'aria-current="page"' : ""}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[t[0]]}</svg><span class="tl">${t[1]}</span><span class="ts">${t[2]}</span>${t[0] === "week" && due ? '<i class="dot" title="Check-in waiting"></i>' : ""}</button>`;
// Signed-in accounts get a sign-out button on every screen. The device-only tester has no account.
const signOutButton = () => (window.SUNDAY_CONFIG?.mode === "cloud" ? '<button class="btn ghost sm signout" type="button" data-account="logout">Sign out</button>' : "");
function render() {
  if (!deviceProfile && !sundayAccount.ready()) return;
  const ae = document.activeElement,
    fid = ae && ae.id,
    sel = fid && ae.selectionStart != null ? [ae.selectionStart, ae.selectionEnd] : null,
    sy = window.scrollY;
  calCache.clear();
  const root = $("#root");
  if (ui.planStage || !prof().setup) {
    document.documentElement.style.height = "100%";
    document.body.style.height = "100%";
    root.style.height = "100%";
    root.innerHTML = ui.planStage ? viewPlanGeneration() : viewOnboard();
  } else {
    document.documentElement.style.height = "";
    document.body.style.height = "";
    root.style.height = "";
    const due = dueCheckins().length + weeklyList().filter((x) => x.due).length;
    const v = {
      week: viewWeek,
      month: viewMonth,
      clubs: viewClubs,
      jobs: viewJobs,
      explore: viewExplore,
      path: viewPath,
      you: viewYou,
    }[ui.tab]();
    const p = prof(),
      st = streak();
    root.innerHTML = `<div class="shell"><aside class="side"><div class="brand"><i></i>Sunday Plan</div><div class="sidelab">Your planner</div><nav class="sidenav" aria-label="Sections">${TABS.map((t) => navBtn(t, due, "snav")).join("")}</nav><div class="sidefoot">${saveChip()}${signOutButton()}${ui.tab === "week" ? "" : `<div class="sstreak ${st > 0 ? "lit" : ""}"><b>${st}</b><span>week streak</span></div>`}<button class="who" data-act="tab" data-v="you"><span class="av">${esc((p.name || "?").trim().charAt(0).toUpperCase() || "?")}</span><span><b>${esc(p.name || "Your profile")}</b><small>${esc(majorRow()[1])} · ${p.grad || ""}</small></span></button></div></aside>
    <div class="col"><header class="mtop"><div class="brand"><i></i>Sunday Plan</div>${saveChip()}${signOutButton()}${st > 0 && ui.tab !== "week" ? `<span class="mstreak">${st}-week streak</span>` : ""}</header><main class="wrap">${v}<div class="footer">Confirm details with the organizer before you go.${feedLine()}</div></main></div>
    <nav class="tabs" aria-label="Sections">${TABS.filter((t) => t[3])
      .map((t) => navBtn(t, due, "tab"))
      .join("")}</nav></div>`;
  }
  ui.flash = null;
  ui.anim = false;
  if (ui.dd) ddFocus();
  if (ui.focusRow) {
    const r = document.querySelector('[data-row="' + ui.focusRow + '"]');
    ui.focusRow = null;
    if (r)
      r.scrollIntoView({
        block: "center",
        behavior: matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth",
      });
    return;
  }
  if (fid) {
    const el = document.getElementById(fid);
    if (el) {
      el.focus({ preventScroll: true });
      if (sel && el.setSelectionRange)
        try {
          el.setSelectionRange(sel[0], sel[1]);
        } catch (e) {}
    }
  }
  window.scrollTo(0, sy);
}
