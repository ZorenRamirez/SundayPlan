/*
  01-reference-data.js — the fixed lists the app is built on.

  WSU majors, the kinds of opportunity (clubs, internships, scholarships...), year names,
  commitment levels, weekly habits and the four-year roadmap text.
  This is wording that we wrote, not live data. Change a label or add a major here.
*/
"use strict";
/* ---------- static reference data (ours, not live listings) ---------- */
const MAJORS = (() => {
  const C = "Carson College of Business",
    V = "Voiland College of Engineering and Architecture",
    A = "College of Arts and Sciences",
    H = "College of Agricultural, Human, and Natural Resource Sciences",
    M = "Murrow College of Communication",
    E = "College of Education, Sport, and Human Sciences",
    F = "Elson S. Floyd College of Medicine",
    N = "College of Nursing",
    T = "College of Veterinary Medicine";
  const g = (grp, col, carson, names) => names.map((n) => [grp, n, carson, col]);
  return [].concat(
    [
      ["finance", "Finance", 1, C],
      ["accounting", "Accounting", 1, C],
      ["marketing", "Marketing", 1, C],
      ["management", "Management", 1, C],
      ["mis", "Management Information Systems", 1, C],
      ["entrepreneurship", "Entrepreneurship", 1, C],
      ["intlbus", "International Business", 1, C],
      ["hospitality", "Hospitality Business Management", 1, C],
      ["hospitality", "Wine and Beverage Business Management", 1, C],
      ["business", "Business, not certified in a major yet", 1, C],
    ],
    g("cs", V, 0, ["Computer Science", "Software Engineering", "Computer Engineering"]),
    g("engineering", V, 0, [
      "Architecture",
      "Bioengineering",
      "Chemical Engineering",
      "Civil Engineering",
      "Construction Engineering",
      "Construction Management",
      "Electrical Engineering",
      "Interior Design",
      "Landscape Architecture",
      "Materials Science and Engineering",
      "Mechanical Engineering",
    ]),
    g("artsci", A, 0, [
      "Anthropology",
      "Asian Studies",
      "Basic Medical Sciences",
      "Biology",
      "Chemistry",
      "Comparative Ethnic Studies",
      "Criminal Justice and Criminology",
      "Digital Technology and Culture",
      "English",
      "Fine Arts",
      "Foreign Languages and Cultures",
      "History",
      "Human Biology",
      "Humanities",
      "Mathematics",
      "Music",
      "Philosophy",
      "Physics and Astronomy",
      "Political Science",
      "Psychology",
      "Public Affairs",
      "Social Sciences",
      "Social Studies",
      "Sociology",
      "Women's Studies",
      "Zoology",
    ]),
    [["cs", "Data Analytics", 0, A]],
    g("agriculture", H, 0, [
      "Agricultural and Food Systems",
      "Animal Sciences",
      "Apparel, Merchandising, Design, and Textiles",
      "Earth and Environmental Sciences",
      "Economic Sciences",
      "Food Science",
      "Human Development",
      "Integrated Plant Sciences",
    ]),
    g("communication", M, 0, ["Journalism and Media Production", "Strategic Communication"]),
    g("education", E, 0, [
      "Education",
      "Kinesiology",
      "Secondary Education",
      "Sport Management",
      "Sports Medicine",
    ]),
    g("health", F, 0, ["Nutrition and Exercise Physiology", "Speech and Hearing Sciences"]),
    g("health", N, 0, ["Nursing"]),
    g("health", T, 0, ["Biochemistry", "Genetics and Cell Biology", "Microbiology", "Neuroscience"]),
    [["undecided", "Undecided or exploring", 0, "Still deciding"]],
  );
})();
const TYPES = {
  career: ["Internships and jobs", "Career"],
  scholarship: ["Scholarships", "Scholarship"],
  club: ["Clubs", "Club"],
  service: ["Volunteering", "Service"],
  competition: ["Competitions", "Competition"],
  leadership: ["Leadership roles", "Leadership"],
  program: ["Outside programs", "Program"],
  event: ["Campus events", "Event"],
};
const YEARS = ["", "First-year", "Sophomore", "Junior", "Senior"];
const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  DOWL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
  MONL = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
const PRIORITIES = {
  balanced: {label:"Explore my options", types:[]},
  people: {label:"Meet people", types:["club","event","service"]},
  experience: {label:"Build experience", types:["career","competition","service","leadership"]},
  funding: {label:"Find funding", types:["scholarship"]},
};
const COMMIT = {
  light: [60, "Light", "About an hour a week"],
  steady: [120, "Steady", "Two to three hours a week"],
  allin: [300, "All in", "Five hours or more a week"],
};
const SKIPS = [
  "No time this week",
  "Did not want to go alone",
  "Not interested",
  "Listing looked wrong",
];
const SEASON = (m) =>
  m === 7 || m === 8
    ? 0
    : m === 9 || m === 10
      ? 1
      : m === 11 || m === 0
        ? 2
        : m === 1 || m === 2
          ? 3
          : m === 3 || m === 4
            ? 4
            : 5;
const SEASONS = ["Start of fall", "Mid fall", "Winter break", "Early spring", "Late spring", "Summer"];
const FOCUS = [
  [
    [
      "Get set up",
      "Go to two club meetings and keep the one you liked",
      "Finish your Handshake profile",
      "Walk through the fall career expo just to look",
    ],
    [
      "Find your people",
      "Get to one club meeting before finals",
      "Start the WSU General Scholarship Application",
      "Write a one-page résumé, even if it is short",
    ],
    [
      "Use the break",
      "Submit the scholarship application by Jan 31",
      "Finish one free job simulation in a field you are curious about",
      "Ask one person in a job you want how they got there",
    ],
    [
      "Show up",
      "Go to the spring career expo and talk to three employers",
      "Apply to two first-year programs or summer jobs",
      "Book one career coaching chat",
    ],
    [
      "Lock in your summer",
      "Confirm a summer job, class or volunteer role",
      "Ask to help run one thing in your club next year",
      "Update your résumé with this year",
    ],
    [
      "Build one story",
      "Do your summer role well enough to talk about it",
      "Have one informational chat a month",
      "List five employers to meet at the fall expo",
    ],
  ],
  [
    [
      "Step up",
      "Take a committee or project role in your club",
      "Go to the fall expo with five target employers",
      "Start applying for next summer",
    ],
    [
      "Apply early",
      "Send five internship applications before finals",
      "Get your résumé reviewed",
      "Reapply for scholarships",
    ],
    [
      "Keep the pipeline moving",
      "Submit the scholarship application by Jan 31",
      "Send five more applications over break",
      "Practise two interview answers out loud",
    ],
    [
      "Close the gap",
      "Work the spring expo for anything still open",
      "Follow up on every application older than two weeks",
      "Enter one competition with a teammate",
    ],
    [
      "Lock in your summer",
      "Confirm an internship, research role or job",
      "Run for an officer role",
      "Ask a professor or supervisor to be a reference",
    ],
    [
      "Make the summer count",
      "Ask for one project you can show afterwards",
      "Keep a weekly note of what you did",
      "Line up fall applications for junior-summer internships",
    ],
  ],
  [
    [
      "Internship season",
      "Apply to ten junior-summer internships by October",
      "Go to the fall expo and every employer night for your major",
      "Lead something in your club",
    ],
    [
      "Interview well",
      "Do two mock interviews",
      "Follow up on open applications",
      "Reapply for scholarships",
    ],
    [
      "Second wave",
      "Apply to ten more roles over break",
      "Submit the scholarship application by Jan 31",
      "Reconnect with last summer’s contacts",
    ],
    [
      "Land it",
      "Use the spring expo for late openings",
      "Accept an offer and tell the other employers",
      "Ask two people to be references",
    ],
    [
      "Get ready",
      "Learn the tools your internship uses",
      "Hand off club duties for the summer",
      "Set one goal with your future manager",
    ],
    [
      "Turn it into an offer",
      "Ask for feedback at the halfway point",
      "Meet one new person a week",
      "Ask about a return offer before you leave",
    ],
  ],
  [
    [
      "Full-time search",
      "Apply to full-time roles now, since many close before winter",
      "Go to the fall expo with a target list",
      "Tell your network what you are looking for",
    ],
    [
      "Interviews and offers",
      "Keep five applications active",
      "Compare offers on more than salary",
      "Mentor a first-year in your club",
    ],
    [
      "Decide or widen",
      "Widen the search if nothing has landed",
      "Ask a career coach to look over your offer",
      "Thank your references",
    ],
    [
      "Finish strong",
      "Use the spring expo if you are still looking",
      "Hand your officer role to someone you trained",
      "Sort out the move and your start date",
    ],
    [
      "Hand it on",
      "Write down what you would tell a first-year",
      "Stay in touch with three people from WSU",
      "Update Handshake and LinkedIn with your new role",
    ],
    [
      "Start well",
      "Ask your manager what a good first 90 days looks like",
      "Keep in touch with three people from WSU",
      "Set up your budget before the first paycheck",
    ],
  ],
];
const EARLY = { finance: 1, accounting: 1, cs: 1, mis: 1, engineering: 1 };
const HABITS = {
  career: "Open Handshake once and check new postings for your major",
  club: "Go to at least one meeting of your main club",
  service: "Book one volunteer shift",
  scholarship: "Add one scholarship to your list with its deadline",
  competition: "Meet your teammate once and write down what changed",
  leadership: "Offer to run one small thing for a group you are in",
  program: "Compare the cost and payoff of one outside program",
};
const ROAD = [
  {
    name: "First year",
    theme: "Look around and pick a home",
    items: [
      "Try two clubs this year and keep one",
      "Submit the WSU General Scholarship Application by Jan 31",
      "Walk through one career expo to see how it works",
      "Do one volunteer shift each semester",
      "Finish your Handshake profile and upload a first résumé",
    ],
  },
  {
    name: "Sophomore",
    theme: "Take a small job in your club",
    items: [
      "Join a committee or run one event",
      "Get your résumé reviewed before the fall expo",
      "Apply for one summer internship, job shadow or research role",
      "Enter one competition with a teammate",
      "Reapply for scholarships by Jan 31",
    ],
  },
  {
    name: "Junior",
    theme: "Lead something and land the internship",
    items: [
      "Run for an officer role",
      "Go to the fall expo with a list of five employers",
      "Lock in a summer internship",
      "Ask two people who know your work to be references",
      "Reapply for scholarships by Jan 31",
    ],
  },
  {
    name: "Senior",
    theme: "Convert the offer and hand things on",
    items: [
      "Start the full-time search in fall",
      "Bring a first-year to your club",
      "Hand your officer role to someone you trained",
      "Tell your references where you landed",
    ],
  },
];
const ROADX = {
  finance: [
    "Sit in on FIRE Club or the Finance Career Accelerator",
    "Start looking at finance internships a year ahead, since many firms recruit early",
  ],
  accounting: [
    "Ask the VITA Club how to volunteer in tax season",
    "Go to Meet the Firms each spring",
    "Ask Beta Alpha Psi about membership",
  ],
  marketing: [
    "Visit Marketing Club or Sales Club",
    "Save your club campaign work as portfolio pieces",
    "Ask about the Sales Competition Team",
  ],
  management: ["Visit PW Club or the Innovation & Change Club"],
  mis: ["Join an MIS Club technical project", "Apply to a first- or second-year tech program"],
  entrepreneurship: [
    "Enter the Business Plan Competition with a teammate",
    "Enter again with an idea you have tested on real people",
  ],
  intlbus: ["Go to an International Business Club meeting", "Price out one study abroad program"],
  hospitality: [
    "Meet Sigma Iota",
    "Ask when SHBM Ambassador applications open",
    "Check Eta Sigma Delta: 50% of credits and a 3.0 GPA",
  ],
  business: ["Sample Alpha Kappa Psi or Delta Sigma Pi to see the majors up close"],
  cs: ["Apply to a first- or second-year tech program", "Bring one finished project to the fall expo"],
  _: ["Ask your advisor which department club and career fair matter most for your major"],
};
