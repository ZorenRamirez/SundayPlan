/*
  02-helpers.js — small tools the other files share.

  Formatting dates and times ("Tue, Nov 24", "6:00pm"), counting days until a deadline,
  and making text safe to put on the page (esc and safeUrl).
*/
"use strict";
/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
const safeUrl = (u) => (/^https:\/\/[^\s"'<>]+$/.test(u || "") ? u : "");
const pad = (n) => String(n).padStart(2, "0");
const iso = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const P = (s) => {
  const a = String(s).split("-").map(Number);
  return new Date(a[0], a[1] - 1, a[2]);
};
const addDays = (s, n) => {
  const d = P(s);
  d.setDate(d.getDate() + n);
  return iso(d);
};
const now = () => (window.__NOW ? new Date(window.__NOW) : new Date());
const today = () => iso(now());
const daysTo = (s) => Math.round((P(s) - P(today())) / 864e5);
const fmtShort = (s) => {
  const d = P(s);
  return MON[d.getMonth()] + " " + d.getDate();
};
const fmtDate = (s) => {
  const d = P(s);
  return DOW[d.getDay()] + ", " + MON[d.getMonth()] + " " + d.getDate();
};
// "Nov 22–28", "Nov 29–Dec 5" or "Dec 27, 2026–Jan 2, 2027". The year shows only when the span crosses a year.
function weekSpan(start, end) {
  const a = P(start), b = P(end), y = a.getFullYear() !== b.getFullYear();
  return MON[a.getMonth()] + " " + a.getDate() + (y ? ", " + a.getFullYear() : "") + "–" +
    (a.getMonth() !== b.getMonth() || y ? MON[b.getMonth()] + " " : "") + b.getDate() + (y ? ", " + b.getFullYear() : "");
}
const fullToday = () => {
  const d = P(today());
  return DOWL[d.getDay()] + ", " + MONL[d.getMonth()] + " " + d.getDate();
};
const fmtTime = (t) => {
  if (!t) return "";
  let [h, m] = t.split(":").map(Number);
  const ap = h >= 12 ? "pm" : "am";
  h = h % 12 || 12;
  return h + (m ? ":" + pad(m) : "") + " " + ap;
};
const dur = (m) =>
  m < 60
    ? m + " min"
    : (m % 60 ? (m / 60).toFixed(1).replace(".0", "") : m / 60) + (m === 60 ? " hour" : " hours");
const inDays = (n) => (n === 0 ? "today" : n === 1 ? "tomorrow" : "in " + n + " days");
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || "");
