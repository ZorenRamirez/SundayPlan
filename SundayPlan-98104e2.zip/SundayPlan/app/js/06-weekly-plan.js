"use strict";

// Keep free-text goals separate from the account's identity and private notes.
function priorityField() {
  const p = prof();
  return `<div class="fieldset full"><span>What matters most this week?</span><div class="chips">${Object.entries(PRIORITIES).map(([key,value]) =>
    `<button class="chip sm" aria-pressed="${(p.priority || "balanced") === key}" data-act="setp" data-f="priority" data-v="${key}">${esc(value.label)}</button>`).join("")}</div></div>
    <label class="f full">A goal in your own words <small>Optional</small><input type="text" maxlength="160" id="plan-goal" data-p="goal" placeholder="e.g. Meet students who work on startups" value="${esc(p.goal || "")}"></label>`;
}
function planPrivacy() {
  return window.SUNDAY_CONFIG?.onDeviceRanking ? '<p class="small muted">Your Mac compares your goal and preferences with real listings using on-device AI.</p>' : "";
}
function planEntry() {
  const rank = currentRanking();
  const applied = Array.isArray(rank?.scheduledKeys);
  const alreadyOnList = applied && rank.scheduledKeys.some(k => ["planned","done"].includes(state.plan[k]?.status));
  const message = alreadyOnList ? "Your steps are on your list. Open your plan to see their dates." :
    "Create a plan to add recommended steps to your list on days you’re available.";
  return `<section class="panel personal-entry"><div><h3>Your personal plan</h3><p>${message}</p></div><div class="actions">
    ${rank ? `<button class="btn ${alreadyOnList ? "primary" : "ghost"} sm" data-act="reviewplan">View my plan</button>` : ""}
    ${alreadyOnList ? "" : `<button class="btn primary sm" data-act="generateplan">${state.recommendations?.week === weekStart() ? "Update my plan" : "Create my plan"}</button>`}</div></section>`;
}
function planReasons(x) {
  const p = prof(), o = x.o, s = o.steps[x.i];
  const reasons = [];
  if (PRIORITIES[p.priority]?.types.includes(o.type)) reasons.push("Matches your priority to " + PRIORITIES[p.priority].label.toLowerCase() + ".");
  reasons.push(...fits(o,x.i).slice(0,2));
  if (p.where !== "pullman" && s.where === "any") reasons.push("You can take this step while away from campus.");
  if (s.min <= 30) reasons.push("A short step that fits in " + dur(s.min) + ".");
  return reasons;
}
function planReason(x) {
  const choice = currentRanking()?.items.find(row => row.key === pkey(x.o,x.i));
  return choice && planReasons(x).includes(choice.reason) ? choice.reason : "";
}
function laterSuggestion() {
  const list = candidates().filter(x => !x.o.outdated);
  const rank = currentRanking();
  for (const item of rank?.items || []) {
    const match = list.find(x => pkey(x.o,x.i) === item.key);
    if (match) return match;
  }
  return list[0];
}
// A weekly meeting with an ambiguous clock can be scheduled on its next known weekday.
// For today, use only an unambiguous future start.
function meetingStillAhead(text, day) {
  if (day !== today()) return true;
  const clock = text.match(/\b(\d{1,2})(?::(\d{2}))?\s*(?:[-–]\s*\d{1,2}(?::\d{2})?\s*)?([ap])\.?m\b/i);
  if (!clock) return false;
  const hour = Number(clock[1]) % 12 + (clock[3].toLowerCase() === "p" ? 12 : 0);
  return laToUtc(day, pad(hour) + ":" + (clock[2] || "00")) > now();
}
function weeklyCandidates() {
  const days = [];
  for (let d = today(); d <= weekEnd(); d = addDays(d, 1)) {
    if (!prof().busy.includes(P(d).getDay())) days.push(d);
  }
  return candidates().filter(x => !x.o.outdated && !x.o.support).map(x => {
    const step = x.o.steps[x.i], event = x.o.dates?.[step.event];
    const allowed = days.filter(d => {
      if ((event && d !== event.date) || (step.from && d < step.from) || (step.to && d > step.to)) return false;
      if (!step.weeklyMeeting) return true;
      const weekday = new RegExp("\\b" + DOWL[P(d).getDay()] + "s?\\b", "i");
      return weekday.test(step.weeklyMeeting) && meetingStillAhead(step.weeklyMeeting, d);
    });
    return {...x, days:allowed};
  }).filter(x => x.days.length);
}
// Choose the entire set before writing entries: each saved step leaves the recommendation pool.
function scheduleWeeklyPicks(rank) {
  if (Array.isArray(rank.scheduledKeys)) return;
  const chosen = picks(weeklyCandidates());
  // Auto-picked steps get no made-up day. Only a listing's own event date is saved, because that is a fact.
  for (const x of chosen) {
    const step = x.o.steps[x.i], event = step.event != null && x.o.dates?.[step.event];
    writePlanEntry(pkey(x.o,x.i), {status:"planned", ...(event && isDate(event.date) ? {day:event.date} : {}), week:weekStart()});
  }
  rank.week = weekStart();
  rank.scheduledKeys = chosen.map(x => pkey(x.o,x.i));
}
function rankingInput() {
  const p = prof(), remaining = remainingMinutes();
  const eligibleList = weeklyCandidates().filter(x => remaining === 0 || x.o.steps[x.i].min <= remaining);
  const types = PRIORITIES[p.priority]?.types || [];
  const hasPriorityMatch = eligibleList.some(x => types.includes(x.o.type));
  const list = hasPriorityMatch ? eligibleList.filter(x => types.includes(x.o.type)) : eligibleList;
  const goalRank = p.goal ? list.filter(x => goalTopic(x.o)).slice(0,12) : [];
  const shortlist = [...new Set([...goalRank,...p.interests.flatMap(t=>list.filter(x=>x.o.type===t).slice(0,2)),...list])].slice(0,36);
  const signals = Object.entries(learned()).filter(([k,v])=>TYPES[k] && v).slice(0,8).map(([k,v])=>TYPES[k][0]+" "+(v>0?"preferred":"less preferred"));
  const intent = (p.goal || PRIORITIES[p.priority]?.label || "").slice(0,160);
  const preferences = [majorRow()[1], YEARS[p.year], "Goal: " + (p.goal || PRIORITIES[p.priority]?.label || "Explore my options"),
    "Priority: " + (PRIORITIES[p.priority]?.label || "Explore my options"),
    "Interested in " + p.interests.filter(t=>TYPES[t]).map(t=>TYPES[t][0]).join(", "), p.where==="pullman"?"In Pullman":"Away from campus",
    p.reach==="wsu"?"Campus opportunities only":"Campus and beyond",p.paid?"Paid programs allowed":"Free only",
    "Weekly minutes: "+p.time, "Unavailable: "+p.busy.map(i=>DOWL[i]).join(", "), ...signals].join(". ").slice(0,720);
  const candidatesForModel = shortlist.map(x=>({title:x.o.title.slice(0,160),kind:TYPES[x.o.type][0],step:x.o.steps[x.i].text.slice(0,320),summary:(x.o.summary || "").slice(0,180),
    minutes:x.o.steps[x.i].min,reasons:planReasons(x).map(r=>r.slice(0,160))}));
  return {shortlist, body:{intent,preferences,remaining,candidates:candidatesForModel}};
}
function viewPlanGeneration() {
  const waiting = ui.planStage === "building";
  const rank = currentRanking();
  const applied = Array.isArray(rank?.scheduledKeys);
  let rows = [];
  if (!waiting && applied) {
    const list = new Map(entries().map(x => [x.k,x]));
    rows = rank.scheduledKeys.map(k => list.get(k)).filter(x => x && ["planned","done"].includes(x.e.status));
  } else if (!waiting && rank) {
    rows = picks(weeklyCandidates()).map(x => ({...x, k:pkey(x.o,x.i), s:x.o.steps[x.i]}));
  }
  const full = !remainingMinutes();
  const later = !waiting && !rows.length && full ? laterSuggestion() : null;
  const usedModel = rows.some(x => rank?.items.some(item => item.key === x.k));
  const model = usedModel && rank?.source === "language" ? "Ranked by Apple’s on-device language model" :
    usedModel && rank?.source === "semantic" ? "Matched by meaning with Apple’s on-device AI" : "Matched using your profile and catalog filters";
  let content;
  if (waiting) {
    content = `<div class="plan-motion" aria-hidden="true"><i></i><i></i><i></i></div><h1 tabindex="-1" id="plan-title">Creating your plan</h1>
      <p role="status">Comparing ${esc(majorRow()[1])} opportunities with your interests and the time you have this week.</p>`;
  } else {
    const minutes = rows.reduce((sum,x) => sum + x.s.min, 0);
    let summary;
    if (rows.length) summary = rows.length + (rows.length === 1 ? " step" : " steps") +
      (applied ? " on your list" : " ready to add") + " · About " + dur(minutes) + " total";
    else if (applied && rank.scheduledKeys.length) summary = "You’ve removed these steps from your list.";
    else summary = full ? "Your week is full. Keep your current commitments." : "No new steps fit your available time and preferences this week.";
    content = `<h1 tabindex="-1" id="plan-title">Your weekly plan</h1><p class="plan-sub">${esc(PRIORITIES[prof().priority]?.label || "Explore my options")} · ${esc(majorRow()[1])}</p>
      ${prof().goal ? `<p class="plan-intent">“${esc(prof().goal)}”</p>` : ""}
      <p>${esc(summary)}</p>
      <ol class="plan-result">${rows.map((x,i) => {
        const reason = x.o.archived ? "" : planReason(x) || planReasons(x)[0];
        const timing = x.e ? (x.e.status === "done" ? "Completed" : fmtDate(x.e.day)) : "";
        return `<li><span class="plan-number" aria-hidden="true">${i+1}</span><div><h2>${esc(x.o.title)}</h2><p>${esc(x.s.text.replace(/the question below/i, "the question in Details"))}</p><small>${[timing,dur(x.s.min),reason].filter(Boolean).map(esc).join(" · ")}</small>
        ${x.o.archived ? "" : `<button class="btn text sm" data-act="showlisting" data-id="${esc(x.o.id)}">View details<span class="vh"> for ${esc(x.o.title)}</span></button>`}</div></li>`;
      }).join("")}</ol>
      ${later ? `<div class="plan-later"><small>For later</small><h2>${esc(later.o.title)}</h2><button class="btn text sm" data-act="showlisting" data-id="${esc(later.o.id)}">View opportunity</button></div>` : ""}
      <p class="plan-method">${esc(model)}.</p>${!applied && rows.length ? '<button class="btn primary" data-act="generateplan">Add these steps to my list</button>' : `<button class="btn primary" data-act="finishplan">${rows.length ? "Open my list" : "Open my week"}</button>`}`;
  }
  return `<main class="plan-stage"><section class="plan-paper" aria-labelledby="plan-title" aria-busy="${waiting}"><div class="brand"><i></i>Sunday Plan</div>${content}</section></main>`;
}
async function generateWeeklyPlan() {
  if (ui.planStage === "building") return;
  const owner = state, screen = ui;
  const active = () => state === owner && ui === screen && ui.planStage === "building";
  ui.planStage = "building"; render(); window.scrollTo(0,0);
  document.getElementById("plan-title")?.focus();
  let source = "rules", items = [];
  await new Promise(resolve => requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  if (!active()) return;
  if (typeof catalogReady !== "undefined" && catalogReady)
    await Promise.race([catalogReady,new Promise(resolve=>setTimeout(resolve,4000))]);
  if (!active()) return;
  const signature = rankingSignature();
  const previous = currentRanking();
  if (previous && (!Array.isArray(previous.scheduledKeys) || previous.scheduledKeys.some(k => ["planned","done"].includes(state.plan[k]?.status)))) {
    scheduleWeeklyPicks(previous);
    ui.planStage = "ready"; save(); render(); document.getElementById("plan-title")?.focus();
    return;
  }
  try {
    const {shortlist,body} = rankingInput();
    if (window.SUNDAY_CONFIG?.onDeviceRanking && shortlist.length) {
      const headers = {"Content-Type":"application/json"};
      if (window.SUNDAY_CONFIG.mode === "cloud") {
        const token = await sundayAccount.rankingToken();
        if (!token || !active()) throw Error("No current account");
        headers.Authorization = "Bearer " + token;
      }
      const response = await fetch("/api/plan/rank",{method:"POST",headers,body:JSON.stringify(body),signal:AbortSignal.timeout(27000)});
      if (response.ok) {
        const result = await response.json();
        if (["language","semantic"].includes(result.source) && Array.isArray(result.picks)) {
          for (const pick of result.picks) {
            const x = shortlist[pick.index], reason = body.candidates[pick.index]?.reasons[pick.reason];
            if (x && reason && !items.some(row=>row.key===pkey(x.o,x.i))) items.push({key:pkey(x.o,x.i),reason});
          }
          if (items.length) source = result.source;
        }
      }
    }
    if (!items.length) items = shortlist.map((x,i) => ({key:pkey(x.o,x.i), reason:body.candidates[i].reasons[0]})).slice(0,8);
  } catch { /* The current filtered plan stays usable offline. */ }
  if (!active()) return;
  if (signature === rankingSignature()) {
    state.recommendations = {signature,source,items};
    scheduleWeeklyPicks(state.recommendations);
  } else {
    ui.planStage = null;
    render();
    toast("Your preferences changed. Create your plan again.");
    return;
  }
  ui.planStage = "ready";
  save(); render(); window.scrollTo(0,0); document.getElementById("plan-title")?.focus();
}
