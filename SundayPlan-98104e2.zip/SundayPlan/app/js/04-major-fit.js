// Academic relevance is separate from the catalog's eligibility groups. Each entry
// lists phrases a student can trace to the listing. Unlisted majors use their full name.
"use strict";
const academicAliases = {
  "Finance": "investment banking|financial analyst|financial analysis|investment management",
  "Accounting": "accountants|accountancy|tax preparation|audit|auditing",
  "Marketing": "advertising|market research|digital marketing",
  "Management": "human resources|organizational management",
  "Management Information Systems": "mis club|information systems",
  "Entrepreneurship": "entrepreneur|entrepreneurs|entrepreneurial|startup|startups",
  "Hospitality Business Management": "hospitality|hotel management",
  "Wine and Beverage Business Management": "winemaking|wine business|viticulture|beverage management",
  "Business, not certified in a major yet": "business",
  "Computer Science": "computing machinery|computer programming|coding|computer scientists|algorithms|leetcode",
  "Computer Engineering": "computer engineers|computer hardware|embedded systems",
  "Software Engineering": "software engineer|software engineers|software development|software developer",
  "Civil Engineering": "civil engineers|civil engineer|asce|steel bridge|concrete canoe",
  "Mechanical Engineering": "mechanical engineers|mechanical engineer|asme",
  "Chemical Engineering": "chemical engineers|chemical engineer|aiche",
  "Electrical Engineering": "electrical engineers|electrical engineer|ieee",
  "Construction Engineering": "construction engineers|construction engineer",
  "Bioengineering": "biomedical engineering|biomedical engineers",
  "Materials Science and Engineering": "materials science|materials engineering|material advantage",
  "Architecture": "architects|architectural design",
  "Asian Studies": "east asian studies|asian american studies",
  "Basic Medical Sciences": "medical sciences|biomedical sciences",
  "Criminal Justice and Criminology": "criminal justice|criminology",
  "Digital Technology and Culture": "digital humanities|digital culture|digital media",
  "English": "english literature|creative writing|literary studies|literary review|literary journal",
  "Fine Arts": "art club|visual arts|painting|sculpture|printmaking",
  "Foreign Languages and Cultures": "language exchange|french club|german club|spanish club|language learning",
  "History": "historical research|historians",
  "Human Biology": "human physiology|human anatomy",
  "Mathematics": "math|maths|mathematical|calculus|algebra|number theory",
  "Music": "choir|choral|orchestra|jazz|clarinet|musicians|music performance",
  "Philosophy": "philosophical|philosophers",
  "Physics and Astronomy": "physics|astronomy|astrophysics",
  "Political Science": "political scientists|political studies",
  "Psychology": "psychologists|psychological science",
  "Public Affairs": "public policy|public administration",
  "Social Sciences": "social science",
  "Women's Studies": "gender studies|women and gender studies|gender equality",
  "Zoology": "zoological|zoologists",
  "Data Analytics": "data analysis|data science|data analyst|data scientists",
  "Agricultural and Food Systems": "food systems|agriculture|agricultural systems",
  "Animal Sciences": "animal science|animal husbandry",
  "Apparel, Merchandising, Design, and Textiles": "apparel|textiles|amdt|fashion merchandising|fashion design|fashion magazine",
  "Earth and Environmental Sciences": "earth science|environmental science|environmental sciences|geology",
  "Economic Sciences": "economics|economists|econ club|econometrics",
  "Integrated Plant Sciences": "plant science|plant sciences|horticulture|crop science",
  "Journalism and Media Production": "journalism|broadcast journalism|media production|student radio|college radio|student newspaper|television station",
  "Strategic Communication": "public relations|strategic communications",
  "Education": "teacher education|education club|future educators",
  "Secondary Education": "secondary teaching|high school teaching",
  "Kinesiology": "kinesiologists",
  "Nutrition and Exercise Physiology": "nutrition|exercise physiology|dietetics",
  "Speech and Hearing Sciences": "speech pathology|speech language pathology|audiology",
  "Nursing": "nurse|nurses|nursing students",
  "Biochemistry": "biochemical",
  "Genetics and Cell Biology": "genetics|cell biology|genomics",
  "Microbiology": "microbiologists|microbial",
  "Neuroscience": "neuroscientists|neurobiology",
};
const adjacentSubjects = {
  "Sports Medicine": "kinesiology|pre pt ot",
  "Public Affairs": "political science",
  "Animal Sciences": "companion animal",
  "Management": "sport management",
  "Architecture": "landscape architecture|landscape architects",
  "Construction Engineering": "construction management|civil engineering|structural engineering",
  "Nutrition and Exercise Physiology": "food science|kinesiology",
  "Digital Technology and Culture": "digital audio",
  "Human Biology": "human physiology|pre med|biomedical sciences|cell biology|genetics",
  "Basic Medical Sciences": "pre med|biomedical sciences|disease diagnostics",
  "Asian Studies": "chinese language|chinese learning|japanese language",
  "Humanities": "philosophy|literary review|history club",
  "Social Studies": "history club|political science",
  "Social Sciences": "political science|economics|econometrics|psychology|sociology",
  "Mathematics": "actuarial science|quantitative research|quantitative trading|quantitative trader|quantitative developer|statistics|data analytics|data science",
  "Finance": "actuarial science|quantitative trading|commercial real estate",
  "Accounting": "actuarial science",
  "Computer Science": "software engineering|software engineer|data science|cyber security|cybersecurity|robotics",
  "Software Engineering": "computing machinery|computer science|coding|leetcode",
  "Computer Engineering": "robotics|electrical engineering|computing machinery",
  "Data Analytics": "statistics|quantitative research|actuarial science",
  "Education": "future teachers|teacher education",
  "Secondary Education": "future teachers|teacher education",
  "Biology": "cell biology|microbiology|genetics|zoology",
  "Chemistry": "biochemistry",
  "Physics and Astronomy": "applied mathematics|aerospace",
  "International Business": "study abroad|international trade",
};
const normalizeTopic = value => String(value || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
  .toLowerCase().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
const majorProfiles = new Map(MAJORS.map(row => {
  const label = row[1], terms = value => value ? value.split("|").map(normalizeTopic) : [];
  return [label, {row, direct:[normalizeTopic(label), ...terms(academicAliases[label])], adjacent:terms(adjacentSubjects[label])}];
}));
const generalStudy = majorProfiles.get("Undecided or exploring");
const specializedTitleTerms = [...new Set([...majorProfiles.values()]
  .filter(profile => profile !== generalStudy)
  .flatMap(profile => profile.direct)
  .filter(term => !["business", "history", "english", "education", "management", "entrepreneur", "startups"].includes(term)))];
// Unambiguous group codes from older profiles can still identify a discipline.
function academicProfile() {
  const selected = prof().major;
  if (majorProfiles.has(selected)) return majorProfiles.get(selected);
  const rows = MAJORS.filter(row => row[0] === selected);
  return rows.length === 1 ? majorProfiles.get(rows[0][1]) : generalStudy;
}
const listingTextCache = new WeakMap();
function listingTopics(o) {
  if (!listingTextCache.has(o)) {
    const title = " " + normalizeTopic(o.title) + " ";
    const description = " " + normalizeTopic(o.summary) + " ";
    listingTextCache.set(o, {title, description, specialized:specializedTitleTerms.some(term => phraseIn(title, term))});
  }
  return listingTextCache.get(o);
}
const phraseIn = (text, term) => text.includes(" " + term + " ");
const ambiguousDescription = new Set(["english", "history", "management", "education", "communication", "business", "finance", "architecture", "humanities", "math"]);
const fitCache = new WeakMap();
function subjectFit(o) {
  const profile = academicProfile(), [group, label] = profile.row;
  if (profile === generalStudy) return null;
  const prev = fitCache.get(o);
  if (prev?.profile === profile) return prev.result;
  const {title, description} = listingTopics(o);
  const adjacent = profile.adjacent.find(term => phraseIn(title, term));
  const titleHit = profile.direct.find(term => {
    if (!phraseIn(title, term) || (adjacent && phraseIn(" " + adjacent + " ", term))) return false;
    if (term === "management" || term === "education") return title.trim() === term + " club";
    return true;
  });
  const described = profile.direct.find(term => !ambiguousDescription.has(term) && phraseIn(description, term));
  // Only an editorial tag that uniquely identifies a degree can stand for that degree.
  const editorial = !o.src && (o.boost?.includes(group) || o.majors?.includes(group)) &&
    MAJORS.filter(row => row[0] === group).length === 1;
  let result = null;
  if (titleHit || editorial) result = {points:titleHit ? 64 : 48, direct:true, reason:"Fits " + label};
  else if (adjacent) result = {points:36, direct:false, reason:"Related to " + label + " through " + adjacent};
  else if (described) result = {points:32, direct:false, reason:"The listing mentions “" + described + "”"};
  fitCache.set(o, {profile, result});
  return result;
}
// A broad goal ("I want to meet people at a club") adds no topic of its own.
const genericGoalWords = new Set((
  "the and for have has had are can could should will would not but any all our your you who how what where " +
  "also about after before become being through more new better first into than then those these other my own " +
  "been because they them their there myself some something that this with without while from around " +
  "attend build campus career careers club clubs college community connect connecting connections develop discover " +
  "event events experience explore exploring field find finding friends gain get getting goals group groups grow " +
  "help hours improve interested interest interests internship internships join joining job jobs learn learning " +
  "like looking look major make meet meeting meetings members network networking opportunities opportunity organization " +
  "organizations people personal plan professional program programs real related research school skills social " +
  "start state step steps student students study support team time university want washington week weekly work wsu year"
).split(" "));
const goalAliases = {singing:["choir","choral"], programming:["coding"], scholarships:["scholarship"]};
function goalTopic(o) {
  const {title, description} = listingTopics(o);
  const goal = normalizeTopic(prof().goal);
  const positive = goal.split(/\b(?:avoid|except|without|not|dont|dislike)\b/)[0];
  for (const word of positive.split(" ")) {
    if (word.length < 3 || genericGoalWords.has(word)) continue;
    const aliases = Object.hasOwn(goalAliases, word) ? goalAliases[word] : [];
    if ([word, ...aliases].some(term => phraseIn(title,term) || phraseIn(description,term))) return word;
  }
  return "";
}
function relevantSuggestion(o) {
  if (academicProfile() === generalStudy || subjectFit(o) || goalTopic(o)) return true;
  // Choosing "clubs" or "internships" alone does not establish interest in every specialty.
  return o.type !== "club" && o.src !== "board" && !listingTopics(o).specialized;
}
