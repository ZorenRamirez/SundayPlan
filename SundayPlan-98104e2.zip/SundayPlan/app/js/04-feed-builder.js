/*
  04-feed-builder.js — turns raw data into the one list the app shows.

  It reads data/clubs.json, data/events.json and data/jobs.json, normalizes each listing and merges the results with the hand-checked listings
  from the database. The result is LIST, which every screen draws from.
*/
"use strict";
// A weekday and time alone do not tell us which week a club meets.
function hasWeeklyMeeting(text) {
  if (!text || /bi[ -]?weekly|fortnight|other|alternat|every (?:two|2)|monthly|month|first|second|third|fourth|last|varies|tbd|occasion|as needed|semester/i.test(text)) return false;
  const weekday = /\b(?:mon|tues|wednes|thurs|fri|satur|sun)days?\b/i;
  const recurring = /\b(?:every|weekly|each)\b|\b(?:mon|tues|wednes|thurs|fri|satur|sun)days\b/i;
  const clock = /\b(?:[01]?\d|2[0-3]):[0-5]\d\b|\b(?:1[0-2]|[1-9])\s*[ap]\.?m\.?\b/i;
  return weekday.test(text) && recurring.test(text) && clock.test(text);
}
/* ---------- catalog safeguards ---------- */
// Recovery and support groups stay in search, Explore and Coming up, but the app does not
// suggest them on its own. A student can turn suggestions on: state.profile.supportGroups = true.
const SUPPORT_GROUP =
  /support group|peer support|\b(?<!disaster |data |password )recovery\b|\bsobriety\b|\bsober\b|substance (?:use|abuse)|\baddiction|12[- ]step|harm reduction|overdose|\bgrief\b|bereave|(?:therapy|counsell?ing|process) group/i;
const isSupportGroup = (...text) => SUPPORT_GROUP.test(text.filter(Boolean).join(" "));
const supportOptIn = () => !!state.profile && state.profile.supportGroups === true;
// How many days a source may go without a successful check before its listings are labeled
// out of date. Events move and get cancelled, so they have the shortest limit.
const STALE_AFTER_DAYS = { events: 3, jobs: 7, clubs: 14, curated: 21 };
// How old one source is. A missing or unreadable check date counts as out of date.
function sourceAge(checked, kind) {
  if (!isDate(checked)) return { checked: "", days: null, stale: true };
  const days = Math.max(0, -daysTo(checked));
  return { checked, days, stale: days > STALE_AFTER_DAYS[kind] };
}
// The date a job's own board was last read. Older snapshots only have the build date.
const jobChecked = (j, meta) =>
  j.checked || ((meta && meta.sourceDates) || {})[String(j.id).split("-", 1)[0]] || (meta && meta.builtAt) || "";
// One summary of how fresh the catalog is, for a banner or a status line.
function catalogStatus() {
  const m = FEEDS.meta || {},
    src = m.sourceDates || {},
    fd = m.builtAt || "",
    jobs = FEEDS.jobs.map((j) => sourceAge(jobChecked(j, m), "jobs"));
  return {
    clubs: sourceAge(src.clubs || fd, "clubs"),
    events: sourceAge(src.events || fd, "events"),
    jobs: { total: jobs.length, outdated: jobs.filter((a) => a.stale).length },
    failedSources: Array.isArray(m.failedSources) ? m.failedSources : [],
  };
}
// Last stop for every listing: records when it was checked, labels it honestly when that was
// too long ago, and decides whether the app may suggest it without being asked.
function finish(listing, kind, age) {
  const o = { ...listing }; // work on a copy: hand-checked listings are also kept in a cache
  const never = !!listing.nopick; // set by the source, for example fraternities and sororities
  o.checked = age.checked || o.checked || "";
  o.support = !!o.support || (kind === "curated" && isSupportGroup(o.title, o.summary, o.org));
  if (o.support) o.dates = (o.dates || []).map((d) => ({ ...d, key: false })); // no deadline nudges
  if (age.stale) {
    o.outdated = true;
    const when = age.checked ? "last checked " + fmtShort(age.checked) : "never date-checked";
    const add = (text) => (o.note = [o.note, text].filter(Boolean).join(" "));
    if (kind === "events") {
      o.verify = "secondary"; // shows the "Confirm with organizer" badge
      o.steps = (o.steps || []).map((s) =>
        s.event != null
          ? { ...s, text: "Confirm on the event page that this is still on, then go" + s.text.replace(/^Go/, "") }
          : s,
      );
      add("Event details were " + when + ". Events can move or be cancelled.");
    } else if (kind === "jobs") {
      o.summary = [o.summary, when + ", may have closed"].filter(Boolean).join(" · ");
      add("This posting was " + when + " on the employer’s careers page and may have closed.");
    } else if (kind === "clubs") {
      add("Club details on WSU Involve were " + when + ". Confirm the meeting time on the club page.");
    } else add("This listing was " + when + ". Confirm the details on the organizer page.");
  }
  const held = age.stale && (kind === "events" || kind === "jobs"); // never suggest from old data
  // Read each time it is asked, so signing in as someone else or changing the setting
  // takes effect at once without rebuilding the list.
  Object.defineProperty(o, "nopick", {
    enumerable: true,
    configurable: true,
    get: () => never || held || (o.support && !supportOptIn()),
  });
  return o;
}
// WSU departments list undergraduate clubs that are absent from the Involve feed.
// These editorial dates are independent of the hourly directory refresh.
const mathDepartment = {org:"WSU Department of Mathematics and Statistics", url:"https://math.wsu.edu/student-clubs-organizations/"};
const departmentClubs = [
  {...mathDepartment, id:"wsu-math-club", title:"Math Club", weight:7,
    summary:"Meet students interested in mathematics and explore developments in the field."},
  {...mathDepartment, id:"wsu-future-teachers-of-mathematics", title:"Future Teachers of Mathematics", weight:4,
    summary:"A WSU group for students exploring math teaching and other careers in mathematics."},
  {id:"wsu-sociology-club", title:"Sociology Club", org:"WSU Department of Sociology", weight:4,
    url:"https://soc.wsu.edu/student-organizations/sociology-club/",
    summary:"Meet sociology students and faculty through speakers, community service and career activities."},
  {id:"wsu-neuroscience-club", title:"Neuroscience Club", org:"WSU Neuroscience Club", weight:4,
    url:"https://www.wsuneuroclub.org/home",
    summary:"Connect with neuroscience students, faculty and research opportunities. Ask the club about current activities."},
  {id:"wsu-coalition-for-women-students", title:"Coalition for Women Students", org:"WSU Women’s Center", weight:4,
    url:"https://women.wsu.edu/student-organizations/",
    summary:"The coalition runs student leadership and gender equality initiatives at WSU."},
];
function departmentListing(club) {
  return finish({...club, type:"club", majors:["all"], dates:[],
    scope:"wsu", qualify:"Ask the organizer about membership and the next meeting.",
    ask:"Hi, I’m interested in " + club.title + ". Is the club meeting this term, and how can I join?",
    steps:[{text:"Open the club’s listing and ask the organizer about the next meeting.", min:10, where:"any", ask:true}]
  }, "curated", sourceAge("2026-11-23", "curated"));
}
function build() {
  if (!CUR.length && !FEEDS.clubs.length && !FEEDS.events.length && !FEEDS.jobs.length && !FEEDS.meta) return [];
  const fd = (FEEDS.meta && FEEDS.meta.builtAt) || "",
    by = {};
  const src = (FEEDS.meta && FEEDS.meta.sourceDates) || {},
    clubsAge = sourceAge(src.clubs || fd, "clubs"),
    eventsAge = sourceAge(src.events || fd, "events");
  for (const c of FEEDS.clubs) if (c.a) by[c.a] = c;
  const meetStep = (c) => ({
    weeklyMeeting: c.t,
    min: 60,
    where: "campus",
    text:
      "Go to a meeting: " + c.t + (c.l ? ", " + c.l : "") + ". Check the club page first in case it moved.",
  });
  const cur = CUR.map((o) => {
    const c = by[o.id];
    if (!c) return finish(o, "curated", sourceAge(o.checked, "curated"));
    const n = Object.assign({}, o);
    n.meet = c.t;
    n.place = c.l;
    n.members = c.m;
    if (!n.summary) n.summary = c.d;
    n.links = (n.links || []).concat([
      { label: "Club page on WSU Involve", url: "https://wsu.presence.io/organization/" + c.u },
    ]);
    if (hasWeeklyMeeting(c.t) && !clubsAge.stale) {
      n.steps = [meetStep(c)];
    } else if (n.dateUnclear && n.steps.some((s) => s.ask)) {
      n.steps = n.steps.map((s) => s.ask ? { ...s, text: "Ask the organizer for the next meeting date and time." } : s);
    }
    if (hasWeeklyMeeting(c.t) && clubsAge.stale)
      n.note = [n.note, "The meeting time on WSU Involve (" + c.t + ") was " + (clubsAge.checked ? "last checked " + fmtShort(clubsAge.checked) : "never date-checked") + ". Confirm it before you go."].filter(Boolean).join(" ");
    return finish(n, "curated", sourceAge(o.checked, "curated"));
  });
  const clubs = FEEDS.clubs
    .filter((c) => !c.a)
    .map((c) => {
      const graduateOnly = !!c.g || (/\bgraduate (?:student|organization|chapter|society)\b/i.test(c.n) &&
        !/\bundergraduate/i.test(c.n));
      return finish({
        id: "org-" + c.u,
        src: "involve",
        type: "club",
        title: c.n,
        org:
          c.k === "greek"
            ? "Fraternity or sorority"
            : c.k === "sport"
              ? "Sport club"
              : "Student organization",
        url: "https://wsu.presence.io/organization/" + c.u,
        summary: c.d,
        meet: c.t,
        place: c.l,
        tags: c.c,
        majors: ["all"],
        grad: graduateOnly,
        nopick: c.k === "greek",
        members: c.m,
        dates: [],
        qualify: graduateOnly
          ? "Listed as a graduate organization."
          : "Open to WSU students. The club page says how to join.",
        steps: [
          hasWeeklyMeeting(c.t) && !clubsAge.stale
            ? meetStep(c)
            : {
                min: 10,
                ask: true,
                where: "any",
                text: "Open the club page and message the officers to ask when they meet.",
              },
        ],
        weight: Math.min(6, 1 + (c.e ? 1 : 0) + (c.m > 40 ? 2 : c.m > 12 ? 1 : 0) + (c.t ? 1 : 0)),
        scope: "wsu",
        cost: "free",
        checked: clubsAge.checked,
        support: isSupportGroup(c.n, c.d),
      }, "clubs", clubsAge);
    });
  const events = FEEDS.events
    .map((e) => {
      const tt = e.n + " " + (e.tags || []).join(" ");
      const type =
        /career|resume|résumé|interview|internship|job fair|headshot|employer|linkedin|recruit|networking night/i.test(
          tt,
        )
          ? "career"
          : /scholarship|fafsa|wasfa|financial aid/i.test(tt)
            ? "scholarship"
            : /volunteer|service project|donation drive|food drive|clean-?up/i.test(tt)
              ? "service"
              : "event";
      return finish({
        id: "ev-" + e.u,
        src: "involve",
        type,
        title: e.n,
        org: e.o,
        url: "https://wsu.presence.io/event/" + e.u,
        summary: e.d,
        tags: e.tags || [],
        majors: ["all"],
        nopick: !!e.greek,
        grad: !!e.g,
        dates: [
          { label: e.n, date: e.date, start: e.s, end: e.e || "", endDate: e.endDate || "", location: e.l, key: type !== "event" },
        ],
        qualify: "Hosted by " + e.o + ". The event page says who can attend.",
        steps: [
          {
            min: 60,
            where: "campus",
            event: 0,
            to: e.date,
            text:
              "Go: " +
              (isDate(e.date) ? fmtDate(e.date) : "") +
              ", " +
              fmtTime(e.s) +
              (e.l ? " at " + e.l : "") +
              ".",
          },
        ],
        weight: type === "event" ? 2 : 4,
        scope: "wsu",
        cost: "free",
        checked: eventsAge.checked,
        support: isSupportGroup(e.n, e.d, (e.tags || []).join(" "), e.o),
      }, "events", eventsAge);
    })
    .filter((e) => isDate(e.dates[0].date));
  const jobs = FEEDS.jobs.map((j) => {
    const early = /first[- ]year|freshm|sophomore|explore|discover|early/i.test(j.n);
    const jobAge = sourceAge(jobChecked(j, FEEDS.meta), "jobs");
    return finish({
      id: "job-" + j.id,
      src: "board",
      type: "career",
      title: j.n,
      org: j.o,
      url: j.url,
      summary: j.o + " · " + j.l + (isDate(j.up) ? " · updated " + fmtShort(j.up) : ""),
      majors: ["all"],
      minYear: early ? 1 : 2,
      dates: [],
      qualify: "Posted on the employer’s own careers page. Read it for class-year and eligibility rules.",
      steps: [
        {
          min: 30,
          where: "any",
          text: "Read the posting. Apply if your class year fits, or save it for next year.",
        },
      ],
      weight: 2,
      scope: "beyond",
      cost: "free",
      checked: jobAge.checked,
    }, "jobs", jobAge);
  });
  const names = new Set([...cur, ...clubs].map(o => o.title.toLowerCase()));
  const department = departmentClubs.filter(o => !names.has(o.title.toLowerCase())).map(departmentListing);
  return cur.concat(department, clubs, events, jobs);
}
LIST = build();
async function loadFeeds() {
  const get = async (f) => {
    try {
      const r = await fetch("data/" + f + ".json", { cache: "no-cache" });
      return r.ok ? await r.json() : null;
    } catch (e) {
      return null;
    }
  };
  const [m, c, e, j] = await Promise.all([get("feed"), get("clubs"), get("events"), get("jobs")]);
  if (m) FEEDS.meta = m;
  if (Array.isArray(c)) FEEDS.clubs = c;
  if (Array.isArray(e)) FEEDS.events = e;
  if (Array.isArray(j)) FEEDS.jobs = j;
  LIST = build();
  render();
}
