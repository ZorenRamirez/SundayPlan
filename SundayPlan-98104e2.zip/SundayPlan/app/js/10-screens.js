/*
  10-screens.js — one function per screen.

  viewWeek (This week), viewMonth (Coming up), viewExplore plus search, viewClubs,
  viewJobs (Internships), viewPath (Four years), viewYou (Profile) and viewOnboard
  (the opening questions). To change what a screen says or shows, start here.
*/
"use strict";
function nextSavedCard(entry) {
  const {o, s, e} = entry;
  const url = safeUrl(o.url);
  const when = whenParts(o, s, e)[0] || "On your list";
  const meta = [when, !o.src && s.min ? "About " + dur(s.min) : "", o.org].filter(Boolean);
  return `<article class="card lead pick saved-lead"><div class="meta"><span class="ribbon">From your list</span>${pill(o)}</div>
    <h3>${esc(o.title)}</h3><p class="saved-step">${esc(s.text)}</p>${s.ask && o.ask ? askBox(o) : ""}<p class="mini">${meta.map(esc).join(" · ")}</p>
    <div class="actions main">${url ? `<a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener">${o.src === "board" ? "View posting" : "Open organizer page"} ↗</a>` : ""}
    ${appleButton(calForStep(entry), "Apple Calendar")}</div></article>`;
}
function nextMeetingCard(meeting) {
  const {o, w, date} = meeting;
  const calendar = weeklyFor(o,w);
  return `<article class="card lead pick saved-lead"><div class="meta"><span class="ribbon">From your list</span>${pill(o)}</div>
    <h3>${esc(o.title)}</h3><p class="saved-step">${esc(withYear(date))} at ${esc(fmtTime(w.time))} Pacific${w.place ? " · " + esc(w.place) : ""}</p>
    <p class="mini">${w.interval === 2 ? "Every two weeks" : "Weekly meeting"}</p>
    <div class="actions main">${appleButton(calendar, "Add schedule to Apple Calendar")}${safeUrl(o.url) ? `<a class="btn ghost sm" href="${esc(o.url)}" target="_blank" rel="noopener">Organizer page ↗</a>` : ""}</div></article>`;
}
function datesPreview(excluded) {
  // Keep the preview relevant to the student's interests and show a listing only once.
  const seen = new Set(excluded);
  const dates = upcoming(false).filter(({o, d}) => {
    if (seen.has(o.id) || o.nopick || o.outdated || state.stale[o.id] || !relevantSuggestion(o) || !prof().interests.includes(o.type)) return false;
    if (o.minYear && +prof().year < o.minYear) return false;
    if (d.date === today() && d.start && laToUtc(calendarFile.endDate(d), d.end || d.start) <= now()) return false;
    seen.add(o.id);
    return true;
  }).slice(0, 2);
  if (!dates.length) return "";
  return `<section class="panel dates-preview"><div class="home-section-head"><h2>Coming up for you</h2>
    <button class="btn text" data-act="tab" data-v="month">All dates</button></div>
    ${dates.map(({o,d}) => `<button class="date-preview" data-act="showlisting" data-id="${esc(o.id)}" aria-label="View ${esc(o.title)} details">
      <time datetime="${esc(d.date)}"><small>${MON[P(d.date).getMonth()]}</small><b>${P(d.date).getDate()}</b></time>
      <span><strong>${esc(d.label === o.title || o.title.includes(d.label) ? o.title : d.label + " · " + o.title)}</strong>
      <small>${[d.start ? fmtTime(d.start) + " Pacific" : "", d.location || o.org].filter(Boolean).map(esc).join(" · ")}</small></span><i aria-hidden="true">›</i></button>`).join("")}</section>`;
}
function savedLater() {
  const rows = Object.entries(state.later || {});
  if (!rows.length) return "";
  return `<section class="panel saved-later" aria-labelledby="later-h"><div class="home-section-head"><h2 id="later-h">Saved for later</h2><span class="count">${rows.length}</span></div>
    <p class="small muted">Longer-term ideas. They stay here from week to week and are kept out of your weekly picks.</p>
    <ul class="later-list">${rows.map(([k, x]) => `<li><div><b>${esc(x.title)}</b><small>${esc(x.step || "")}</small></div><span class="later-actions"><button class="btn primary sm" data-act="plan" data-k="${esc(k)}">Add to my list<span class="vh">: ${esc(x.title)}</span></button><button class="btn ghost sm" data-act="showlisting" data-id="${esc(x.id)}">Open</button><button class="btn text sm" data-act="unlater" data-k="${esc(k)}">Remove<span class="vh"> ${esc(x.title)}</span></button></span></li>`).join("")}</ul></section>`;
}
function laterPick(x) {
  if (!x) return "";
  const {o,i} = x;
  const reason = fits(o,i).slice(0,2).join(" · ");
  return `<section class="panel later-pick"><div class="home-section-head"><h2>For later</h2>${pill(o)}</div>
    <h3>${esc(o.title)}</h3>${reason ? `<p>${esc(reason)}</p>` : ""}
    <button class="btn ghost sm" data-act="showlisting" data-id="${esc(o.id)}">View opportunity</button></section>`;
}
// Degree resources give students a next step when the catalog has no matching club.
const degreeResources = new Map([
  ["Comparative Ethnic Studies", "https://degrees.wsu.edu/degree/comparative-ethnic-studies/"],
  ["Speech and Hearing Sciences", "https://healthprofessions.wsu.edu/pre-speech-and-hearing-sciences/"],
  ["Wine and Beverage Business Management", "https://degrees.wsu.edu/degree/wine-and-beverage-business-management/"],
]);
function noWeeklyPicks() {
  const p = prof(), label = majorRow()[1];
  const clubsOnly = p.interests.length === 1 && p.interests[0] === "club" && academicProfile() !== generalStudy;
  const resource = clubsOnly && degreeResources.get(label);
  const message = clubsOnly ? "No eligible clubs match " + esc(label) + " or your goal this week."
    : "No new picks fit your current preferences this week.";
  return `<div class="empty">${message}<div class="actions">
    ${resource ? `<a class="btn ghost sm" href="${esc(resource)}" target="_blank" rel="noopener">WSU program resources ↗</a>` : ""}
    <button class="btn ghost sm" data-act="tab" data-v="you">Review preferences</button>
    <button class="btn text" data-act="tab" data-v="explore">Browse opportunities</button></div></div>`;
}
function viewWeek() {
  const p = prof();
  const co = coach();
  const pk = picks(),
    list = todoList();
  // When the coach singles out one of the picks, that pick leads and carries the coach's reason.
  const at = !currentRanking()?.items.some(item => pk.some(x => pkey(x.o,x.i) === item.key)) && co && co.k ? pk.findIndex((x) => pkey(x.o, x.i) === co.k) : -1,
    first = at > 0 ? pk[at] : pk[0],
    rest = pk.filter((x) => x !== first),
    why = at >= 0 && !/^Start with your top pick/.test(co.text) ? co.text : "";
  // The top pick and the other picks are separate pieces so each can sit where the layout needs it.
  let lead = "",
    alts = "";
  const saved = planned().find(x => !isDate(x.e.day) || x.e.day <= weekEnd());
  const meeting = first || saved ? null : weeklyList().find(x => !x.went && x.date >= today());
  const featuredSaved = !first && (saved || meeting);
  const later = !first && LIST.length ? laterSuggestion() : null;
  const horizon = datesPreview([first?.o.id, saved?.o.id, meeting?.o.id, later?.o.id, ...rest.map(x => x.o.id)]);
  let heading = "Picks for you";
  if (featuredSaved) {
    heading = saved ? "Your next step" : "Your next meeting";
    lead = saved ? nextSavedCard(saved) : nextMeetingCard(meeting);
  } else if (!LIST.length)
    lead = `<div class="empty">${feed.state === "loading" ? "Loading this week’s listings…" : "Listings could not be loaded. Refresh the page to try again."}</div>`;
  else if (!pk.length)
    lead = later ? "" : noWeeklyPicks();
  else {
    lead = card(first, "top", planReason(first) || why);
    if (rest.length) alts = `<div class="alts">${rest.map((x) => card(x, "alt", planReason(x))).join("")}</div>`;
  }
  // Smaller notes sit after the list and the picks, never in front of them.
  let side = "";
  const hu = headsUp();
  if (hu.length)
    side += `<div class="heads">${hu.map((x) => `<div class="head ${x.n <= 2 ? "due" : ""}"><span class="mono">${fmtShort(x.d.date)}</span><span><b>${esc(x.d.label.split(",")[0])}</b> · ${inDays(x.n)}</span></div>`).join("")}</div>`;
  if (co && co.wk) {
    const o = LIST.find((x) => x.id === co.wk);
    side += `<div class="slim"><p>${esc(co.text)}</p>${ui.coach && ui.wk === co.wk && o ? wkForm(o) : `<button class="btn sm wheat" data-act="coachwk" data-id="${esc(co.wk)}">Set the time</button>`}</div>`;
  } else if (co && co.tab)
    side += `<div class="slim"><p>${esc(co.text)}</p><button class="btn sm ghost" data-act="tab" data-v="${esc(co.tab)}">Open checklist</button></div>`;
  if (!state.welcomed && LIST.length > CUR.length) {
    const el = (o) => eligible(o) && youPred(o);
    const a = LIST.filter((o) => o.type === "club" && el(o)).length,
      b = LIST.filter((o) => o.type === "career" && el(o)).length,
      c = upcoming(false).filter((x) => daysTo(x.d.date) <= 14).length;
    side += `<div class="slim"><p>For ${esc(majorRow()[1])}: ${a} club${a === 1 ? "" : "s"}, ${b} internship and career lead${b === 1 ? "" : "s"}, and ${c} date${c === 1 ? "" : "s"} in the next two weeks.</p><button class="btn sm ghost" data-act="welcomed">Got it</button></div>`;
  }
  side = `<div class="wk-side">${planEntry()}${side}${focusPanel()}</div>`;
  const head = lead ? `<h2 class="wkh" id="picks-h">${heading}</h2>` : "",
    links = `<nav class="wk-links" aria-label="More to browse"><button class="btn text" data-act="tab" data-v="jobs">Internships</button><button class="btn text" data-act="tab" data-v="month">Coming up</button><button class="btn text" data-act="tab" data-v="explore">Explore all</button></nav>`,
    none = `<section class="wk-none-card" aria-labelledby="list-h"><div class="lhead"><h3 id="list-h">Your list</h3><small class="lweek">${weekSpan(weekStart(), weekEnd())}</small><small>0 to do</small></div><p class="wk-none">Nothing on your list yet. Add a pick and it lands here. A day is optional.</p></section>`;
  // Two columns on a wide screen. On a phone the pieces flow in one column in the order set in
  // the stylesheet: saved list, top pick, other picks, then the smaller notes.
  return (
    weekHead() +
    (list
      ? `<div class="week has-list"><div class="wk-a"><section class="wk-list" aria-labelledby="list-h">${list}</section>${horizon}${side}</div><div class="wk-b">${head}${lead}${laterPick(later)}${alts}${savedLater()}${horizon ? "" : links}</div></div>`
      : `<div class="week no-list"><div class="wk-a">${head}${lead}${none}${side}</div><div class="wk-b">${laterPick(later)}${alts}${savedLater()}${horizon}${horizon ? "" : links}</div></div>`)
  );
}
function viewMonth() {
  const t = today(),
    mid = t.slice(0, 7),
    d = P(t),
    p = prof();
  const dm = doneAll().filter((x) => (x.e.at || "").slice(0, 7) === mid).length,
    goal = 4;
  let h = `<section class="hero"><div><div class="eyebrow">Deadlines and events</div><h1>Coming up</h1></div><div class="hero-stat"><strong>${dm} of ${goal} steps this month</strong><div class="bar" role="img" aria-label="${dm} of ${goal} steps done this month"><i style="width:${Math.min(100, (dm / goal) * 100)}%"></i></div></div></section>`;
  const upAll = upcoming(ui.allDates),
    up = upAll.slice(0, ui.limit + 16);
  const groups = {};
  for (const x of up) {
    const m = x.d.date.slice(0, 7);
    (groups[m] = groups[m] || []).push(x);
  }
  const hab = p.interests.filter((i) => HABITS[i]);
  h += `<div class="toolbar"><div class="seg" role="group" aria-label="Which dates to show"><button aria-pressed="${!ui.allDates}" data-act="datesall" data-v="0">For you</button><button aria-pressed="${ui.allDates}" data-act="datesall" data-v="1">Everything on campus</button></div><span class="count">${upAll.length} dates</span></div><div class="grid mgrid" id="mgrid">`;
  h += `<div class="grid">`;
  const keys = Object.keys(groups).sort().slice(0, 6);
  if (!keys.length)
    h += `<div class="empty">No dated deadlines or events are listed for your profile yet.</div>`;
  for (const m of keys) {
    const [y, mo] = m.split("-").map(Number);
    h += `<div class="mgroup"><h3>${MONL[mo - 1]} ${y}<small>${groups[m].length} date${groups[m].length > 1 ? "s" : ""}</small></h3>${groups[m].map((x) => `<div class="mrow ${x.d.key ? "key" : ""}"><div class="d">${P(x.d.date).getDate()}<small>${DOW[P(x.d.date).getDay()]}</small></div><div class="t"><b>${esc(x.d.label)}</b><span>${x.d.label === x.o.title || x.o.title.includes(x.d.label) ? (x.o.src ? esc(x.o.org) + " · " : "") : esc(x.o.title) + " · "}${x.d.start ? fmtTime(x.d.start) + " · " : ""}${x.d.location ? esc(x.d.location) + " · " : ""}${inDays(daysTo(x.d.date))}</span></div>${calBtns(calFor(x.o, x.d))}</div>`).join("")}</div>`;
  }
  if (upAll.length > up.length)
    h += `<div class="seeall"><button class="btn ghost" data-act="more">Show more dates</button></div>`;
  h += `</div><div class="grid"><div class="panel"><h3>Every month</h3><div>${hab.map((i) => `<button class="check" aria-pressed="${!!state.habits[mid + ":" + i]}" data-act="habit" data-v="${mid}:${i}"><i class="box"></i><span>${esc(HABITS[i])}</span></button>`).join("") || '<p class="muted">Pick interests in Profile to see habits here.</p>'}</div></div>
  <div class="panel"><h3>All key dates</h3><div class="actions"><button class="btn primary sm" data-act="appleall">Add to Apple Calendar</button></div><p class="muted small">For Google, use + Google on each date.</p></div></div></div>`;
  return h;
}
function viewExplore() {
  const p = prof();
  RES = { pred: null, plain: false, you: null };
  let h = `<section class="hero"><div><div class="eyebrow">Opportunity directory</div><h1>Explore</h1></div></section>
  <div class="filterbar">${searchBox("Search clubs, internships, events, scholarships")}
  <div class="chips filters" role="group" aria-label="Type"><button class="chip sm" aria-pressed="${ui.ftype === ""}" data-act="ftype" data-v="">All types</button>${Object.keys(
    TYPES,
  )
    .map(
      (t) =>
        `<button class="chip sm" aria-pressed="${ui.ftype === t}" data-act="ftype" data-v="${t}">${TYPES[t][0]}</button>`,
    )
    .join("")}</div>
  <div class="chips filters" role="group" aria-label="Where and who"><button class="chip sm" aria-pressed="${ui.fscope === ""}" data-act="fscope" data-v="">Anywhere</button><button class="chip sm" aria-pressed="${ui.fscope === "wsu"}" data-act="fscope" data-v="wsu">At WSU</button><button class="chip sm" aria-pressed="${ui.fscope === "beyond"}" data-act="fscope" data-v="beyond">Beyond WSU</button><button class="chip sm" aria-pressed="${ui.all}" data-act="all">Show all majors</button></div></div>
  <div id="results">${results()}</div>
`;
  return h;
}
let RES = { pred: null, plain: false, you: null };
const hay = (o) =>
  o._h ||
  (o._h = [
    o.title,
    o.org,
    o.summary,
    o.qualify,
    (o.tags || []).join(" "),
    (TYPES[o.type] || [])[0],
    o.meet,
    o.place,
  ]
    .join(" ")
    .toLowerCase());
function found() {
  const toks = ui.q
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 1 || /\d/.test(t)),
    out = [];
  for (const o of LIST) {
    if (RES.pred && !RES.pred(o)) continue;
    if (!RES.plain && ((ui.ftype && o.type !== ui.ftype) || (ui.fscope && o.scope !== ui.fscope))) continue;
    let sc = 1;
    if (toks.length) {
      const t = o.title.toLowerCase(),
        h = hay(o);
      sc = 0;
      let ok = true;
      for (const k of toks) {
        if (!h.includes(k)) {
          ok = false;
          break;
        }
        sc += t.startsWith(k) ? 100 : t.includes(" " + k) ? 60 : t.includes(k) ? 40 : 10;
      }
      if (!ok) continue;
    } else if (!ui.all && !(eligible(o) && !(o.support && !supportOptIn()) && (!RES.you || RES.you(o)))) continue;
    out.push({ o, sc, b: subjectFit(o)?.points || (goalTopic(o) ? 20 : 0) });
  }
  return out.sort(
    (a, b) =>
      b.sc - a.sc ||
      b.b - a.b ||
      (a.o.src ? 1 : 0) - (b.o.src ? 1 : 0) ||
      (b.o.weight || 0) - (a.o.weight || 0) ||
      (b.o.members || 0) - (a.o.members || 0) ||
      (a.o.title < b.o.title ? -1 : 1),
  );
}
function results() {
  const r = found();
  if (!r.length)
    return `<div class="empty">${LIST.length ? (ui.q ? "Nothing matches “" + esc(ui.q) + "”. Try a shorter word." : "Nothing here for your profile yet. Switch to all.") : "No listings loaded yet."}</div>`;
  const show = r.slice(0, ui.limit);
  return `<p class="count">${r.length} result${r.length > 1 ? "s" : ""}</p><div class="grid cols2">${show.map((x) => card({ o: x.o, i: stepIndex(x.o) }, "list")).join("")}</div>${r.length > show.length ? `<div class="seeall"><button class="btn ghost" data-act="more">Show more</button></div>` : ""}`;
}
function sugg() {
  if (ui.q.trim().length < 2) return "";
  return found()
    .slice(0, 6)
    .map(
      (x) =>
        `<button type="button" data-act="sugg" data-id="${esc(x.o.id)}"><span>${esc(x.o.title)}</span><small>${esc((TYPES[x.o.type] || ["", ""])[1])}${x.o.meet ? " · " + esc(x.o.meet) : x.o.dates && x.o.dates[0] && x.o.src ? " · " + fmtShort(x.o.dates[0].date) : ""}</small></button>`,
    )
    .join("");
}
const searchBox = (ph) =>
  `<div class="sbox"><input type="search" id="q" placeholder="${esc(ph)}" value="${esc(ui.q)}" aria-label="${esc(ph)}" autocomplete="off"><div class="sugg" id="sugg" hidden></div></div>`;
const youPred = (o) => relevantSuggestion(o);
const isClub = (o) => o.type === "club";
function viewClubs() {
  RES = { pred: isClub, plain: true, you: youPred };
  const n = LIST.filter(isClub).length;
  return `<section class="hero"><div><div class="eyebrow">WSU Pullman</div><h1>Clubs</h1><div class="who">${n} organizations in the WSU catalog. Matches for ${esc(majorRow()[1])} come first.</div></div></section>
  <div class="toolbar">${searchBox("Search clubs by name or interest")}<div class="seg" role="group" aria-label="Which clubs to show"><button aria-pressed="${!ui.all}" data-act="allset" data-v="0">For you</button><button aria-pressed="${ui.all}" data-act="allset" data-v="1">All clubs</button></div></div>
  <div id="results">${results()}</div>`;
}
function viewJobs() {
  RES = { pred: (o) => o.type === "career", plain: true, you: youPred };
  const p = prof();
  return `<section class="hero"><div><div class="eyebrow">Internships and career</div><h1>Internships</h1><div class="who">Career events at WSU, programs to apply to, and saved postings from employer career pages. Open the employer’s page to check current availability.</div></div></section>
  <div class="toolbar">${searchBox("Search roles, companies or events")}<div class="seg" role="group" aria-label="Which listings to show"><button aria-pressed="${!ui.all}" data-act="allset" data-v="0">For you</button><button aria-pressed="${ui.all}" data-act="allset" data-v="1">Browse all</button></div></div>
  <div id="results">${results()}</div>
  <div class="strip"><div><b>WSU Handshake</b><span>Most internships for WSU students are posted here. Sign in and try “${esc(majorRow()[1].toLowerCase())} intern”.</span></div><a class="btn primary sm" href="https://wsu.joinhandshake.com/login" target="_blank" rel="noopener">Open Handshake ↗</a></div>`;
}
function viewPath() {
  const p = prof(),
    ex = ROADX[grp()] || ROADX._;
  let total = 0,
    done = 0;
  const cols = ROAD.map((y, n) => {
    const items = y.items.map((t, j) => [n + ":" + j, t]);
    if (ex[n]) items.unshift([n + ":x", ex[n]]);
    total += items.length;
    done += items.filter((i) => state.road[i[0]]).length;
    return `<div class="year ${+p.year === n + 1 ? "now" : ""}"><div class="n">${n + 1}</div><h3>${y.name}${+p.year === n + 1 ? " · you are here" : ""}</h3><div class="theme">${y.theme}</div>${items.map((i) => `<button class="check" aria-pressed="${!!state.road[i[0]]}" data-act="road" data-v="${i[0]}"><i class="box"></i><span>${esc(i[1])}</span></button>`).join("")}</div>`;
  }).join("");
  return `<section class="hero"><div><div class="eyebrow">The long view</div><h1>Four years</h1><div class="who">Suggestions for ${esc(majorRow()[1])}, not WSU requirements.</div></div><div style="min-width:220px"><strong style="font-family:var(--display);font-size:17px">${done} of ${total} checked</strong><div class="bar" style="margin-top:8px"><i style="width:${total ? (done / total) * 100 : 0}%"></i></div></div></section><div class="years">${cols}</div>`;
}
function profileFields() {
  const p = prof();
  return `
  <label class="f">Name<input type="text" id="p-name" data-p="name" value="${esc(p.name)}" autocomplete="given-name"></label>
  ${dd("grad", "Graduation year", p.grad || ayEnd() + 4 - p.year, gradOpts())}
  ${dd("major", "Major", majorRow()[1], majorOpts(), { search: "Search WSU majors", full: true })}
  ${dd("age", "Age, optional", p.age, AGES, { ph: "Choose if you like" })}
  <div class="fieldset full"><span>What you want more of</span><div class="chips">${Object.keys(TYPES)
    .map(
      (t) =>
        `<button class="chip" aria-pressed="${p.interests.includes(t)}" data-act="interest" data-v="${t}">${TYPES[t][0]}</button>`,
    )
    .join("")}</div></div>
  <div class="fieldset full"><span>How much you want to take on</span><div class="chips">${Object.keys(COMMIT)
    .map(
      (c) =>
        `<button class="chip" aria-pressed="${p.commit === c}" data-act="commit" data-v="${c}">${COMMIT[c][1]} · ${COMMIT[c][2].toLowerCase()}</button>`,
    )
    .join("")}</div></div>
  <div class="fieldset"><span>Where to look</span><div class="chips"><button class="chip" aria-pressed="${p.reach === "wsu"}" data-act="setp" data-f="reach" data-v="wsu">WSU only</button><button class="chip" aria-pressed="${p.reach === "both"}" data-act="setp" data-f="reach" data-v="both">WSU and beyond</button></div></div>
  <div class="fieldset"><span>Programs that cost money</span><div class="chips"><button class="chip" aria-pressed="${!p.paid}" data-act="paid" data-v="0">Free only</button><button class="chip" aria-pressed="${!!p.paid}" data-act="paid" data-v="1">Show paid ones too</button></div></div>
  <div class="fieldset full"><button class="chip" aria-pressed="${p.supportGroups === true}" data-act="supportgroups">Include support groups in my weekly suggestions</button><p class="small muted">Off by default. When off, support and recovery groups are not picked for This week or For you. You can still search for them, browse everything, and any you saved stay on your plan.</p></div>
  ${priorityField()}
  <label class="f">GPA, optional<input type="number" id="p-gpa" data-p="gpa" min="0" max="4" step="0.01" inputmode="decimal" value="${esc(p.gpa)}" placeholder="Leave blank and we flag GPA rules"></label>`;
}
function reminderFields() {
  const r = state.remind,
    w = weeklyCal();
  return `
  ${dd(
    "rday",
    "Weekly summary day",
    r.day,
    DOWL.map((d, i) => ({ v: i, l: d })),
  )}
  ${dd("rtime", "Time", r.time, TIMES)}
  ${dd(
    "rlead",
    "Warn me before key dates",
    r.lead,
    [1, 3, 7, 14].map((n) => ({ v: n, l: n === 1 ? "1 day ahead" : n + " days ahead" })),
  )}
  <div class="actions"><button class="btn primary sm" data-act="appleweekly">Add to Apple Calendar</button><a class="btn ghost sm" href="${esc(gcal(w))}" target="_blank" rel="noopener">Google Calendar</a></div>`;
}
function viewYou() {
  const e = entries(),
    d = e.filter((x) => x.e.status === "done"),
    sk = e.filter((x) => x.e.status === "skipped");
  return `<section class="hero"><div><div class="eyebrow">You, reminders and progress</div><h1>Profile</h1><div class="morelinks"><button class="btn ghost sm" data-act="tab" data-v="month">Coming up →</button><button class="btn ghost sm" data-act="tab" data-v="path">Four-year checklist →</button></div><div class="status live"><span><i></i>${window.SUNDAY_CONFIG?.mode === "cloud" ? '<span role="status" data-account-status>' + sundayAccount.statusText() + '</span>' : cloud.ok ? "Local database connected" : "Using browser storage"}</span></div></div></section>
  <div class="grid" style="grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);align-items:start" id="ygrid">
  <div class="panel">${window.SUNDAY_CONFIG?.mode === "cloud" ? sundayAccount.controls() : ""}<h3>About you</h3><div class="form">${profileFields()}</div></div>
  <div class="grid">
   ${planEntry()}
   <div class="panel"><h3>This week</h3>
    <div class="fieldset"><span>I am</span><div class="chips"><button class="chip sm" aria-pressed="${prof().where === "pullman"}" data-act="where" data-v="pullman">In Pullman</button><button class="chip sm" aria-pressed="${prof().where !== "pullman"}" data-act="where" data-v="away">Away or on break</button></div></div>
    <div class="fieldset"><span>Busy days</span><div class="chips">${DOW.map((d, i) => `<button class="chip sm" aria-pressed="${prof().busy.includes(i)}" data-act="busy" data-v="${i}">${d}</button>`).join("")}</div></div></div>
   <div class="panel"><h3>Reminders</h3>${reminderFields()}<p class="muted small">Confirm in Calendar to turn on the weekly reminder.</p></div>
   <div class="panel"><h3>Progress</h3><div class="stats"><div class="stat"><b>${d.length}</b><span>steps done</span></div><div class="stat"><b>${streak()}</b><span>week streak</span></div><div class="stat"><b>${sk.length}</b><span>skipped</span></div></div><div class="actions"><button class="btn ghost sm" data-act="report">Copy my report</button></div></div>
   <div class="panel"><h3>What it’s learned</h3>${(() => {
     const L = learned(),
       k = Object.keys(L)
         .filter((t) => L[t] !== 0 && TYPES[t])
         .sort((a, b) => L[b] - L[a]);
     if (!k.length)
       return '<p class="muted" style="font-size:14.5px">Nothing yet. It learns from what you add, finish and skip.</p>';
     const mx = Math.max(...k.map((t) => Math.abs(L[t])), 6);
     return k
       .map(
         (t) =>
           `<div class="lrow"><span>${TYPES[t][0]}</span><div class="bar"><i style="width:${Math.max(6, (Math.abs(L[t]) / mx) * 100)}%;background:${L[t] > 0 ? "var(--wheat)" : "var(--line)"}"></i></div><small>${L[t] > 0 ? "more" : "less"}</small></div>`,
       )
       .join("");
   })()}</div>
   <section class="panel reset-account"><h3>${window.SUNDAY_CONFIG?.mode === "cloud" ? "Delete your account" : "Clear this local profile"}</h3>
   ${ui.confirmReset ? `<p>${window.SUNDAY_CONFIG?.mode === "cloud" ? `Permanently delete the Sunday Plan account${sundayAccount.email() ? " for <strong>" + esc(sundayAccount.email()) + "</strong>" : ""}? This removes your profile, saved steps, notes and progress. You can start again with the same Google email. Your Google account stays active.` : "Permanently clear the profile, saved steps, notes and progress on this local planner?"}</p>
   ${ui.resetError ? `<p role="alert">${esc(ui.resetError)}</p>` : ""}
   <div class="actions"><button class="btn ghost sm" data-act="cancel">Keep my data</button>${window.SUNDAY_CONFIG?.mode === "cloud" ? '<button class="btn danger sm" data-account="delete">Delete my Sunday Plan account</button>' : '<button class="btn danger sm" data-act="reset2">Clear everything</button>'}</div>` :
   '<div class="actions"><button class="btn ghost sm" data-act="reset">Clear my data</button></div>'}</section>
  </div></div><p class="muted small">Sunday Plan · Version ${esc(document.querySelector('meta[name="application-version"]').content)}</p>`;
}
const OBMSG = [
  "Add your name and graduation year first.",
  "Pick your major, or choose Undecided or exploring.",
  "Pick at least one thing you want more of.",
  "Choose how much you want to take on.",
  "Choose where to look and whether paid programs are okay.",
  "Pick the day you want your weekly summary.",
];
function obOk(n) {
  const p = prof();
  return [
    !!String(p.name || "").trim() && !!p.grad,
    !!p.major_set,
    p.interests.length > 0,
    !!p.commit,
    !!p.reach && (p.paid === true || p.paid === false),
    !!state.remind.set,
  ][n];
}
function viewOnboard() {
  const p = prof(),
    r = state.remind,
    n = ui.ob,
    N = 6;
  let b = "";
  if (n === 0)
    b = `<h1>A short plan for your week at WSU.</h1><p class="sub">Clubs, internships, scholarships and volunteering you qualify for, with one next step each. Six quick questions first.</p>${testerMode ? '<p class="small muted">Try the planner without an account. Your plan saves in this browser.</p>' : ""}<label class="f">What should we call you?<input type="text" id="ob-name" data-p="name" value="${esc(p.name)}" placeholder="First name" autocomplete="given-name"></label>${dd("grad", "When do you graduate?", p.grad, gradOpts(), { ph: "Pick your graduation year" })}${dd("age", "How old are you? Optional", p.age, AGES, { ph: "Skip or choose" })}`;
  if (n === 1)
    b = `<h1>What are you studying?</h1><p class="sub">We match clubs, events and internships to it.</p>${dd("major", "Your major", p.major_set ? majorRow()[1] : "", majorOpts(), { search: "Search WSU majors", ph: "Choose your major" })}<p class="muted" style="font-size:13.5px">The list is WSU’s own degree list for the Pullman colleges. Not there yet? Pick Undecided or exploring.</p>`;
  if (n === 2)
    b = `<h1>What do you want more of?</h1><p class="sub">Pick as many as you like. You can change this any week.</p><div class="optgrid">${Object.keys(
      TYPES,
    )
      .map(
        (t) =>
          `<button class="optbtn" aria-pressed="${p.interests.includes(t)}" data-act="interest" data-v="${t}">${TYPES[t][0]}</button>`,
      )
      .join("")}</div>${priorityField()}`;
  if (n === 3)
    b = `<h1>How much do you want to take on?</h1><p class="sub">This sets how much we put in front of you each week.</p><div class="opt">${Object.keys(
      COMMIT,
    )
      .map(
        (c) =>
          `<button class="optbtn" aria-pressed="${p.commit === c}" data-act="commit" data-v="${c}"><span>${COMMIT[c][1]}<small>${COMMIT[c][2]}</small></span></button>`,
      )
      .join("")}</div>`;
  if (n === 4)
    b = `<h1>How far should we look?</h1><p class="sub">Beyond WSU means national internships, remote volunteering and outside programs.</p><div class="opt"><button class="optbtn" aria-pressed="${p.reach === "both"}" data-act="setp" data-f="reach" data-v="both"><span>WSU and beyond<small>Campus first, plus bigger programs you can apply to</small></span></button><button class="optbtn" aria-pressed="${p.reach === "wsu"}" data-act="setp" data-f="reach" data-v="wsu"><span>WSU only<small>Keep it to campus and Pullman</small></span></button></div><div class="fieldset"><span>Open to programs that cost money?</span><div class="chips"><button class="chip" aria-pressed="${p.paid === false}" data-act="paid" data-v="0">Free only</button><button class="chip" aria-pressed="${p.paid === true}" data-act="paid" data-v="1">Show paid ones too</button></div></div>`;
  if (n === 5)
    b = `<h1>When do you want your weekly summary?</h1><p class="sub">This sets the start of your planning week. You can change your reminder later. You can add it to your calendar as a repeating reminder once you are in.</p>${dd(
      "rday",
      "Day",
      r.set ? r.day : "",
      DOWL.map((d, i) => ({ v: i, l: d })),
      { ph: "Pick a day" },
    )}${dd("rtime", "Time", r.time, TIMES)}${planPrivacy()}`;
  return `<div class="ob"><div class="obart" aria-hidden="true"><svg viewBox="0 0 600 900" preserveAspectRatio="xMidYMax slice"><circle cx="430" cy="250" r="74" fill="var(--wheat)"/><path d="M0 520C120 440 240 470 360 520S540 560 600 500V900H0Z" fill="#2a6a52"/><path d="M0 610C150 540 260 600 400 590S560 560 600 600V900H0Z" fill="#1f5743"/><path d="M0 700C140 640 300 700 430 680S560 660 600 690V900H0Z" fill="#184636"/><path d="M0 790C160 740 330 800 600 760V900H0Z" fill="#103528"/></svg><div class="obart-t"><span>For students in Pullman</span><b>Your week,<br>planned.</b></div></div><div class="obmain"><div class="obcard"><div class="brand"><i></i>Sunday Plan</div>${window.SUNDAY_CONFIG?.mode === "cloud" ? '<button class="btn text sm" data-account="logout">Sign out</button>' : ""}<div class="obprog" aria-label="Step ${n + 1} of ${N}">${Array.from({ length: N }, (_, i) => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</div>${b}<div class="obnav">${n > 0 ? `<button class="btn ghost" data-act="obback">Back</button>` : "<span></span>"}<button class="btn primary ${obOk(n) ? "" : "off"}" data-act="obnext">${n === N - 1 ? "Create my plan" : "Next"}</button></div></div></div></div>`;
}
