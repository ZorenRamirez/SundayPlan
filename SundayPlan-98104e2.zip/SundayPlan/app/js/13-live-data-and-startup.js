/*
  13-live-data-and-startup.js — connects to the database and starts the app.

  connect() asks for the database, loads the hand-checked listings and the student's
  saved plan, and keeps the newer of the browser copy and the database copy.
  The last line starts everything: render(); connect(); loadCatalog();
*/
"use strict";
/* ---------- live data ---------- */
function clean(d, id) {
  if (!d || typeof d !== "object" || typeof d.title !== "string" || !TYPES[d.type]) return null;
  const o = JSON.parse(JSON.stringify(d));
  o.id = id;
  o.steps = Array.isArray(o.steps)
    ? o.steps.filter((s) => s && typeof s.text === "string").map((s) => ((s.min = +s.min || 15), s))
    : [];
  o.dates = Array.isArray(o.dates)
    ? o.dates.filter((x) => x && isDate(x.date) && typeof x.label === "string")
    : [];
  for (const s of o.steps) if (s.event != null && !o.dates[s.event]) delete s.event;
  o.scope = o.scope === "beyond" ? "beyond" : "wsu";
  o.cost = o.cost === "paid" ? "paid" : "free";
  return o;
}
async function connect() {
  const c = window.claude;
  if (!c || typeof c.use !== "function") {
    feed.state = "offline";
    render();
    return;
  }
  let db = null,
    user = null;
  try {
    [db, user, downloads] = await Promise.all([c.use("db"), c.use("user"), c.use("downloads")]);
  } catch (e) {}
  if (!db) {
    feed.state = "offline";
    render();
    return;
  }
  const slow = setTimeout(() => {
    if (feed.state === "loading") {
      feed.state = LIST.length ? "cached" : "slow";
      render();
    }
  }, 10000);
  db.collection("listings").onSnapshot(
    (snap) => {
      CUR = snap.docs.map((d) => clean(d.data(), d.id)).filter(Boolean);
      LIST = build();
      if (!snap.metadata.fromCache) {
        clearTimeout(slow);
        feed.state = "live";
      } else if (feed.state === "loading") feed.state = "cached";
      try {
        localStorage.setItem(LKEY, JSON.stringify({ list: CUR, at: today(), meta: feed.meta }));
      } catch (e) {}
      render();
    },
    () => {
      clearTimeout(slow);
      feed.state = "offline";
      render();
    },
  );
  db.doc("meta/feed").onSnapshot(
    (s) => {
      feed.meta = s.exists ? JSON.parse(JSON.stringify(s.data())) : null;
      render();
    },
    () => {},
  );
  try {
    const uid = user ? await user.id() : null;
    if (uid) {
      cloud.doc = db.doc("data/users/" + uid + "/state");
      const s = await cloud.doc.get();
      cloud.ok = true;
      if (s.exists) {
        const d = s.data();
        if ((d.savedAt || 0) > (state.savedAt || 0)) {
          state = adopt(d);
          try {
            localStorage.setItem(KEY, JSON.stringify(state));
          } catch (e) {}
          render();
        }
      }
    }
  } catch (e) {}
}
async function loadTesterListings() {
  downloads = await window.claude.use("downloads");
  try {
    const response = await fetch("data/curated.json");
    if (!response.ok) throw Error("Catalog unavailable");
    const data = await response.json();
    CUR = data.listings.map(o => clean(o, o.id)).filter(Boolean);
    feed.meta = data.meta;
    feed.state = "live";
    LIST = build();
  } catch { feed.state = "offline"; }
  await loadCatalog();
  render();
}
ui.tab = sectionFromUrl();
if (window.SUNDAY_CONFIG?.mode === "local") {
  render();
  connect();
  loadCatalog();
} else if (testerMode) {
  render();
  loadTesterListings();
} else {
  sundayAccount.start();
}
