/*
  07-calendar.js — "Add to calendar".

  Builds Google Calendar links and Apple/iCloud calendar (.ics) files for events,
  planned steps, weekly club meetings and the weekly summary reminder.
*/
"use strict";
/* ---------- calendar ---------- */
function laToUtc(dateIso, hhmm) {
  const [y, m, d] = dateIso.split("-").map(Number),
    [h, mi] = hhmm.split(":").map(Number);
  for (const off of [8, 7]) {
    const t = new Date(Date.UTC(y, m - 1, d, h + off, mi));
    const hr = +new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Los_Angeles",
      hour: "numeric",
      hourCycle: "h23",
    }).format(t);
    if (hr === h) return t;
  }
  return new Date(Date.UTC(y, m - 1, d, h + 8, mi));
}
const compact = (s) => s.replace(/-/g, "");
function calFor(o, d) {
  return {
    uid: o.id + "-" + d.date + "-" + (d.start || "day") + "-" + (d.label || o.title),
    title: (d.label && d.label !== o.title && !o.title.includes(d.label) ? d.label + ": " : "") + o.title,
    date: d.date,
    start: d.start,
    end: d.end,
    endDate: d.endDate,
    location: d.location || "",
    details: [
      o.org,
      o.qualify,
      safeUrl(o.url),
      "From Sunday Plan. Confirm on the organizer page before you go.",
    ]
      .filter(Boolean)
      .join("\n\n"),
  };
}
function calForStep(x) {
  const s = x.s,
    o = x.o;
  if (s.event != null && o.dates[s.event]) return calFor(o, o.dates[s.event]);
  // A step without a day the student chose has nothing to put on a calendar.
  if (!isDate(x.e.day)) return null;
  return {
    uid: "step-" + x.k.replace(":", "-"),
    title: "My step: " + o.title,
    date: x.e.day,
    location: "",
    details: [s.text, s.ask && o.ask ? askText(o) : "", s.min ? "About " + dur(s.min) : "", o.org, safeUrl(o.url)].filter(Boolean).join("\n\n"),
  };
}
function weeklyCal() {
  const r = state.remind;
  let d = today();
  for (let i = 0; i < 7; i++) {
    if (P(d).getDay() === +r.day) break;
    d = addDays(d, 1);
  }
  const [h, m] = r.time.split(":").map(Number);
  const e = h * 60 + m + 15;
  return {
    uid: "weekly-summary",
    title: "Open Sunday Plan: this week’s picks",
    date: d,
    start: r.time,
    end: pad(Math.floor(e / 60) % 24) + ":" + pad(e % 60),
    location: "",
    details: "Open Sunday Plan on your Mac, check in on last week, and choose this week’s step.",
    rrule: "FREQ=WEEKLY;BYDAY=" + ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][+r.day],
  };
}
function gcal(c) {
  const u = new URLSearchParams({ action: "TEMPLATE", text: c.title, details: c.details || "" });
  if (c.location) u.set("location", c.location);
  if (c.start) {
    u.set(
      "dates",
      compact(c.date) +
        "T" +
        c.start.replace(":", "") +
        "00/" +
        compact(calendarFile.endDate(c)) +
        "T" +
        (c.end || c.start).replace(":", "") +
        "00",
    );
    u.set("ctz", "America/Los_Angeles");
  } else u.set("dates", compact(c.date) + "/" + compact(addDays(c.date, 1)));
  if (c.rrule) u.set("recur", "RRULE:" + c.rrule);
  return "https://calendar.google.com/calendar/render?" + u.toString();
}
async function appleFile(items, name) {
  if (!items.length) return toast("Nothing to add yet.");
  const lead = Number(state.remind.lead) || 7;
  try {
    if (window.SUNDAY_CONFIG?.macCalendar) {
      try {
        const response = await fetch("/api/calendar/open", {
          method: "POST", headers: {"Content-Type":"application/json"},
          body: JSON.stringify({items, lead})
        });
        if (response.ok) {
          toast("Choose a calendar in Apple Calendar, then select OK.");
          return;
        }
      } catch { /* Use the portable file when the local handoff is unavailable. */ }
    }
    const data = new Blob([calendarFile.write(items, lead)], {type:"text/calendar;charset=utf-8"});
    await downloads.save({filename:name + ".ics", data});
    toast("Open the downloaded .ics file in Calendar to add the " + (items.length === 1 ? "event." : "events."));
  } catch (error) {
    if (error?.code !== "declined") toast("Could not open Calendar. Please try again.");
  }
}
const calCache = new Map();
function appleButton(c, label = "Apple Calendar") {
  if (!c || !isDate(c.date)) return "";
  const id = "c" + calCache.size;
  calCache.set(id, c);
  return `<button class="datechip" data-act="apple" data-id="${id}" title="Add to Apple Calendar" aria-label="Add ${esc(c.title)} to Apple Calendar">${esc(label)}</button>`;
}
function calBtns(c) {
  if (!c || !isDate(c.date)) return "";
  return `<span class="cal"><a class="datechip" href="${esc(gcal(c))}" target="_blank" rel="noopener" title="Add to Google Calendar">+ Google</a>${appleButton(c)}</span>`;
}
