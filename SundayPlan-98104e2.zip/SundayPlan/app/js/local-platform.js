"use strict";
/*
  local-platform.js — the LOCAL stand-in for what Claude gave the app.

  When Sunday Plan ran inside Claude, the page asked Claude for three things:
    claude.use("db")         a database (shared listings + each person's saved plan)
    claude.use("user")       who is signed in
    claude.use("downloads")  permission to save a file (the calendar file)

  On your Mac there is no Claude around the page, so this file answers those
  same three requests itself. The rest of the app does not know the difference,
  which is why none of the app files had to change.

    db         -> talks to server.js, which reads and writes local-data/database.json
    user       -> always answers "local-user" (there is no real sign-in yet)
    downloads  -> uses the browser's normal download

  When the app moves to a real database with logins, this is the file that
  gets replaced. Only the parts the app actually uses are built here.
*/
(() => {
  const LOCAL_USER_ID = "local-user";

  // One small helper for talking to server.js.
  async function api(method, kind, path, body) {
    const res = await fetch("/api/db/" + kind + "?path=" + encodeURIComponent(path), {
      method,
      cache: "no-store",
      headers: body === undefined ? {} : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (!res.ok) {
      const err = new Error("Local database request failed (" + res.status + ")");
      err.code = res.status === 400 ? "invalid_argument" : "unavailable";
      throw err;
    }
    return res.json();
  }

  // What the app gets back when it reads one document.
  const docSnapshot = (id, found) => ({
    id,
    exists: !!found.exists,
    data: () => (found.exists ? JSON.parse(JSON.stringify(found.data)) : undefined),
    metadata: { fromCache: false },
  });

  const db = {
    // One document, for example db.doc("data/users/local-user/state")
    doc(path) {
      const id = path.split("/").pop();
      return {
        id,
        async get() {
          return docSnapshot(id, await api("GET", "doc", path));
        },
        async set(data) {
          await api("PUT", "doc", path, data);
        },
        async delete() {
          await api("DELETE", "doc", path);
        },
        // Inside Claude this keeps listening for changes. Locally it reads once;
        // reload the page to pick up edits made to database.json by hand.
        onSnapshot(onData, onError) {
          this.get().then(onData, onError || (() => {}));
          return () => {};
        },
      };
    },

    // A group of documents, for example db.collection("listings")
    collection(path) {
      return {
        doc: (id) => db.doc(path + "/" + id),
        async get() {
          const found = await api("GET", "collection", path);
          return {
            docs: found.docs.map((d) => docSnapshot(d.id, { exists: true, data: d.data })),
            metadata: { fromCache: false },
          };
        },
        onSnapshot(onData, onError) {
          this.get().then(onData, onError || (() => {}));
          return () => {};
        },
      };
    },
  };

  const user = {
    id: async () => LOCAL_USER_ID,
    isOwner: async () => true,
  };

  const downloads = {
    // The app hands over { filename, data } where data is the file's contents.
    async save({ filename, data }) {
      const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data]));
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    },
  };

  const parts = { db, user, downloads };
  window.claude = {
    use: (name) => Promise.resolve(parts[name] || null),
  };
})();
