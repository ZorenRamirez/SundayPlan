// Keep one recoverable draft per browser tab, project and student.
function samePlan(left, right) {
  if (left === right) return true;
  if (!left || !right || typeof left !== "object" || typeof right !== "object") return false;
  if (Array.isArray(left) !== Array.isArray(right)) return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length &&
    keys.every(key => Object.hasOwn(right, key) && samePlan(left[key], right[key]));
}
// Three-way merge of a student's plan. `base` is what this tab last saw, `mine` is this tab's
// state and `theirs` is what another tab saved. Independent changes are all kept. When both
// sides changed the same value, this tab's (the newest edit) wins, except a finished step stays finished.
function mergePlans(base, mine, theirs) {
  const plain = v => v && typeof v === "object" && !Array.isArray(v);
  const merge = (b, m, t, key) => {
    if (samePlan(m, t)) return m;
    if (samePlan(b, m)) return t;
    if (samePlan(b, t)) return m;
    if (plain(m) && plain(t)) {
      const out = {}, from = plain(b) ? b : {};
      for (const k of new Set([...Object.keys(m), ...Object.keys(t)])) {
        const v = merge(from[k], m[k], t[k], k);
        if (v !== undefined) out[k] = v;
      }
      return out;
    }
    if (key === "status" && (m === "done" || t === "done")) return "done";
    if (key === "savedAt") return Math.max(+m || 0, +t || 0);
    return m;
  };
  return merge(base ?? undefined, mine, theirs);
}
function createPlanSync({storage, key, read, write, onStatus, active, merge, onMerged}) {
  let revision = 0, baseline = null, draft = null, timer, inFlight, conflicted = false, stopped = false;
  const live = () => !stopped && active();
  function remember() {
    try {
      if (draft) storage.setItem(key, JSON.stringify(draft));
      else storage.removeItem(key);
      return true;
    } catch { return false; }
  }
  function matches(remote, edit) {
    return remote?.revision === edit.base + 1 && samePlan(remote.payload, edit.payload);
  }
  async function load() {
    const remote = await read();
    if (!live()) return null;
    revision = remote?.revision || 0;
    baseline = remote?.payload || {};
    try {
      const saved = JSON.parse(storage.getItem(key) || "null");
      if (Number.isInteger(saved?.base) && saved.base >= 0 && saved.payload && typeof saved.payload === "object") draft = saved;
    } catch {}
    if (draft && draft.base !== revision) {
      if (matches(remote, draft)) { draft = null; remember(); }
      else if (merge && remote?.payload && draft.from && typeof draft.from === "object") {
        draft = {base: revision, from: remote.payload, payload: merge(draft.from, draft.payload, remote.payload)};
        remember();
      } else conflicted = true;
    }
    onStatus(conflicted ? "conflict" : draft ? "pending" : "synced");
    if (draft && !conflicted) timer = setTimeout(flush, 0);
    return draft?.payload || remote?.payload || null;
  }
  function queue(payload) {
    if (!live()) return;
    draft = {base: draft?.base ?? revision, from: draft?.from ?? baseline, payload: structuredClone(payload)};
    const durable = remember();
    onStatus(conflicted ? "conflict" : durable ? "pending" : "volatile");
    clearTimeout(timer);
    if (!conflicted) timer = setTimeout(flush, 400);
  }
  async function drain() {
    let merges = 0;
    while (live() && draft && !conflicted) {
      const current = draft;
      try {
        let next = await write(current.base, current.payload);
        if (!live()) return;
        if (next === null) {
          const remote = await read();
          if (!live()) return;
          if (matches(remote, current)) next = remote.revision;
          else if (merge && remote?.payload && draft.from && typeof draft.from === "object" && merges++ < 5) {
            const payload = merge(draft.from, draft.payload, remote.payload);
            revision = remote.revision; baseline = remote.payload;
            draft = {base: remote.revision, from: remote.payload, payload};
            remember();
            onMerged?.(payload);
            continue;
          } else { conflicted = true; onStatus("conflict"); return; }
        }
        revision = next;
        baseline = current.payload;
        if (draft === current) draft = null;
        else { draft.base = next; draft.from = current.payload; }
        remember();
        onStatus(draft ? "pending" : "synced");
      } catch {
        if (live()) onStatus(remember() ? "offline" : "volatile");
        return;
      }
    }
  }
  function flush() {
    clearTimeout(timer);
    if (!inFlight) inFlight = Promise.resolve().then(drain).finally(() => { inFlight = undefined; });
    return inFlight;
  }
  async function useRemote() {
    const remote = await read();
    if (!live()) return null;
    if (draft) storage.setItem(key + ":conflict-backup", JSON.stringify(draft));
    revision = remote?.revision || 0;
    baseline = remote?.payload || {};
    draft = null;
    conflicted = false;
    remember();
    onStatus("synced");
    return remote?.payload || null;
  }
  function stop() { stopped = true; clearTimeout(timer); }
  return {load, queue, flush, useRemote, stop};
}
if (typeof module !== "undefined") module.exports = {createPlanSync, mergePlans};
