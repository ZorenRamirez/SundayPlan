/*
  06-engine.js — the thinking part. Nothing in here draws anything.

  Who qualifies for what, which next step to suggest this week and why, how picks are
  scored and learned from what the student does or skips, check-ins, the streak,
  and which dates are coming up.
*/
"use strict";
/* ---------- engine (pure given LIST, state, now) ---------- */
const prof = () => state.profile;
const majorRow = () => academicProfile().row;
const grp = () => majorRow()[0];
const isCarson = () => !!majorRow()[2];
const weekStart = (date = today()) => {
  let d = date;
  for (let i = 0; i < 7; i++) {
    if (P(d).getDay() === state.weekStartsOn) return d;
    d = addDays(d, -1);
  }
  return date;
};
const weekEnd = () => addDays(weekStart(), 6);
const pkey = (o, i) => o.id + ":" + i;
function matchMajor(o) {
  const m = o.majors && o.majors.length ? o.majors : ["all"];
  return m.includes("all") || (m.includes("carson") && isCarson()) || m.includes(grp());
}
function why_not(o) {
  const p = prof();
  if (!matchMajor(o)) return "Listed for other majors";
  if (o.years && o.years.length && !o.years.includes(+p.year))
    return "Listed for " + o.years.map((y) => YEARS[y].toLowerCase() + "s").join(" and ");
  if (o.cost === "paid" && !p.paid) return "Costs money, and you turned paid programs off";
  if (o.scope === "beyond" && p.reach === "wsu") return "Outside WSU, and you chose WSU only";
  if (o.gpa && p.gpa !== "" && +p.gpa < o.gpa) return "Listed minimum GPA is " + o.gpa.toFixed(1);
  if (o.grad) return "Graduate organization";
  return "";
}
const eligible = (o) => !why_not(o);
function stepIndex(o) {
  const t = today(),
    we = weekEnd(),
    st = o.steps || [];
  const fin = (i) => {
    const e = state.plan[pkey(o, i)];
    return e && e.status === "done";
  };
  let flexible = -1;
  for (let i = 0; i < st.length; i++) {
    const s = st[i];
    if (fin(i) || (s.to && s.to < t) || (s.from && s.from > t)) continue;
    if (s.event != null) {
      const date = o.dates?.[s.event];
      if (!date || date.date < t || date.date > we || prof().busy.includes(P(date.date).getDay())) continue;
      if (date.date === t && date.start && laToUtc(calendarFile.endDate(date), date.end || date.start) <= now()) continue;
      return i;
    }
    if (o.dateUnclear && i > 0 && !s.ask && s.where === "campus" && o.steps.some((step) => step.ask)) continue;
    if (flexible < 0) flexible = i;
  }
  return flexible;
}
const skippedNow = (o) =>
  !!state.weekly[o.id] ||
  Object.entries(state.plan).some(
    ([k, e]) =>
      k.startsWith(o.id + ":") && (e.status === "skipped" || e.status === "done") && e.week === weekStart(),
  );
const nextKey = (o) =>
  (o.dates || [])
    .filter((d) => isDate(d.date) && d.date >= today())
    .sort((a, b) => (a.date < b.date ? -1 : 1))[0];
function learned() {
  const a = {};
  const add = (t, n) => {
    if (t) a[t] = (a[t] || 0) + n;
  };
  for (const x of entries()) {
    if (!x.o) continue;
    const e = x.e,
      t = x.o.type;
    if (e.status === "done") add(t, 3);
    else if (e.status === "planned") add(t, 1.5);
    else if (e.status === "skipped")
      add(t, e.reason === "Not interested" ? -4 : e.reason === "No time this week" ? 0 : -1.5);
  }
  for (const id of Object.keys(state.weekly)) {
    const o = LIST.find((x) => x.id === id);
    if (o) add(o.type, 3);
  }
  for (const k of Object.keys(state.attend))
    if (state.attend[k]) {
      const o = LIST.find((x) => x.id === k.slice(0, k.lastIndexOf(":")));
      if (o) add(o.type, 1);
    }
  return a;
}
let LEARN = {};
function coach() {
  const p = prof(),
    t = today();
  const over = planned().filter((x) => x.e.day < t)[0];
  if (over)
    return {
      text: "Tick off or move “" + over.o.title + "”. It was planned for " + fmtDate(over.e.day) + ".",
    };
  const wkDue = weeklyList().filter((x) => x.due)[0];
  if (wkDue) return { text: "Did you make it to " + wkDue.o.title + " this week? Tick it on your list." };
  const pk = picks();
  for (const { o, i } of pk) {
    if (o.src) continue;
    const k = nextKey(o);
    if (k && k.key && i >= 0 && daysTo(k.date) <= 21 && !state.plan[pkey(o, i)])
      return {
        text:
          (o.title.includes(k.label) ? o.title : k.label.split(",")[0] + " for " + o.title) +
          " is " +
          inDays(daysTo(k.date)) +
          ". Add its next step.",
        k: pkey(o, i),
      };
  }
  const asked = doneAll().find(
    (x) => x.s && x.s.ask && ["club", "service", "leadership"].includes(x.o.type) && !state.weekly[x.o.id],
  );
  if (asked)
    return {
      text: "Heard back from " + asked.o.title + "? Add its confirmed meeting schedule.",
      wk: asked.o.id,
    };
  if (!planned().length && weekCount() === 0 && pk[0])
    return { text: "Start with your top pick: " + pk[0].o.title + ".", k: pkey(pk[0].o, pk[0].i) };
  const tried = new Set(
    entries()
      .filter((x) => x.o && x.e.status !== "skipped")
      .map((x) => x.o.type)
      .concat(Object.keys(state.weekly).map((id) => (LIST.find((o) => o.id === id) || {}).type)),
  );
  const gap = p.interests.find((ty) => !tried.has(ty));
  if (gap) {
    const c = pk.find((x) => x.o.type === gap);
    if (c)
      return {
        text: "Matches your interest in " + TYPES[gap][0].toLowerCase() + ".",
        k: pkey(c.o, c.i),
      };
  }
  const ex = ROADX[grp()] || ROADX._,
    n = +p.year - 1,
    items = (ex[n] ? [[n + ":x", ex[n]]] : []).concat(ROAD[n].items.map((it, j) => [n + ":" + j, it])),
    nx = items.find((it) => !state.road[it[0]]);
  if (nx)
    return { text: "From your " + ROAD[n].name.toLowerCase() + " checklist: " + nx[1] + ".", tab: "path" };
  return null;
}
function score(o, i) {
  const p = prof(),
    s = o.steps[i];
  let v = 0;
  if (p.interests.includes(o.type)) v += 30;
  if (PRIORITIES[p.priority]?.types.includes(o.type)) v += 20;
  v += subjectFit(o)?.points || 0;
  if (goalTopic(o)) v += 34;
  v += Math.max(0, Math.min(10, +o.weight || 3)) * 2;
  const k = nextKey(o);
  if (k && k.key) {
    const n = daysTo(k.date);
    v += n <= 7 ? 34 : n <= 21 ? 26 : n <= 45 ? 18 : n <= 75 ? 12 : n <= 110 ? 5 : 0;
  }
  if (s.event != null && o.dates[s.event] && o.dates[s.event].date <= weekEnd())
    v += o.type === "event" ? 12 : 40;
  v += s.min <= p.time ? 8 : -15;
  if (p.where !== "pullman" && s.where === "any") v += 5;
  if (+p.year === 1 && o.type === "club") v += 6;
  if (o.verify === "secondary") v -= 14;
  if (!o.src) v += 8;
  v += Math.max(-14, Math.min(14, LEARN[o.type] || 0));
  return v;
}
function candidates() {
  const p = prof();
  LEARN = learned();
  return LIST.filter((o) => eligible(o) && p.interests.includes(o.type) && relevantSuggestion(o))
    .map((o) => ({ o, i: stepIndex(o) }))
    .filter(
      (x) =>
        x.i >= 0 &&
        !x.o.nopick &&
        !state.stale[x.o.id] &&
        !(x.o.minYear && +p.year < x.o.minYear) &&
        !skippedNow(x.o) &&
        !(state.later && state.later[pkey(x.o, x.i)]) &&
        !(state.plan[pkey(x.o, x.i)] && state.plan[pkey(x.o, x.i)].status === "planned") &&
        !(p.where !== "pullman" && x.o.steps[x.i].where === "campus"),
    )
    .map((x) => ((x.s = score(x.o, x.i)), x))
    .sort((a, b) => b.s - a.s || (a.o.id < b.o.id ? -1 : 1));
}
function remainingMinutes() {
  const reserved = planned().filter(x => !isDate(x.e.day) || (x.e.day >= weekStart() && x.e.day <= weekEnd()))
    .reduce((sum, x) => sum + (x.s?.min || 0), 0) + weeklyList().length * 60;
  const freeDay = Array.from({length: daysTo(weekEnd()) + 1}, (_, i) => P(addDays(today(), i)).getDay())
    .some(day => !prof().busy.includes(day));
  return freeDay ? Math.max(0, prof().time - reserved) : 0;
}
function picks(ranked = candidates()) {
  const out = [];
  let remaining = remainingMinutes();
  const savedRank = currentRanking()?.items || [];
  function take(x) {
    const minutes = x.o.steps[x.i].min;
    if (out.length === 3 || out.includes(x) || minutes > remaining) return;
    if (x.o.type === "event" && x.o.src && out.some(y => y.o.type === "event" && y.o.src)) return;
    out.push(x);
    remaining -= minutes;
  }
  for (const item of savedRank) {
    const x = ranked.find(x => pkey(x.o,x.i) === item.key && !x.o.outdated && !x.o.support);
    if (x) take(x);
  }
  if (out.length) return out;
  for (const x of ranked) if (!out.some(y => y.o.type === x.o.type)) take(x);
  for (const x of ranked) take(x);
  return savedRank.length ? out : out.sort((a, b) => b.s - a.s);
}
function rankingSignature() {
  const p = prof();
  return JSON.stringify(["discipline-v2", weekStart(), FEEDS.meta?.builtAt || "", p.major, p.year, p.priority, p.goal || "", p.time,
    p.where, p.reach, p.paid, p.supportGroups === true, p.gpa, [...p.busy].sort(), [...p.interests].sort()]);
}
function currentRanking() {
  return state.recommendations?.signature === rankingSignature() && Array.isArray(state.recommendations.items)
    ? state.recommendations : null;
}
function fits(o, i) {
  const p = prof(),
    s = o.steps[i],
    out = [];
  const fit = subjectFit(o), topic = goalTopic(o);
  if (fit) out.push(fit.reason);
  if (topic) out.push("Your goal mentions “" + topic + "”");
  if (!out.length && (o.majors || []).includes("carson")) out.push("For business majors");
  if ((LEARN[o.type] || 0) >= 4) out.push("You keep choosing " + TYPES[o.type][0].toLowerCase());
  else if (p.interests.includes(o.type)) out.push("You asked for " + TYPES[o.type][0].toLowerCase());
  if (!out.length) out.push(o.src === "board" ? "Check the employer’s requirements" : "Browse this opportunity");
  const k = nextKey(o);
  if (k && daysTo(k.date) <= 60) out.push(k.label.split(",")[0] + " " + inDays(daysTo(k.date)));
  if (s.event != null && o.dates[s.event] && p.busy.includes(P(o.dates[s.event].date).getDay()))
    out.push("You marked " + DOWL[P(o.dates[s.event].date).getDay()] + " as busy");
  return out;
}
const entries = () =>
  Object.entries(state.plan).map(([k, e]) => {
    const [id, i] = k.split(":");
    const live = LIST.find((x) => x.id === id);
    const currentStep = live?.steps?.[+i];
    const saved = e.listing;
    if (currentStep && (!saved?.step || saved.step === currentStep.text)) return {k, e, o:live, i:+i, s:currentStep};
    const o = {id, title:saved?.title || live?.title || "Previously saved opportunity",
      org:saved?.org || "", type:saved?.type || live?.type || "program", url:saved?.url || "",
      dates:saved?.event ? [saved.event] : [], ask:saved?.question || "", archived:true};
    const s = {text:saved?.step || "The original listing is unavailable. Your saved plan is still here.", min:saved?.minutes || 0, ask:!!saved?.question, ...(saved?.event ? {event:0} : {})};
    return {k, e, o, i:+i, s};
  });
const planned = () =>
  entries()
    .filter((x) => x.e.status === "planned")
    .sort((a, b) => (isDate(a.e.day) !== isDate(b.e.day) ? (isDate(a.e.day) ? -1 : 1) : a.e.day < b.e.day ? -1 : a.e.day > b.e.day ? 1 : 0));
const dueCheckins = () => planned().filter((x) => x.e.day <= today());
const doneAll = () => entries().filter((x) => x.e.status === "done");
const doneThisWeek = () => doneAll().filter((x) => x.e.week === weekStart());
function nextMeeting(w, from) {
  if (w.interval === 2 && isDate(w.anchor)) {
    if (from <= w.anchor) return w.anchor;
    const days = Math.round((P(from) - P(w.anchor)) / 864e5);
    return addDays(w.anchor, 14 * Math.ceil(days / 14));
  }
  return addDays(from, (+w.day - P(from).getDay() + 7) % 7);
}
const weeklyList = (includeFuture = false) =>
  Object.entries(state.weekly)
    .map(([id, w]) => {
      const o = LIST.find((x) => x.id === id);
      if (!o || !w) return null;
      const d = nextMeeting(w, weekStart());
      if (d > weekEnd() && !includeFuture) return null;
      const went = d <= weekEnd() && !!state.attend[id + ":" + weekStart()];
      return { id, o, w, date: d, went, due: d <= today() && !went };
    })
    .filter(Boolean)
    .sort((a, b) => (a.date < b.date ? -1 : 1));
const weekCount = () => doneThisWeek().length + weeklyList().filter((x) => x.went).length;
function weeklyFor(o, w) {
  const d = nextMeeting(w, today());
  const [h, m] = w.time.split(":").map(Number),
    e = h * 60 + m + 60;
  return {
    uid: "weekly-" + o.id,
    title: o.title,
    date: d,
    start: w.time,
    end: pad(Math.floor(e / 60) % 24) + ":" + pad(e % 60),
    location: w.place || "",
    details: [o.org, safeUrl(o.url), w.interval === 2 ? "Every two weeks, from Sunday Plan." : "Weekly, from Sunday Plan."].filter(Boolean).join("\n\n"),
    rrule: "FREQ=WEEKLY;" + (w.interval === 2 ? "INTERVAL=2;" : "") + "BYDAY=" + ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][P(d).getDay()],
  };
}
function streak() {
  const w = new Set(
    doneAll()
      .map((x) => x.e.week)
      .concat(
        Object.keys(state.attend)
          .filter((k) => state.attend[k])
          .map((k) => k.slice(k.lastIndexOf(":") + 1)),
      ),
  );
  let s = weekStart(),
    n = 0;
  if (!w.has(s)) s = addDays(s, -7);
  while (w.has(s)) {
    n++;
    s = addDays(s, -7);
  }
  return n;
}
function weeksHit(n) {
  const w = new Set(
    doneAll()
      .map((x) => x.e.week)
      .concat(
        Object.keys(state.attend)
          .filter((k) => state.attend[k])
          .map((k) => k.slice(k.lastIndexOf(":") + 1)),
      ),
  );
  const out = [];
  let s = weekStart();
  for (let i = 0; i < n; i++) {
    out.unshift(w.has(s));
    s = addDays(s, -7);
  }
  return out;
}
function headsUp() {
  const p = prof(),
    lead = +state.remind.lead || 7,
    out = [];
  for (const o of LIST) {
    if (!eligible(o) || state.stale[o.id]) continue;
    const mine =
      (p.interests.includes(o.type) && relevantSuggestion(o)) || Object.keys(state.plan).some((k) => k.startsWith(o.id + ":"));
    if (!mine) continue;
    for (const d of o.dates || []) {
      if (!d.key || !isDate(d.date)) continue;
      const n = daysTo(d.date);
      if (n >= 0 && n <= lead) out.push({ o, d, n });
    }
  }
  return out.sort((a, b) => a.n - b.n || (a.o.src ? 1 : 0) - (b.o.src ? 1 : 0)).slice(0, 3);
}
function upcoming(all) {
  const out = [],
    p = prof();
  for (const o of LIST) {
    if (all ? o.scope === "beyond" : !eligible(o)) continue;
    const saved = !all && Object.entries(state.plan).some(([k, e]) => k.startsWith(o.id + ":") && e && e.status === "planned");
    if (!all && !saved && ((o.src && !p.interests.includes(o.type)) || !relevantSuggestion(o) || (o.support && !supportOptIn())))
      continue;
    for (const d of o.dates || []) if (isDate(d.date) && d.date >= today()) out.push({ o, d });
  }
  return out.sort((a, b) => (a.d.date < b.d.date ? -1 : a.d.date > b.d.date ? 1 : 0));
}
