# SundayPlan project instructions

- Run `npm test` before finishing a change.
- Never read or commit `.env.local`.
- Never edit `original/`.
- Keep the files in `app/js/` as plain scripts.
- Ask Zoren before committing.

## Working together

- Zoren owns product and release decisions. Copilot implements and tests. Claude independently reviews engineering choices and reproduces browser behavior. Codex documents and coordinates.
- Work from the same named checkout and project record. Give each change one implementation owner and one directly testable outcome.
- Use code for repeatable checks. Use judgment for relevance, usability, and tradeoffs. Bring findings and options to Zoren when a decision affects the product.
- Record the evidence, the environment, and the limits. Distinguish local changes, automated checks, browser checks, and what is live. Stop with an open question when a claim cannot be verified.
