// Run the browser's own planner functions with the shipped data and an isolated student.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const root = path.resolve(__dirname, "..");
process.env.TZ = "America/Los_Angeles";
const read = file => fs.readFileSync(path.join(root, file), "utf8");
function fixture() {
  const context = vm.createContext({
    window: { __NOW: "2026-11-23T10:30:00" },
    document: { addEventListener() {} }, URLSearchParams, calendarFile: require("../app/js/ical"),
    raw: JSON.parse(read("local-data/seed.json")).docs,
    feeds: Object.fromEntries(["clubs", "events", "jobs", "feed"].map(k => [k, JSON.parse(read("app/data/" + k + ".json"))])),
  });
  const run = code => vm.runInContext(code, context);
  for (const file of fs.readdirSync(path.join(root, "app/js")).filter(n => /^0[1-9]-|^10-/.test(n)).sort()) {
    vm.runInContext(read("app/js/" + file), context, { filename: file });
  }
  run(`CUR = Object.entries(raw).filter(([k]) => k.startsWith("listings/")).map(([k,v]) => ({...v, id:k.slice(9)}));
    FEEDS = {...feeds, meta:feeds.feed}; LIST = build();
    Object.assign(state.profile, {setup:true, name:"Test", grad:2030, year:1, major:"Finance",
      interests:["career","scholarship","club"], time:120, where:"pullman"});
    const minutes = () => picks().reduce((n,x) => n + x.o.steps[x.i].min, 0);
    const eventOf = x => x.o.dates?.[x.o.steps[x.i].event];
    const byId = id => LIST.find(o => o.id === id);`);
  return run;
}
test("future attendance stays in Coming up and out of candidates, picks and the coach", () => {
  const run = fixture();
  run("state.profile.interests = Object.keys(TYPES)");
  assert.equal(run('candidates().filter(x => eventOf(x)?.date > weekEnd()).length'), 0);
  assert.equal(run('upcoming(true).some(x => x.d.date === "2026-12-01")'), true);
  assert.equal(run('picks().some(x => eventOf(x)?.date > weekEnd())'), false);
  assert.equal(run('picks().filter(x => x.o.type === "event" && x.o.src).length <= 1'), true);
  assert.equal(run('!coach()?.k || picks().some(x => pkey(x.o,x.i) === coach().k)'), true);
  assert.equal(run('picks().length > 0 && minutes() <= 120'), true);
});
test("uncertain and alternating meetings ask for confirmation, weekly examples stay usable", () => {
  const run = fixture();
  for (const id of ["intl-business-club", "sales-club", "marketing-club"]) {
    assert.equal(run('byId("' + id + '").steps[0].ask'), true);
    assert.equal(run('byId("' + id + '").dateUnclear'), true);
    run('state.plan["' + id + ':0"] = {status:"done"}');
    assert.equal(run('stepIndex(byId("' + id + '"))'), -1);
  }
  for (const id of ["fire-club", "mis-club"]) {
    assert.match(run('byId("' + id + '").steps[0].text'), /^Go to a meeting/);
  }
  for (const meeting of ["Varies", "4:00–5:00", "First Wednesdays at 4pm", "Every other Monday at 5pm"]) {
    assert.equal(run("hasWeeklyMeeting(" + JSON.stringify(meeting) + ")"), false);
  }
});
test("a busy day and a finished event are independently filtered", () => {
  const run = fixture();
  run('const event = byId("ev-mental-well-meeting-45")');
  assert.equal(run("stepIndex(event)"), 0);
  run("state.profile.busy = [1]");
  assert.equal(run("stepIndex(event)"), -1);
  run('state.profile.busy = []; window.__NOW = "2026-11-23T21:00:00"');
  assert.equal(run("stepIndex(event)"), -1);
});
test("the weekly budget includes existing plans and meeting commitments", () => {
  const run = fixture();
  run("state.profile.interests = Object.keys(TYPES); state.profile.time = 60");
  assert.equal(run("minutes() > 0 && minutes() <= 60"), true);
  run('state.plan["finance-career-accelerator:0"] = {status:"planned", day:"2026-11-24"}');
  assert.equal(run("minutes() <= 50"), true);
  run('state.weekly["fire-club"] = {day:2,time:"17:30"}');
  assert.equal(run("picks().length"), 0);
});
test("the day picker stops on Saturday and summary changes preserve history", () => {
  const run = fixture();
  run(`for (const [i,week] of ["2026-11-08","2026-11-15","2026-11-22"].entries())
    state.plan["forage:"+i] = {status:"done", week};
    state.remind.day=3;`);
  assert.equal(run("streak()"), 3);
  assert.equal(run("weekCount()"), 1);
  run('window.__NOW = "2026-11-28T10:30:00"');
  assert.equal(run('dayChips("forage:0", []).match(/data-day=/g).length'), 1);
  assert.equal(run('adopt({remind:{day:4}}).weekStartsOn'), 4);
});
test("alternating meetings use the confirmed date in attendance and calendar exports", () => {
  const run = fixture();
  run('const club = byId("intl-business-club"); const schedule = state.weekly[club.id] = {day:3, interval:2, anchor:"2026-12-02", time:"17:00"}');
  assert.equal(run("weeklyList().length"), 0);
  assert.equal(run("weeklyList(true)[0].date"), "2026-12-02");
  assert.match(run("calendarFile.write([weeklyFor(club,schedule)])"), /RRULE:FREQ=WEEKLY;INTERVAL=2;BYDAY=WE/);
  run('window.__NOW = "2026-12-09T18:00:00"');
  assert.equal(run("weeklyList().length"), 0);
  assert.equal(run("weeklyFor(club,schedule).date"), "2026-12-16");
  assert.equal(run('nextMeeting({day:3},today())'), "2026-12-09");
});
test("a removed listing keeps its saved action and an older save remains manageable", () => {
  const run=fixture();
  run('state.plan["removed-post:0"]={status:"planned",day:"2026-11-22",listing:{title:"Career workshop",type:"career",step:"Review the agenda",minutes:15}}; state.plan["legacy:0"]={status:"planned",day:"2026-11-23"}');
  assert.match(run("viewWeek()"),/Career workshop/);
  assert.match(run("viewWeek()"),/Previously saved opportunity/);
  assert.match(run("coach().text"),/Career workshop/);
  run('ui.planning = "removed-post:0"');
  assert.match(run("viewWeek()"), /Review the agenda/);
  assert.match(run("viewWeek()"), /Optional: pick a day for yourself/);
  assert.equal(run('entries().find(x=>x.k==="removed-post:0").s.text'),"Review the agenda");
});
test("saving an action records the title and step before the source disappears", () => {
  const run=fixture();
  run('window.addEventListener=()=>{};save=()=>{}');
  run(read("app/js/12-actions.js"));
  run('const item=byId("intl-business-club");setPlan(item.id+":0",{status:"planned",day:"2026-11-24"})');
  for (const detailsOpen of [false, true]) {
    run("ui.open[item.id]=" + detailsOpen);
    const pick = run('card({o:item,i:0}, "top")');
    assert.ok(pick.includes(run("esc(askText(item))")));
    assert.equal(pick.match(/Copy question/g)?.length, 1);
  }
  assert.match(run("nextSavedCard(planned()[0])"),/Copy question/);
  assert.ok(run("calForStep(planned()[0]).details.includes(askText(item))"));
  run('LIST=LIST.filter(o=>o!==item)');
  assert.equal(run("planned()[0].o.title"),run("item.title"));
  assert.equal(run("planned()[0].s.text"),run("item.steps[0].text"));
  assert.equal(run("planned()[0].o.archived"),true);
  assert.match(run("nextSavedCard(planned()[0])"),/Copy question/);
});
test("a saved event still exports its time and location when the organizer listing disappears", () => {
  const run = fixture();
  run('window.addEventListener=()=>{};save=()=>{}');
  run(read("app/js/12-actions.js"));
  run(`const listing=byId("career-networking-night"), i=listing.steps.findIndex(s=>s.event!=null);
    setPlan(pkey(listing,i),{status:"planned",day:listing.dates[0].date});
    LIST=LIST.filter(o=>o!==listing);`);
  const event = run("calForStep(planned()[0])");
  assert.equal(event.date, "2027-02-08");
  assert.equal(event.start, "16:30");
  assert.match(event.location, /CUB Senior Ballroom/);
});
test("a full week shows the student's next saved action, at most two relevant dates, and an optional later idea", () => {
  const run = fixture();
  run(`state.profile.time=60; state.profile.major="Accounting";
    state.plan["career-networking-night:0"]={status:"planned",day:"2026-11-23",week:weekStart()};
    state.plan["scholarship-app:0"]={status:"planned",day:"2026-11-24",week:weekStart()};`);
  assert.equal(run("picks().length"), 0);
  const html = run("viewWeek()");
  assert.match(html,/Your next step/);
  assert.match(html,/Update your résumé/);
  assert.match(html,/Coming up for you/);
  assert.equal((html.match(/class="date-preview"/g)||[]).length,2);
  assert.match(html,/For later/);
  assert.match(html,/data-act="showlisting"/);
  assert.equal(run("planned().length"), 2);
});
test("a club meeting that fills the student's week has a real next-meeting card", () => {
  const run = fixture();
  const html = run(`state.profile.time=60;
    state.weekly["fire-club"]={day:2,time:"17:30",place:"Todd 216",interval:1};viewWeek()`);
  assert.match(html,/Your next meeting/);
  assert.match(html,/5:30 pm Pacific · Todd 216/);
  assert.match(html,/Add schedule to Apple Calendar/);
});
test("Undo done restores the original scheduled day, and removes an unscheduled completion", async () => {
  const run = fixture();
  run(`let clickHandler;
    document.addEventListener=(type, handler)=>{if(type==="click")clickHandler=handler};
    document.querySelector=()=>null;window.addEventListener=()=>{};
    save=()=>{};toast=()=>{};burst=()=>{};function render(){}
    const id="career-networking-night:0";
    const click=act=>clickHandler({target:{closest:()=>({dataset:{act,k:id}})}});
  `);
  run(read("app/js/12-actions.js"));
  run('setPlan(id,{status:"planned",day:"2026-11-18",week:"2026-11-15",note:"Keep my notes"})');
  await run('click("done")');
  assert.equal(run("state.plan[id].status"),"done");
  await run('click("undo")');
  assert.equal(run("state.plan[id].status"),"planned");
  assert.equal(run("state.plan[id].day"),"2026-11-18");
  assert.equal(run("state.plan[id].week"),"2026-11-15");
  assert.equal(run("state.plan[id].note"),"Keep my notes");
  run("delete state.plan[id]");
  await run('click("done")');
  await run('click("undo")');
  assert.equal(run("state.plan[id]"),undefined);
});
test("Everything on campus includes other majors and keeps off-campus opportunities out", () => {
  const run = fixture();
  run(`const sample=byId("career-networking-night");
    LIST=[
      {...sample,id:"campus",scope:"wsu",majors:["engineering"]},
      {...sample,id:"away",scope:"beyond",majors:["all"]}
    ]; state.profile.reach="both";`);
  assert.equal(run('upcoming(true).map(x=>x.o.id).join(",")'),"campus");
  assert.equal(run('upcoming(false).map(x=>x.o.id).join(",")'),"away");
});

test("marking a listing out of date hides suggestions until the student clears the mark", () => {
  const run=fixture();
  run('const original=candidates()[0].o;state.stale[original.id]=true');
  assert.equal(run("candidates().some(x=>x.o.id===original.id)"),false);
  assert.equal(run("LIST.some(o=>o.id===original.id)"),true);
  run('window.addEventListener=()=>{}');
  run(read("app/js/12-actions.js"));
  assert.ok(run("reportText().endsWith('Marked out of date: ' + original.title)"));
  run("state.stale[original.id]=false");
  assert.equal(run("candidates().some(x=>x.o.id===original.id)"),true);
  assert.doesNotMatch(run("reportText()"), /Marked out of date:/);
  run('state.stale["retired-id"]="Retired Workshop";state.stale["legacy-id"]=true');
  assert.match(run("reportText()"), /Marked out of date: Retired Workshop, Previously listed opportunity$/);
});

test("AI picks are rechecked against the catalog, the week’s remaining minutes and student choices", () => {
  const run = fixture();
  run(`state.profile.time=60; const pool=candidates(); const first=pool.find(x=>!x.o.outdated && x.o.steps[x.i].min<=60);
    const key=pkey(first.o,first.i); state.recommendations={signature:rankingSignature(),source:"semantic",items:[{key:"made-up:0"},{key},{key}]};`);
  assert.equal(run("pkey(picks()[0].o,picks()[0].i)"),run("key"));
  assert.ok(run("minutes()<=60 && new Set(picks().map(x=>x.o.id)).size===picks().length"));
  run("state.stale[first.o.id]=true");
  assert.equal(run("picks().some(x=>x.o.id===first.o.id)"),false);
  run("state.profile.busy=[0,1,2,3,4,5,6]");
  assert.equal(run("picks().length"),0);
  assert.equal(run("currentRanking()"),null);
});
test("a personal shortlist uses actual interests, fixed eligibility and a student's own goal", () => {
  const run=fixture();
  run(`Object.assign(state.profile,{name:"Secret Name", gpa:"3.654",where:"away",reach:"wsu",priority:"funding",goal:"Scholarships for college tuition",interests:["club","scholarship"]});
    const payload=rankingInput();`);
  assert.ok(run("payload.shortlist.length>0 && payload.shortlist.length<=36"));
  assert.ok(run('payload.shortlist.every(x=>x.o.steps[x.i].where!=="campus" && x.o.scope!=="beyond" && !x.o.nopick && !x.o.outdated && !x.o.support)'));
  assert.match(run("payload.body.preferences"), /Scholarships for college tuition/);
  assert.doesNotMatch(run("JSON.stringify(payload.body)"), /Secret Name|3\.654/);
  assert.ok(run('payload.shortlist.some(x=>x.o.type==="scholarship")'));
  assert.ok(run("payload.body.candidates.every(x=>x.reasons.length>0)"));
  run("state.profile.interests=[]");
  assert.equal(run("rankingInput().shortlist.length"),0);
});
test("a generated plan survives a saved profile and is invalidated by a new goal or week", () => {
  const run=fixture();
  run('const signature=rankingSignature(); state.recommendations={signature,source:"semantic",items:[]}; state=adopt(JSON.parse(JSON.stringify(state)));');
  assert.ok(run("currentRanking()"));
  run('prof().goal="Get a summer internship"');
  assert.equal(run("currentRanking()"),null);
  run('prof().goal=""; window.__NOW="2026-12-01T09:30:00"');
  assert.equal(run("currentRanking()"),null);
});

test("creating a plan schedules the displayed choices once and keeps existing list entries", async () => {
  const run=fixture();
  run(`window.addEventListener=()=>{}; window.scrollTo=()=>{}; document.getElementById=()=>null;
    const requestAnimationFrame=fn=>fn(); let saved; save=()=>{saved=JSON.stringify(state)}; function render(){};
    prof().busy=[2]; prof().time=180;
    const existing="own-step:0"; state.plan[existing]={status:"planned",day:today(),note:"Keep my notes",listing:{title:"My step",step:"Already scheduled",minutes:15}};`);
  run(read("app/js/12-actions.js"));
  await run("generateWeeklyPlan()");
  assert.equal(run("currentRanking().scheduledKeys.length"),3);
  assert.ok(run("currentRanking().scheduledKeys.every(k=>state.plan[k].status==='planned' && state.plan[k].listing.step && P(state.plan[k].day).getDay() !== 2)"));
  assert.match(run("viewPlanGeneration()"),/3 steps on your list/);
  assert.equal(run("state.plan[existing].note"),"Keep my notes");
  const before=run("JSON.stringify(state.plan)");
  await run("generateWeeklyPlan()");
  assert.equal(run("JSON.stringify(state.plan)"),before);
  run("state=adopt(JSON.parse(saved));const firstKey=currentRanking().scheduledKeys[0];state.plan[firstKey].day=weekEnd()");
  assert.ok(run("viewPlanGeneration().includes(fmtDate(weekEnd()))"));
  run("const archived=state.plan[firstKey].listing.title;LIST=LIST.filter(o=>o.id!==firstKey.split(':')[0])");
  assert.ok(run("viewPlanGeneration().includes(esc(archived))"));
});

test("auto-scheduling honors fixed events, prep deadlines, busy days, meeting weekdays and full weeks", () => {
  const run=fixture();
  run("window.addEventListener=()=>{}; save=()=>{};");
  run(read("app/js/12-actions.js"));
  run(`const base={...byId("bpc"),type:"career",scope:"wsu",majors:["all"],years:[1],src:null,nopick:false,outdated:false,support:false};
    function listing(id,step,dates=[]) { return {...base,id,title:id,steps:[{text:id,min:10,where:"any",...step}],dates}; }
    LIST=[listing("meeting",{weeklyMeeting:"Wednesdays at 5pm"}),listing("date",{event:0},[{date:"2026-11-26",label:"event"}]),
      listing("prep",{to:today()}),listing("busy",{weeklyMeeting:"Tuesdays at 5pm"}),listing("ended",{weeklyMeeting:"Mondays at 9am"})];
    prof().busy=[2];const keys=weeklyCandidates().map(x=>x.o.id);const rank=state.recommendations={signature:rankingSignature(),source:"rules",items:[]}; scheduleWeeklyPicks(rank);`);
  assert.deepEqual(JSON.parse(run("JSON.stringify(keys.sort())")),["date","meeting","prep"]);
  // Only the listing's own event date is saved. Auto-picked steps get no invented day.
  assert.equal(run('state.plan["prep:0"].day'),undefined);
  assert.equal(run('state.plan["date:0"].day'),"2026-11-26");
  assert.equal(run('state.plan["meeting:0"].day'),undefined);
  assert.equal(run('Object.values(state.plan).every(e=>e.status==="planned"&&e.week===weekStart())'),true);
  run('state.plan={};prof().busy=[0,1,2,3,4,5,6];const empty=state.recommendations={signature:rankingSignature(),source:"rules",items:[]};scheduleWeeklyPicks(empty)');
  assert.equal(run("Object.keys(state.plan).length"),0);
  assert.match(run("viewPlanGeneration()"),/Your week is full/);
});

test("a legacy plan preview is read-only until the student adds its exact steps", async () => {
  const run=fixture();
  run(`window.addEventListener=()=>{};window.scrollTo=()=>{};document.getElementById=()=>null;const requestAnimationFrame=fn=>fn();
    function render(){} save=()=>{};const first=weeklyCandidates()[0];state.recommendations={signature:rankingSignature(),source:"semantic",items:[{key:pkey(first.o,first.i),reason:"Fits Finance"}]};`);
  run(read("app/js/12-actions.js"));
  assert.match(run("viewPlanGeneration()"),/Add these steps to my list/);
  assert.equal(run("planned().length"),0);
  await run("generateWeeklyPlan()");
  assert.equal(run("planned().length"),1);
  assert.equal(run("planned()[0].k"),run("pkey(first.o,first.i)"));
});

test("Mathematics picks use the discipline across home, browse, the AI shortlist and the saved list", async () => {
  const run = fixture();
  run(`Object.assign(prof(), {major:"Mathematics", interests:["club"], time:180});
    const math = byId("wsu-math-club"), actuarial = LIST.find(o=>o.title==="Actuarial Science Club");
    const choir = LIST.find(o=>o.title==="God’s Harmony"), chemistry = LIST.find(o=>o.title==="Chemistry Club");
    const asme = LIST.find(o=>o.title.includes("(ASME)"));
    const wrong = [choir, chemistry, asme];`);
  assert.equal(run("picks()[0].o.title"), "Math Club");
  assert.ok(run("picks().some(x => x.o === actuarial)"));
  assert.match(run("fits(actuarial,0)[0]"), /Related to Mathematics through actuarial science/);
  assert.ok(run('wrong.every(o=>!subjectFit(o) && !badges(o,true).includes("Your major"))'));
  assert.ok(run("wrong.every(o=>!candidates().some(x=>x.o===o) && !rankingInput().shortlist.some(x=>x.o===o))"));
  assert.match(run("viewWeek()"), /Math Club/);
  run("viewClubs()");
  assert.ok(run("!found().some(x=>wrong.includes(x.o))"));
  run("ui.all=true");
  assert.ok(run("found().some(x=>x.o===choir)"));
  run(`window.addEventListener=()=>{}; window.scrollTo=()=>{}; document.getElementById=()=>null;
     const requestAnimationFrame=fn=>fn();function render(){};save=()=>{};`);
  run(read("app/js/12-actions.js"));
  await run("generateWeeklyPlan()");
  assert.ok(run("currentRanking().scheduledKeys.length===3 && planned().every(x=>subjectFit(x.o))"));
  run("state=adopt(JSON.parse(JSON.stringify(state)))");
  assert.ok(run("planned().some(x=>x.o.title==='Math Club') && !planned().some(x=>wrong.includes(x.o))"));
});

test("clubs use topic evidence across majors, including a goal outside the major and sparse coverage", () => {
  const run=fixture();
  const checks=[
    ["Music","God’s Harmony","Chemistry Club"],
    ["Chemistry","Chemistry Club","God’s Harmony"],
    ["Mechanical Engineering","American Society Of Mechanical Engineers (ASME)","Chemistry Club"],
    ["Data Analytics","Data Analytics Club","God’s Harmony"],
    ["Finance","FIRE Club (finance, insurance, real estate)","History Club"],
    ["History","History Club","God’s Harmony"],
    ["Civil Engineering","American Society of Civil Engineers at WSU","God’s Harmony"],
    ["Fine Arts","Art Club at WSU","American Society Of Mechanical Engineers (ASME)"],
    ["Economic Sciences","Econ Club","Food Science Club"],
    ["Public Affairs","Political Science Club","Horticulture Club at WSU"],
    ["Sports Medicine","Kinesiology Club","God’s Harmony"],
    ["Animal Sciences","Companion Animal Club","God’s Harmony"],
    ["Nursing","Rho- Nu (Pre-Nursing Club)","Companion Animal Club"],
    ["Sociology","Sociology Club","God’s Harmony"],
    ["Neuroscience","Neuroscience Club","God’s Harmony"],
    ["Women's Studies","Coalition for Women Students","God’s Harmony"],
    ["Journalism and Media Production","The Daily Evergreen","Food Science Club"],
  ];
  run('prof().interests=["club"];const titled=t=>LIST.find(o=>o.title===t)');
  for(const [major,match,unrelated] of checks){
    run("prof().major="+JSON.stringify(major));
    assert.ok(run("subjectFit(titled("+JSON.stringify(match)+"))"),major+" should match "+match);
    assert.equal(run("subjectFit(titled("+JSON.stringify(unrelated)+"))"),null,major+" should exclude "+unrelated);
  }
  run('prof().major="Music"');
  assert.match(run('subjectFit(titled("God’s Harmony")).reason'), /listing mentions “choir”/);
  assert.equal(run('subjectFit(titled("God’s Harmony")).direct'),false);
  run('prof().major="Architecture"');
  assert.match(run('subjectFit(titled("American Society of Landscape Architecture at WSU")).reason'), /Related to Architecture/);
  run('prof().major="Education"');
  assert.equal(run('subjectFit(titled("WISH Education"))'),null);
  run('prof().major="Mathematics";const choir=titled("God’s Harmony");prof().goal="I want to meet new people and learn about the clubs at WSU"');
  assert.equal(run("relevantSuggestion(choir)"),false);
  run('const specialtyEvent={title:"Chemistry internship fair",summary:"Meet employers",src:"involve",type:"career",majors:["all"]};');
  assert.equal(run("relevantSuggestion(specialtyEvent)"),false);
  assert.equal(run('relevantSuggestion({...specialtyEvent,title:"Campus internship fair"})'),true);
  run('prof().goal="constructor"');
  assert.equal(run("goalTopic(choir)"),"");
  run('prof().goal="Join a choir and sing with other people"');
  assert.equal(run("relevantSuggestion(choir)"),true);
  assert.ok(run('fits(choir,0)[0].includes("choir") && !fits(choir,0).join(" ").includes("Mathematics")'));
  run('prof().goal="";LIST=[choir];');
  assert.equal(run("picks().length"),0);
  assert.match(run("viewWeek()"),/No eligible clubs match Mathematics/);
  run('prof().major="Speech and Hearing Sciences"');
  assert.match(run("viewWeek()"),/href="https:\/\/healthprofessions\.wsu\.edu\/pre-speech-and-hearing-sciences\/"/);
  run('prof().major="Undecided or exploring"');
  assert.equal(run("picks().length"),1);
  assert.doesNotMatch(run('fits(choir,0).join(" ")'),/Fits |Finance/);
});

test("every selectable major keeps direct claims, admissions rules and browsing separate", () => {
  const run=fixture();
  run('prof().interests=["club","career","scholarship"];prof().time=180;');
  const failures=run(`MAJORS.flatMap(row=>{
    prof().major=row[1];
    const errors=[];
    if(majorRow()[1]!==row[1]) errors.push("wrong profile");
    const pool=candidates();
    if(pool.some(x=>!eligible(x.o) || x.o.grad || x.o.nopick)) errors.push("ineligible candidate");
    const items=picks();
    if(items.some(x=>!pool.some(c=>c.o===x.o && c.i===x.i))) errors.push("unfiltered pick");
    if(items.some(x=>x.o.type==="club" && !subjectFit(x.o) && row[0]!=="undecided")) errors.push("ungrounded club");
    const input=rankingInput();
    if(input.shortlist.some((x,i)=>!pool.some(c=>c.o===x.o) ||
      input.body.candidates[i].reasons.some(r=>r.startsWith("Fits ") && !subjectFit(x.o)?.direct))) errors.push("ungrounded plan reason");
    if(LIST.some(o=>badges(o,true).includes("Your major") !== !!subjectFit(o)?.direct)) errors.push("unverified badge");
    const other={title:"Welcome to campus",summary:"Open to students",boost:[row[0]],src:"involve",
      majors:["all"],type:"club",steps:[{min:10}]};
    if(subjectFit(other) || fits(other,0).some(r=>r.startsWith("Fits "))) errors.push("broad group counted as proof");
    return errors.map(e=>row[1]+": "+e);
  })`);
  assert.deepEqual(Array.from(failures),[]);
});

test("an old ranking is invalidated without touching an already saved step", () => {
  const run=fixture();
  run(`prof().major="Mathematics";prof().interests=["club"];const choir=LIST.find(o=>o.title==="God’s Harmony");
    const k=pkey(choir,0);
    const signature=JSON.parse(rankingSignature());signature.shift();
    state.recommendations={signature:JSON.stringify(signature),source:"semantic",items:[{key:k,reason:"Fits Mathematics"}],scheduledKeys:[k]};
    state.plan[k]={status:"planned",day:today()};`);
  assert.equal(run("currentRanking()"),null);
  assert.equal(run("planned()[0].o.title"),"God’s Harmony");
  assert.ok(run("!picks().some(x=>x.o===choir)"));
});
test("save status tells the student whether a change reached storage, and retry recovers", () => {
  const run = fixture();
  run(`globalThis.broken = false; globalThis.toasts = []; globalThis.chips = [{outerHTML:""}];
    globalThis.localStorage = {setItem(){ if (broken) throw new Error("blocked"); }, getItem:() => null, removeItem(){}};
    document.querySelectorAll = () => chips;
    toast = m => toasts.push(m);
    function openSection(s) { globalThis.opened = s; }`);
  assert.equal(run("saveChip()"), "", "nothing is claimed before the first save");
  run("save()");
  assert.match(run("chips[0].outerHTML"), /Saved on this device/);
  run("broken = true; save(); save()");
  assert.match(run("saveChip()"), /<button class="savechip failed"[^>]*data-act="saveretry"[^>]*>Not saved · tap to retry/);
  assert.equal(run("toasts.length"), 1, "the warning toast is not repeated on every failed save");
  run("retrySave()");
  assert.match(run("saveChip()"), /failed/, "retry while storage is still blocked stays failed");
  run("broken = false; retrySave()");
  assert.match(run("saveChip()"), /<span class="savechip saved"/);
});
test("account sync states map to plain labels and tappable recovery", () => {
  const run = fixture();
  run('globalThis.chips = []; document.querySelectorAll = () => chips; window.SUNDAY_CONFIG = {mode:"cloud"}; globalThis.sundayAccount = {retry(){ globalThis.retried = true; }}; function openSection(s) { globalThis.opened = s; }');
  for (const [state, label, tappable] of [["saved", "Saved to your account", false], ["saving", "Saving…", false],
    ["offline", "Saved here · sync pending", true], ["volatile", "Not saved yet", true], ["conflict", "Plan changed elsewhere", true]]) {
    run(`setSaveState("${state}")`);
    const html = run("saveChip()");
    assert.ok(html.includes(label), state);
    assert.equal(html.startsWith("<button"), tappable, state);
  }
  run("retrySave()");
  assert.equal(run("opened"), "you", "a conflict sends the student to the Profile review controls");
  run('setSaveState("offline"); retrySave()');
  assert.equal(run("retried"), true);
});
// Two browser tabs of the same student sharing one browser storage.
function tabs(mode = "tester") {
  const memory = new Map(), listeners = [];
  const localStorage = { getItem: k => memory.get(k) ?? null, setItem: (k, v) => memory.set(k, String(v)), removeItem: k => memory.delete(k) };
  const open = () => {
    const handlers = [];
    const context = vm.createContext({
      window: { __NOW: "2026-11-23T10:30:00", SUNDAY_CONFIG: { mode }, addEventListener: (t, f) => handlers.push([t, f]) },
      document: { addEventListener() {}, querySelectorAll: () => [] }, URLSearchParams, localStorage,
      calendarFile: require("../app/js/ical"), toast() {},
      raw: JSON.parse(read("local-data/seed.json")).docs,
      feeds: Object.fromEntries(["clubs", "events", "jobs", "feed"].map(k => [k, JSON.parse(read("app/data/" + k + ".json"))])),
    });
    const run = code => vm.runInContext(code, context);
    for (const file of ["plan-sync.js"].concat(fs.readdirSync(path.join(root, "app/js")).filter(n => /^0[1-9]-|^10-/.test(n)).sort()))
      vm.runInContext(read("app/js/" + file), context, { filename: file });
    run(`render = () => { globalThis.renders = (globalThis.renders || 0) + 1; };`);
    return { run, deliver: (key, value) => handlers.filter(h => h[0] === "storage").forEach(h => h[1]({ key, newValue: value, storageArea: localStorage })) };
  };
  return { open, memory };
}
test("a stale second tab keeps another tab's saved and completed steps", () => {
  const t = tabs();
  const a = t.open();
  a.run(`Object.assign(state.profile, {setup:true, name:"Test", major:"Finance"}); state.plan["x:0"] = {status:"planned", day:"2026-11-24"}; save();`);
  const b = t.open();
  assert.equal(b.run('state.plan["x:0"].status'), "planned");
  // Tab A finishes the step and saves a second one; tab B, never refreshed, saves its own different step.
  a.run('state.plan["x:0"] = {status:"done", at:"2026-11-24"}; state.plan["y:0"] = {status:"planned", day:"2026-11-25"}; save();');
  b.run('state.plan["z:0"] = {status:"planned", day:"2026-11-26"}; state.profile.time = 90; save();');
  const saved = JSON.parse(t.memory.get("sunday-plan-tester-v1"));
  assert.equal(saved.plan["x:0"].status, "done", "the completion survives the stale tab's save");
  assert.equal(saved.plan["y:0"].status, "planned");
  assert.equal(saved.plan["z:0"].status, "planned");
  assert.equal(saved.profile.time, 90);
  assert.equal(b.run('state.plan["y:0"].status'), "planned", "the stale tab now shows the merged plan");
});
test("conflicting edits to one step resolve the same way in every tab, and finished stays finished", () => {
  const t = tabs();
  const a = t.open();
  a.run('state.plan["x:0"] = {status:"planned", day:"2026-11-24"}; save();');
  const b = t.open();
  a.run('state.plan["x:0"] = {status:"done", at:"2026-11-24"}; save();');
  b.run('state.plan["x:0"] = {status:"skipped", reason:"busy"}; save();');
  assert.equal(JSON.parse(t.memory.get("sunday-plan-tester-v1")).plan["x:0"].status, "done");
  const c = t.open();
  c.run('state.plan["x:0"] = {status:"planned", day:"2026-11-27"}; state.profile.time = 30;');
  a.run("state.profile.time = 150; save();");
  c.run("save();");
  assert.equal(c.run("state.profile.time"), 30, "for the same setting the tab that saves last wins");
});
test("an open tab picks up another tab's save without being used", () => {
  const t = tabs();
  const a = t.open(), b = t.open();
  a.run('state.plan["x:0"] = {status:"planned", day:"2026-11-24"}; save();');
  b.deliver("sunday-plan-tester-v1", t.memory.get("sunday-plan-tester-v1"));
  assert.equal(b.run('state.plan["x:0"].status'), "planned");
  assert.equal(b.run("renders"), 1);
});
test("Saved for later keeps an idea off this week's picks, survives a week change, and moves out when planned", async () => {
  const run = fixture();
  run(`let onClick;
    document.querySelector = () => null; document.querySelectorAll = () => [];
    document.addEventListener = (type, fn) => { if (type === "click") onClick = fn; };
    window.addEventListener = () => {}; globalThis.toast = () => {}; render = () => {}; save = () => {};`);
  run(read("app/js/12-actions.js"));
  const top = run("const x = picks()[0]; pkey(x.o, x.i)");
  await run(`onClick({target:{closest: () => ({dataset:{act:"later", k:${JSON.stringify(top)}}})}})`);
  assert.equal(run(`!!state.later[${JSON.stringify(top)}]`), true);
  assert.equal(run(`candidates().some(x => pkey(x.o, x.i) === ${JSON.stringify(top)})`), false, "not offered as a weekly pick");
  assert.match(run("savedLater()"), /Saved for later/);
  run('window.__NOW = "2026-12-07T10:30:00"');
  assert.equal(run(`!!state.later[${JSON.stringify(top)}]`), true, "still there the next week");
  run(`setPlan(${JSON.stringify(top)}, {status:"planned", day:"2026-12-08"})`);
  assert.equal(run(`!!state.later[${JSON.stringify(top)}]`), false);
});
test("the week heading is today's date and the list card names its week across month and year boundaries", () => {
  const run = fixture();
  const at = (now) => { run(`window.__NOW = ${JSON.stringify(now)}`); return run("weekHead()"); };
  let html = at("2026-11-24T10:00:00");
  assert.match(html, /<h1>Tuesday, November 24<\/h1>/);
  assert.equal(run("weekSpan(weekStart(), weekEnd())"), "Nov 22–28");
  at("2026-11-30T10:00:00");
  assert.equal(run("weekSpan(weekStart(), weekEnd())"), "Nov 29–Dec 5");
  html = at("2026-12-30T10:00:00");
  assert.match(html, /<h1>Wednesday, December 30<\/h1>/);
  assert.equal(run("weekSpan(weekStart(), weekEnd())"), "Dec 27, 2026–Jan 2, 2027");
  run("const x = picks()[0]; state.plan[pkey(x.o, x.i)] = {status:'planned', day:today(), week:weekStart()}");
  assert.match(run("todoList()"), /lweek">Dec 27, 2026–Jan 2, 2027<\/small><small>1 to do/);
});

test("Add to my list saves at once with no day, from a card and from Saved for later; picking a day stays optional", async () => {
  const run = fixture();
  run(`let onClick;
    document.querySelector = () => null; document.querySelectorAll = () => [];
    document.addEventListener = (type, fn) => { if (type === "click") onClick = fn; };
    window.addEventListener = () => {}; globalThis.toast = () => {}; render = () => {}; save = () => {};`);
  run(read("app/js/12-actions.js"));
  run("const x = picks()[0], k = pkey(x.o, x.i)");
  assert.match(run("card(x, 'top', '')"), /data-act="plan"/);
  await run(`onClick({target:{closest: () => ({dataset:{act:"plan", k}})}})`);
  assert.equal(run("state.plan[k].status"), "planned");
  assert.equal(run("state.plan[k].day"), undefined);
  assert.equal(run("ui.planning"), null, "no day picker opens");
  const planned = run("card(x, 'top', '')");
  assert.match(planned, /On your list<\/span>/);
  assert.match(planned, /Pick a day \(optional\)/);
  assert.doesNotMatch(run("todoList()"), /Today|Tomorrow/);
  assert.doesNotMatch(run("todoList()"), /class="mini">On your list|undefined|NaN|Overdue|You planned/);
  assert.equal(run("appleButton(calForStep(planned().find(r => r.k === k)))"), "", "no calendar button without a date");
  await run(`onClick({target:{closest: () => ({dataset:{act:"pickday", k}})}})`);
  assert.equal(run("ui.planning"), run("k"));
  await run(`onClick({target:{closest: () => ({dataset:{act:"planday", k, day: today()}})}})`);
  assert.match(run("todoList()"), /Your plan: /);
  await run(`onClick({target:{closest: () => ({dataset:{act:"clearday", k}})}})`);
  assert.equal(run("state.plan[k].day"), undefined);
  assert.equal(run("planned().some(r => r.k === k)"), true, "undated step persists");
  run("const y = picks()[0], k2 = pkey(y.o, y.i); state.later[k2] = {id:y.o.id, title:y.o.title, step:'s', at:today()}");
  assert.match(run("savedLater()"), /data-act="plan" data-k=/);
  await run(`onClick({target:{closest: () => ({dataset:{act:"plan", k:k2}})}})`);
  assert.equal(run("!!state.later[k2] || state.plan[k2].day !== undefined"), false);
});
test("only real event dates, deadlines and the student's own days are labeled as dates", () => {
  const run = fixture();
  run(`const o = {id:"t", title:"T", dates:[{date:addDays(today(),3), label:"Apply", key:true},{date:addDays(today(),5), label:"Mixer", start:"18:00"}]};`);
  assert.deepEqual(JSON.parse(run(`JSON.stringify(whenParts(o, {text:"x"}, {status:"planned"}))`)).length, 1);
  assert.match(run(`whenParts(o, {text:"x"}, {status:"planned"})[0]`), /^Deadline /);
  assert.match(run(`whenParts(o, {text:"x", event:1}, {status:"planned", day:o.dates[1].date})[0]`), /^Event .*6 PM|^Event /);
  assert.match(run(`whenParts(o, {text:"x"}, {status:"planned", day:addDays(today(),1)})[1]`), /^Your plan: /);
});
test("Details buttons are scoped per place, keep their own state and expose aria-controls", () => {
  const run = fixture();
  run("const x = picks()[0]; const alt = {o:x.o, i:x.i}");
  const lead = run("card(x, 'top', '')"), list = run("card(alt, 'list', '')");
  assert.match(lead, /id="more-top-[^"]+"[^>]*aria-expanded="false"[^>]*aria-controls="body-top-/);
  run("ui.open['card:list:' + x.o.id] = true");
  assert.match(run("card(alt, 'list', '')"), /aria-expanded="true"/);
  assert.match(run("card(x, 'top', '')"), /aria-expanded="false"/, "the same listing elsewhere stays closed");
  assert.match(run("card(alt, 'list', '')"), /id="body-list-/);
  assert.notEqual(lead.match(/id="more-[^"]+"/)[0], list.match(/id="more-[^"]+"/)[0]);
});
test("Your list shows its week when empty, and pick pills never invent or misstate dates", () => {
  const run = fixture();
  run("window.__NOW='2026-12-30'; state.plan={}");
  const empty = run("viewWeek()");
  assert.match(empty, /Your list<\/h3><small class="lweek">Dec 27, 2026–Jan 2, 2027<\/small>/);
  assert.doesNotMatch(empty, /undefined|NaN|Invalid/);
  run("const x = picks()[0], k = pkey(x.o, x.i); state.plan[k] = {status:'planned', week: weekStart()}");
  let c = run("card(x, 'top', '')");
  assert.match(c, /On your list<\/span>/);
  assert.doesNotMatch(c, /Your plan|You planned|undefined|NaN/);
  run("state.plan[k].day = '2026-12-20'");
  assert.match(run("card(x, 'top', '')"), /You planned Sun, Dec 20/);
  run("state.plan[k].day = '2027-01-01'");
  assert.match(run("card(x, 'top', '')"), /Your plan: Fri, Jan 1 2027/);
  assert.doesNotMatch(run("viewWeek()"), /undefined|NaN|Invalid/);
});
test("row Details opens and Less closes readable detail even while a day picker, skip or meeting form is open", async () => {
  const run = fixture();
  run(`let onClick; document.querySelector = () => null; document.querySelectorAll = () => [];
    document.addEventListener = (t, fn) => { if (t === "click") onClick = fn; };
    window.addEventListener = () => {}; globalThis.toast = () => {}; render = () => {}; save = () => {};`);
  run(read("app/js/12-actions.js"));
  run("const x = picks()[0], k = pkey(x.o, x.i); state.plan[k] = {status:'planned', week: weekStart()}; ui.planning = k;");
  const row = () => run("todoList()");
  const rowBtn = (h) => h.match(/<button class="ttext" id="tx-[^"]+"[^>]*>/)[0];
  assert.match(rowBtn(row()), /aria-expanded="false"/);
  assert.match(row(), /id="more-row-[^"]+"[^>]*aria-expanded="false"/);
  const click = (id) => run(`onClick({target:{closest: () => ({dataset:{act:"open", id:${JSON.stringify(id)}}})}})`);
  click("row:" + run("k"));
  assert.match(rowBtn(row()), /aria-expanded="true"/);
  assert.match(row(), /Open page|class="actions"/);
  assert.match(row(), />Less</);
  click("row:" + run("k"));
  assert.match(rowBtn(row()), /aria-expanded="false"/);
  assert.match(row(), />Details</);
  // Skip form, then choosing a day: ids stay stable so focus can return to the same button.
  run("ui.planning = null; ui.skipping = k;");
  click("row:" + run("k"));
  assert.match(row(), /data-act="skipwhy"/);
  assert.match(rowBtn(row()), /aria-expanded="true"/);
  run("ui.skipping = null; ui.planning = k;");
  await run(`onClick({target:{closest: () => ({dataset:{act:"planday", k, day: today()}})}})`);
  assert.equal(run("ui.planning"), null);
  assert.match(rowBtn(row()), /id="tx-/);
  assert.match(rowBtn(row()), /aria-expanded="true"/);
});
test("normal flow no longer asks Did it already, Already knew, New to me or I know when it meets; saved data and Done/Undo remain", () => {
  const run = fixture();
  run("window.addEventListener=()=>{}; save=()=>{}; document.querySelector=()=>null; document.querySelectorAll=()=>[]; document.getElementById=()=>null;");
  run(read("app/js/12-actions.js"));
  run(`const x = picks()[0], k = pkey(x.o, x.i); const club = LIST.find(o=>o.type==="club" && o.steps?.length);
    const ck = pkey(club, 0); state.plan[ck] = {status:"done", at: today(), knew:true, note:"kept", week: weekStart()};
    ui.open["done:" + ck] = true; ui.open["card:top:" + x.o.id] = true;`);
  const all = run("viewWeek() + todoList() + card(picks()[0], 'list', '')")
  assert.doesNotMatch(read("app/js/10-screens.js"), /new to you/);;
  for (const t of [/Did it already/, /Already knew/, /New to me/, /new to you/, /I know when it meets/]) assert.doesNotMatch(all, t);
  assert.match(all, /data-act="undo"/);
  assert.match(all, /Note to yourself/);
  assert.equal(run("state.plan[ck].knew"), true);
  assert.equal(run("state.plan[ck].note"), "kept");
  assert.ok(!run("SKIPS").includes("Already knew about it"));
  assert.match(run("todoDone(entries().find(e=>e.k===ck))"), /Add a repeating meeting time/);
});
test("undated list rows have no redundant subtitle or overdue label, the ring says weekly goal, and a restored plan reports saved", () => {
  const run = fixture();
  run("window.__NOW='2026-12-30'; const x = picks()[0], k = pkey(x.o, x.i); state.plan[k] = {status:'planned', week:'2026-11-01'};");
  const list = run("todoList()");
  assert.doesNotMatch(list, /class="mini"|is-over|Overdue|Did it happen|undefined|NaN/);
  assert.match(run("weekHead()"), /Weekly goal: \d of 3 done/);
  assert.match(run("weekHead()"), /aria-label="Weekly goal: /);
  assert.match(read("app/js/05-ui-and-save.js"), /restoredFromStorage[^;]*\? "saved"/);
});
