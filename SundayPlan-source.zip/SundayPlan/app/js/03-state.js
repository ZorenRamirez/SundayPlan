/*
  03-state.js — what the app remembers about one student ("state").

  fresh() is what a brand-new save looks like: profile, reminder settings, the plan,
  the four-year checklist, weekly habits and attendance (the streak comes from these).
  On startup this file loads the last save kept in the browser.
*/
"use strict";
/* ---------- state ---------- */
const testerMode = window.SUNDAY_CONFIG?.mode === "tester";
const deviceProfile = testerMode || window.SUNDAY_CONFIG?.mode === "local";
const KEY = testerMode ? "sunday-plan-tester-v1" : "sunday-plan-v1",
  LKEY = "sunday-plan-listings-v1";
const fresh = () => ({
  v: 1,
  weekStartsOn: 0,
  profile: {
    setup: false,
    name: "",
    year: 1,
    major: "Finance",
    major_set: false,
    grad: 0,
    age: "",
    interests: [],
    priority: "balanced",
    commit: "",
    time: 120,
    where: "pullman",
    busy: [],
    gpa: "",
    reach: "",
    paid: null,
  },
  remind: { day: 0, time: "18:00", lead: 7, set: false },
  focus: {},
  welcomed: false,
  plan: {},
  later: {},
  road: {},
  habits: {},
  stale: {},
  weekly: {},
  attend: {},
  savedAt: 0,
});
function adopt(d) {
  const f = fresh();
  if (!d || typeof d !== "object") return f;
  const s = Object.assign(f, JSON.parse(JSON.stringify(d)));
  s.profile = Object.assign(fresh().profile, d.profile || {});
  s.remind = Object.assign(fresh().remind, d.remind || {});
  // Older saves used the summary weekday to group completed steps.
  const start = d.weekStartsOn ?? s.remind.day;
  s.weekStartsOn = Number.isInteger(+start) && +start >= 0 && +start <= 6 ? +start : 0;
  for (const k of ["plan", "later", "road", "habits", "stale", "weekly", "attend", "focus"])
    if (!s[k] || typeof s[k] !== "object") s[k] = {};
  return s;
}
let state = fresh();
let restoredFromStorage = false;
try {
  const r = localStorage.getItem(KEY);
  if (deviceProfile && r) {
    state = adopt(JSON.parse(r));
    restoredFromStorage = true;
  }
} catch (e) {}
// What this tab last read from or wrote to browser storage; the common ground for merging with other tabs.
let storedBase = deviceProfile ? JSON.parse(JSON.stringify(state)) : null;
let LIST = [],
  CUR = [],
  FEEDS = { clubs: [], events: [], jobs: [], meta: null };
let feed = { state: "loading", meta: null, cachedAt: null };
try {
  const r = JSON.parse(localStorage.getItem(LKEY) || "null");
  if (r && Array.isArray(r.list)) {
    CUR = r.list;
    feed.cachedAt = r.at;
    feed.meta = r.meta || null;
  }
} catch (e) {}
