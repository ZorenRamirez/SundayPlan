/*
  05-ui-and-save.js — what is on screen right now, and saving.

  ui    which tab is open, what is expanded, the search text. Never saved.
  save() writes the student's state to the browser straight away and, about 1.5 seconds
        later, to the database (locally that is local-data/database.json).
*/
"use strict";
const freshUI = () => ({
  tab: "week",
  planning: null,
  skipping: null,
  q: "",
  ftype: "",
  fscope: "",
  all: false,
  ob: 0,
  confirmReset: false,
  flash: null,
  dd: null,
  anim: true,
  wk: null,
  wform: null,
  focusRow: null,
  open: {},
  adjust: false,
  limit: 24,
  allDates: false,
});
let ui = freshUI();
let cloud = { doc: null, ok: false, timer: null, chain: Promise.resolve() },
  downloads = null;

// Save status: one short label, shown on every screen, so a student can tell whether a change stuck.
// A plan read back from this browser on return is truthfully "saved here".
let saveState = typeof restoredFromStorage !== "undefined" && restoredFromStorage ? "saved" : "";
const SAVE_LABELS = {
  saved: () => (window.SUNDAY_CONFIG?.mode === "cloud" ? "Saved to your account" : "Saved on this device"),
  saving: () => "Saving…",
  offline: () => "Saved here · sync pending",
  volatile: () => "Not saved yet · keep this tab open",
  failed: () => "Not saved · tap to retry",
  conflict: () => "Plan changed elsewhere · tap to review",
};
const SAVE_ACTIONABLE = ["offline", "volatile", "failed", "conflict"];
function saveChip() {
  if (!saveState) return "";
  const tag = SAVE_ACTIONABLE.includes(saveState) ? "button" : "span";
  return `<${tag} class="savechip ${saveState}" data-save-chip${tag === "button" ? ' type="button" data-act="saveretry"' : ""} role="status">${SAVE_LABELS[saveState]()}</${tag}>`;
}
function setSaveState(next) {
  if (!SAVE_LABELS[next] || next === saveState) return;
  saveState = next;
  // The chip changes tag when it becomes tappable, so replace it rather than edit it.
  for (const node of document.querySelectorAll("[data-save-chip]")) node.outerHTML = saveChip();
}
function retrySave() {
  if (saveState === "conflict") return openSection("you");
  if (window.SUNDAY_CONFIG?.mode === "cloud") return sundayAccount.retry();
  save();
}
// Another tab may have saved since this one last looked. Fold its changes into this tab's state
// before writing, so a stale tab never overwrites them. Returns true when anything changed.
function mergeOtherTabs(raw) {
  if (typeof mergePlans !== "function" || !deviceProfile) return false;
  let theirs;
  try {
    theirs = JSON.parse(raw === undefined ? localStorage.getItem(KEY) : raw);
  } catch {}
  if (!theirs || typeof theirs !== "object") return false;
  const mine = JSON.parse(JSON.stringify(state)),
    merged = adopt(mergePlans(storedBase, mine, adopt(theirs)));
  if (JSON.stringify(merged) === JSON.stringify(mine)) return false;
  for (const k of Object.keys(state)) delete state[k];
  Object.assign(state, merged);
  return true;
}
if (deviceProfile && typeof window.addEventListener === "function")
  window.addEventListener("storage", (e) => {
    if (e.key !== KEY || e.newValue == null || e.storageArea !== localStorage) return;
    const before = JSON.stringify(state);
    mergeOtherTabs(e.newValue);
    try { storedBase = adopt(JSON.parse(e.newValue)); } catch {}
    if (JSON.stringify(state) !== before && typeof render === "function") render();
  });
function save() {
  state.savedAt = Date.now();
  if (window.SUNDAY_CONFIG?.mode === "cloud") {
    sundayAccount.save(state);
    return;
  }
  try {
    mergeOtherTabs();
    localStorage.setItem(KEY, JSON.stringify(state));
    storedBase = JSON.parse(JSON.stringify(state));
    setSaveState("saved");
  } catch {
    const first = saveState !== "failed";
    setSaveState("failed");
    if (first) toast("Your browser could not save this plan. Allow site storage, then tap “Not saved” to retry.");
  }
  if (cloud.ok && cloud.doc) {
    clearTimeout(cloud.timer);
    cloud.timer = setTimeout(() => {
      const body = JSON.parse(JSON.stringify(state));
      cloud.chain = cloud.chain
        .then(() => cloud.doc.set(body))
        .catch((e) => {
          if (e && e.code === "invalid_argument") cloud.ok = false;
        });
    }, 1500);
  }
}
